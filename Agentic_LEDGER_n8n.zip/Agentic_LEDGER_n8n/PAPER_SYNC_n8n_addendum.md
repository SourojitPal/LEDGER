
## Addendum (11 Nov 2026): live n8n evaluation

**What was added.** I made LEDGER copies of two production-style n8n Cloud workflows (Moneycontrol news brief with Pinecone RAG memory; AI Recruiter with Brave Search). The details are in `integrations/n8n/README.md`, and the analysis is in `LEDGER_n8n_Live.ipynb`.

**Suggested paper text** (a short "Live deployment" paragraph or subsection, or the appendix if space is tight):

> We additionally deployed LEDGER inside two live n8n agent workflows: a news-brief agent (gpt-5-mini) with a Pinecone memory written by its own past runs, and a recruiting agent (Claude Sonnet 5) over web-search results. All reads go through a read hook that consults a quarantine registry. Layer F enforces source binding on the email sink: every link or profile URL must equal a value extracted by the workflow, not by the LLM. Violations are confirmed with the curtailed Fisher test (q = 4) using masked replays of the same LLM step, and are then repaired by re-derivation and quarantine. Over N runs per cell we report ASR, utility and LLM-call overhead with and without LEDGER for direct, stealth and memory-poisoning injections, plus two content-only attacks that are outside Layer F by construction.

**Claims this evidence supports:**
* Layer F, the replay/Fisher confirmation, rollback and quarantine with mediated reads work as specified in real agent stacks (LLM nodes, RSS, Brave, Pinecone, Gmail, data tables).
* The confirmation step prevents false quarantine. In smoke test exec 17, a case-only schema violation was flagged but not confirmed (p = 1).
* The cost is concentrated on flagged runs: 2q − 1 = 7 extra LLM calls at q = 4.

**Claims it does NOT support (state these explicitly):**
* Nothing here supports Layer S, Layer T, HITL triage or the conformal calibration. These are single-agent pipelines, and those layers are evaluated in simulation only.
* There is no MELON comparison on n8n. MELON is compared on AgentDojo (E1).
* The sample sizes are small (Wilson intervals are wide). Present the results as a feasibility study, not a benchmark.
* Content-only manipulation (`content`, `rank`) is the residual threat, consistent with the min-cut bound.

**Implementation notes to mention:**
* Suspect localisation in the live copies is content-match on the offending host/URL, with a fallback to the records the output cites. It is not the SVD localisation of Layer S.
* The workflow graph plays the role of the trusted planner: sinks and recipients are constants in the graph.
