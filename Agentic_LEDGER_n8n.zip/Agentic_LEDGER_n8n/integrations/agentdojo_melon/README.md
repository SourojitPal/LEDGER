# E1: LEDGER vs MELON on AgentDojo (MELON's own code)

Run it from the notebook (Section 10). Programmatic use:

```python
from ledger.keys import load_openai_key; load_openai_key()           # key from api_keys.py
from integrations.agentdojo_melon.ledger_agentdojo import offline_selftest, run_e1
offline_selftest("banking", melon_path=MELON_PATH)                    # no key, no cost
rows, summary = run_e1("banking", defenses=("none", "melon", "melon_exact", "ledger"),
                       model="gpt-4o-mini-2024-07-18", user_tasks=None, injection_tasks=None,
                       melon_path=MELON_PATH)
```

* `melon_loader.py` loads your `pi_detector.py` unchanged on disk; in memory it drops two unused
  heavy imports (transformers, torch), reads the key from `OPENAI_API_KEY`, and – for MELON-exact
  only – swaps the single cosine line for exact action-alphabet equality. It refuses to load if that
  line is not found exactly once.
* `ledger_agentdojo.py` builds the four pipelines, counts LLM/embedding calls and tokens, and runs
  AgentDojo's `benchmark_suite_with_injections` / `..._without_injections`.
* AgentDojo version: `agentdojo==0.1.29` (MELON's code expects string message contents, which
  changed in 0.1.30). Pipeline names must contain an AgentDojo model id (e.g. `gpt-4o-mini-2024-07-18`)
  because the `important_instructions` attack addresses the model by name.
* `make_melon_exact.py` is the alternative manual route (writes `pi_detector_exact.py` into an
  AgentDojo checkout).
