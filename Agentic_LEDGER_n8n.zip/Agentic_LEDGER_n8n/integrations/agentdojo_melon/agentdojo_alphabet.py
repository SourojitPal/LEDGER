"""Finite action alphabet pi for AgentDojo tool calls (E1 of the code plan: exact comparison
inside MELON's own code). High-consequence arguments keep their exact normalised value;
all other arguments are reduced to a type class.

The table lists the AgentDojo v1 suites (banking, slack, workspace, travel). Unknown tools
fall back to "all arguments exact", which is conservative (never merges distinct calls).
"""
from __future__ import annotations

import re
from typing import Dict, Tuple

HC_ARGS: Dict[str, Tuple[str, ...]] = {
    # banking
    "send_money": ("recipient", "amount"), "schedule_transaction": ("recipient", "amount"),
    "update_scheduled_transaction": ("id", "recipient", "amount"), "update_password": ("password",),
    "update_user_info": ("street", "city"),
    # slack
    "send_direct_message": ("recipient",), "send_channel_message": ("channel",),
    "invite_user_to_slack": ("user", "user_email"), "add_user_to_channel": ("user", "channel"),
    "remove_user_from_slack": ("user",), "post_webpage": ("url",), "get_webpage": ("url",),
    # workspace
    "send_email": ("recipients", "cc", "bcc"), "delete_email": ("email_id",), "delete_file": ("file_id",),
    "share_file": ("file_id", "email", "permission"), "create_calendar_event": ("participants",),
    "add_calendar_event_participants": ("event_id", "participants"), "cancel_calendar_event": ("event_id",),
    # travel
    "reserve_hotel": ("hotel",), "reserve_restaurant": ("restaurant",), "reserve_car_rental": ("company",),
}

_CALL = re.compile(r"^\s*([\w\.]+)\((.*)\)\s*$", re.S)
_SPLIT = re.compile(r",\s*(?=[A-Za-z_]\w*\s*=\s)")


def _norm(v: str) -> str:
    v = v.strip().strip("'\"").lower()
    try:
        f = float(v)
        return str(int(f)) if f.is_integer() else f"{f:.4g}"
    except ValueError:
        return " ".join(v.split())


def _cls(v: str) -> str:
    v = v.strip()
    if re.fullmatch(r"-?\d+(\.\d+)?", v):
        return "number"
    if v.startswith("["):
        return "list"
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}.*", v):
        return "date"
    return "text"


def parse_call(text: str):
    m = _CALL.match(text)
    if not m:
        return text.strip(), {}
    name, inner = m.group(1), m.group(2).strip()
    args = {}
    if inner:
        for part in _SPLIT.split(inner):
            if "=" in part:
                k, v = part.split("=", 1)
                args[k.strip()] = v.strip()
    return name, args


def pi(call_text: str) -> str:
    """Symbol in Sigma for MELON's textual tool call 'fn(a = x, b = y)'."""
    name, args = parse_call(call_text)
    hc = HC_ARGS.get(name)
    parts = [name]
    for k in sorted(args):
        if hc is None or k in hc:
            parts.append(f"{k}={_norm(args[k])}")
        else:
            parts.append(f"{k}:{_cls(args[k])}")
    return "|".join(parts)


def exact_match(a: str, b: str) -> bool:
    return pi(a) == pi(b)
