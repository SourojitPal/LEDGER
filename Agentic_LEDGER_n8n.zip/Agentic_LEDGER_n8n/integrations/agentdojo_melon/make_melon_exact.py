"""Create MELON-exact from MELON's official pi_detector.py (github.com/kaijiezhu11/MELON).

The ONLY change: the embedding cosine similarity between an original and a masked tool call
is replaced by exact equality of their symbols in the finite action alphabet (1.0 if
pi(a) == pi(b) else 0.0). MELON's threshold test `cosine_sim > 0.8` then fires exactly on
symbol equality; masking, tool-call bank and abort logic are untouched.

Usage:
    python make_melon_exact.py path/to/agentdojo/src/agentdojo/agent_pipeline/pi_detector.py
writes pi_detector_exact.py next to it (class MELON is kept; import it as MELON_EXACT).
Register it in agent_pipeline.py exactly like MELON (see README.md).
"""
import re
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent


def patch(src: Path) -> Path:
    code = src.read_text(encoding="utf-8")
    pattern = r"cosine_sim = np\.dot\(original_tool_call_emb, masked_tool_call_emb\) / \(np\.linalg\.norm\(original_tool_call_emb\) \* np\.linalg\.norm\(masked_tool_call_emb\)\)"
    n = len(re.findall(pattern, code))
    if n != 1:
        raise SystemExit(f"Expected exactly one cosine line in {src}, found {n}. MELON version changed?")
    code = re.sub(pattern, "cosine_sim = 1.0 if exact_match(original_tool_call, masked_tool_call) else 0.0", code)
    code = code.replace("import numpy as np", "import numpy as np\nfrom agentdojo.agent_pipeline.agentdojo_alphabet import exact_match", 1)
    dst = src.with_name("pi_detector_exact.py")
    dst.write_text(code, encoding="utf-8")
    shutil.copy(HERE / "agentdojo_alphabet.py", src.with_name("agentdojo_alphabet.py"))
    return dst


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit(__doc__)
    print("written:", patch(Path(sys.argv[1])))
