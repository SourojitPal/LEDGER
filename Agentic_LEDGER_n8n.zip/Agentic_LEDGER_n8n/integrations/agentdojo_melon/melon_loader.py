"""Load MELON's official ``pi_detector.py`` (github.com/kaijiezhu11/MELON) from your folder without
editing it, so the comparison runs MELON's own code.

Only three *mechanical* changes are applied in memory (the file on disk is untouched):

1. unused heavy imports (``from transformers import AutoModel``, ``import torch.nn.functional as F``)
   are removed, so neither transformers nor torch is needed;
2. the hard-coded ``OpenAI(api_key="your-api-key")`` reads ``OPENAI_API_KEY`` from the environment
   (set it once in ``api_keys.py`` in the project root);
3. for **MELON-exact** only: the embedding cosine similarity between an original and a masked tool
   call is replaced by exact equality of their symbols in the finite action alphabet
   (1.0 if pi(a) == pi(b) else 0.0), so MELON's own test ``cosine_sim > 0.8`` fires exactly on symbol
   equality. Masking, tool-call bank and stop logic are unchanged.

``quiet=True`` silences MELON's very verbose debug printing.
"""
from __future__ import annotations

import os
import re
import sys
import types
from pathlib import Path

HERE = Path(__file__).resolve().parent
COSINE_LINE = re.compile(
    r"cosine_sim = np\.dot\(original_tool_call_emb, masked_tool_call_emb\) / "
    r"\(np\.linalg\.norm\(original_tool_call_emb\) \* np\.linalg\.norm\(masked_tool_call_emb\)\)")


def default_melon_path() -> Path:
    """Look for pi_detector.py in the usual places (your OneDrive 'Melon' folder first)."""
    cands = [
        os.environ.get("MELON_PI_DETECTOR", ""),
        r"C:\Users\souro\OneDrive\Documents\My Files\Further Studies\Post enrollment Works"
        r"\Work 15 - Agentic AI\3. PERAGENT\Melon\pi_detector.py",
        str(HERE / "pi_detector.py"),
    ]
    for c in cands:
        if c and Path(c).is_file():
            return Path(c)
    raise FileNotFoundError("MELON's pi_detector.py not found. Set MELON_PATH in the notebook "
                            "(or the MELON_PI_DETECTOR environment variable).")


def _patched_source(src: str, exact: bool) -> str:
    n_cos = len(COSINE_LINE.findall(src))
    if n_cos != 1:
        raise RuntimeError(f"Expected exactly one cosine-similarity line in MELON, found {n_cos}. "
                           "Has pi_detector.py changed?")
    src = re.sub(r"^\s*from transformers import AutoModel\s*$", "", src, flags=re.M)
    src = re.sub(r"^\s*import torch\.nn\.functional as F\s*$", "", src, flags=re.M)
    src, n_key = re.subn(r"OpenAI\(\s*api_key\s*=\s*['\"][^'\"]*['\"]\s*\)",
                         "OpenAI(api_key=os.environ.get('OPENAI_API_KEY'))", src)
    if n_key == 0 and "OpenAI(" in src:
        raise RuntimeError("Could not find MELON's OpenAI(api_key=...) line to redirect to OPENAI_API_KEY.")
    header = "import os\n"
    if exact:
        header += "from integrations.agentdojo_melon.agentdojo_alphabet import exact_match\n"
        src = COSINE_LINE.sub("cosine_sim = 1.0 if exact_match(original_tool_call, masked_tool_call) else 0.0", src)
    return header + src


def load_melon(path=None, exact: bool = False, quiet: bool = True) -> types.ModuleType:
    """Return the MELON module (class ``MELON`` inside). ``exact=True`` gives MELON-exact."""
    p = Path(path) if path else default_melon_path()
    src = p.read_text(encoding="utf-8")
    name = "melon_pi_detector_exact" if exact else "melon_pi_detector"
    mod = types.ModuleType(name)
    mod.__file__ = str(p)
    sys.modules[name] = mod
    exec(compile(_patched_source(src, exact), f"{p} [{'exact' if exact else 'original'}]", "exec"), mod.__dict__)
    if quiet:
        mod.__dict__["print"] = lambda *a, **k: None
        mod.__dict__["pprint"] = lambda *a, **k: None
    return mod
