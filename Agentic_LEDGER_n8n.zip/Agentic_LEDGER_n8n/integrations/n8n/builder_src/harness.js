const fs=require('fs');const {DateTime}=require('luxon');
let src=fs.readFileSync(process.argv[2],'utf8').replace(/^export default /m,'module.exports.wf = ');
const nodes={};const mk=(kind)=>(o)=>{const c=o.config||o;nodes[c.name]=o;const b={to:()=>b,input:()=>b,onTrue:()=>b,onFalse:()=>b,output:()=>b,add:()=>b,group:()=>b};return b;};
const ctx={trigger:mk(),node:mk(),merge:mk(),ifElse:mk(),languageModel:mk(),outputParser:mk(),embeddings:mk(),vectorStore:mk(),textSplitter:mk(),documentLoader:mk(),tool:mk(),memory:mk(),
 sticky:()=>({}),expr:s=>s,newCredential:x=>x,fromAi:x=>x,workflow:()=>{const b={to:()=>b,add:()=>b,group:()=>b};return b;}};
const f=new Function(...Object.keys(ctx),'module',src);const m={exports:{}};f(...Object.values(ctx),m);
module.exports={nodes,run(name,data,input){const code=nodes[name].config.parameters.jsCode;
 const $=(n)=>({first:()=>({json:data[n][0]}),all:()=>data[n].map(j=>({json:j}))});
 const fn=new Function('$','$input','$execution','$now',code);
 return fn($,{first:()=>({json:input[0]}),all:()=>input.map(j=>({json:j}))},{id:'777'},DateTime.now()).map(x=>x.json);}};
for(const [n,o] of Object.entries(nodes)){const c=o.config;if(c&&c.parameters&&c.parameters.jsCode){try{new Function('$','$input','$execution','$now',c.parameters.jsCode);console.log('OK syntax',n)}catch(e){console.log('ERR',n,e.message)}}}
