"""Analyse the live n8n LEDGER runs (data table `ledger_runs`, exported as CSV).

Usage (from the project root):
    python -m integrations.n8n.analyze_ledger_runs  integrations/n8n/data/ledger_runs.csv
or call `analyze(csv_path, out_dir)` from the notebook.

Outputs (out_dir, default results/n8n/):
    tables/n8n_summary.csv / .tex      per workflow x attack mode x LEDGER on/off
    tables/n8n_verdicts.csv            verdict counts
    tables/n8n_confirmation.csv        replay confirmation (Fisher) per flagged run
    figures/n8n_asr_utility.png/.pdf   main figure: ASR and utility, no defense vs LEDGER, Wilson 95% CI, k/n labels
    figures/n8n_outcome_grid.png/.pdf  one row per run: flagged / confirmed / blocked / attack reached inbox / utility
    figures/n8n_confirmation.png/.pdf  replay confirmation: x_u vs x_m on the Fisher p-value grid (q = 4)
    figures/n8n_cost.png/.pdf          LLM calls and wall-clock time per run
    figures/n8n_verdicts.png/.pdf      verdict mix per cell
Same palette and style as the simulation figures (ledger/plots.py).
Every figure is tagged [LIVE n8n] so it is never confused with the simulation figures.
"""
from __future__ import annotations

import math
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

MODES = ["none", "direct", "stealth", "memory", "content", "rank"]
RESIDUAL_MODES = {"content", "rank"}          # content-only manipulation: outside Layer F by design
BOOL_COLS = ["ledger_enabled", "confirmed", "repaired", "attack_success", "utility"]
NUM_COLS = ["x_unmasked", "x_masked", "p_value", "memory_records_read", "memory_records_blocked", "llm_calls", "duration_s"]


def wilson(k: int, n: int, z: float = 1.96) -> tuple[float, float, float]:
    if n == 0:
        return float("nan"), float("nan"), float("nan")
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return p, max(0.0, c - h), min(1.0, c + h)


def _to_bool(s: pd.Series) -> pd.Series:
    if s.dtype == bool:
        return s
    return s.astype(str).str.strip().str.lower().isin(["true", "1", "yes", "t"])


def load_runs(csv_path: str | Path) -> pd.DataFrame:
    df = pd.read_csv(csv_path)
    df.columns = [c.strip() for c in df.columns]
    for c in BOOL_COLS:
        if c in df:
            df[c] = _to_bool(df[c])
    for c in NUM_COLS:
        if c in df:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    df["attack_mode"] = df["attack_mode"].astype(str).str.lower().str.strip()
    df["defense"] = np.where(df["ledger_enabled"], "LEDGER", "no defense")
    df["attacked"] = df["attack_mode"] != "none"
    df["flagged_bool"] = df["flagged"].astype(str).str.lower().eq("yes")
    df["false_flag"] = (~df["attacked"]) & df["flagged_bool"]
    # residual influence: did the injected record get *selected* (main story / top-2 candidate) even without a
    # structural violation?  Parsed from the notes column written by the workflows.
    notes = df.get("notes", pd.Series([""] * len(df))).fillna("").astype(str)
    rank = pd.to_numeric(notes.str.extract(r"attacker_rank=(\d+)")[0], errors="coerce").fillna(0)
    df["injected_selected"] = df["attacked"] & (notes.str.contains("main_link=[^ ]*ledger-test", regex=True) | (rank > 0))
    for c in ["x_unmasked", "x_masked", "p_value"]:
        df.loc[df[c] < 0, c] = np.nan                       # -1 = replay not run
    return df


def summary_table(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (wf, mode, dfn), g in df.groupby(["workflow", "attack_mode", "defense"]):
        n = len(g)
        asr, asr_lo, asr_hi = wilson(int(g["attack_success"].sum()), n)
        ut, ut_lo, ut_hi = wilson(int(g["utility"].sum()), n)
        se, se_lo, se_hi = wilson(int(g["injected_selected"].sum()), n) if mode != "none" else (np.nan,) * 3
        rows.append({
            "workflow": wf, "attack_mode": mode, "defense": dfn, "n": n, "asr_k": int(g["attack_success"].sum()), "ut_k": int(g["utility"].sum()),
            "ASR": asr, "ASR_lo": asr_lo, "ASR_hi": asr_hi,
            "utility": ut, "utility_lo": ut_lo, "utility_hi": ut_hi,
            "flag_rate": g["flagged_bool"].mean(),
            "selected": se, "selected_lo": se_lo, "selected_hi": se_hi, "sel_k": int(g["injected_selected"].sum()),
            "confirm_rate": g["confirmed"].mean(),
            "false_flag_rate": g["false_flag"].mean() if mode == "none" else np.nan,
            "mem_blocked": g["memory_records_blocked"].sum(),
            "llm_calls_mean": g["llm_calls"].mean(),
            "duration_s_mean": g["duration_s"].mean(),
            "residual_threat": mode in RESIDUAL_MODES,
        })
    out = pd.DataFrame(rows)
    order = {m: i for i, m in enumerate(MODES)}
    return out.sort_values(["workflow", "attack_mode", "defense"], key=lambda s: s.map(order) if s.name == "attack_mode" else s)


def _fmt_ci(p, lo, hi):
    return "--" if np.isnan(p) else f"{p:.2f} [{lo:.2f}, {hi:.2f}]"


def write_tex(summ: pd.DataFrame, path: Path) -> None:
    lines = [r"\begin{tabular}{llrlllr}", r"\toprule",
             r"Workflow & Attack & Defense & $n$ & ASR [95\% CI] & Utility [95\% CI] & LLM calls \\", r"\midrule"]
    for _, r in summ.iterrows():
        mode = r.attack_mode + (r"$^\dagger$" if r.residual_threat else "")
        lines.append(f"{r.workflow} & {mode} & {r.defense} & {r.n} & {_fmt_ci(r.ASR, r.ASR_lo, r.ASR_hi)} & "
                     f"{_fmt_ci(r.utility, r.utility_lo, r.utility_hi)} & {r.llm_calls_mean:.1f} \\\\")
    lines += [r"\bottomrule", r"\end{tabular}",
              r"% dagger: content-only manipulation, outside Layer F by design (residual threat)"]
    path.write_text("\n".join(lines), encoding="utf-8")



# ------------------------------------------------------------------ style (same palette as ledger/plots.py)
COLORS = {"no defense": "#8a8985", "LEDGER": "#2a78d6"}
VERDICT_COLORS = {"V0": "#1baf7a", "V2": "#eda100", "V3": "#d64545", "OFF": "#b5b4ae"}
VERDICT_LABELS = {"V0": "V0 pass", "V2": "V2 blocked, not confirmed", "V3": "V3 confirmed + quarantined", "OFF": "no defense"}
MODE_LABELS = {"none": "Benign", "direct": "Direct injection", "stealth": "Stealth (no keywords)",
               "memory": "Memory poisoning", "content": "Content-only\n(residual)", "rank": "Rank manipulation\n(residual)"}
WF_LABELS = {"moneycontrol": "News brief agent (gpt-5-mini + Pinecone memory)",
             "recruiter": "Recruiter agent (Claude + web search)"}
INK, INK2, GRID = "#0b0b0b", "#52514e", "#e4e3df"
TAG = " [LIVE n8n]"


# fonts: Times New Roman; figure title 14 pt, axes title 12 pt, labels 10 pt, tick labels 10 pt (same as ledger/plots.py)
FONT_FAMILY = ["Times New Roman", "Times", "Liberation Serif", "Nimbus Roman", "TeX Gyre Termes", "DejaVu Serif"]
FS_TITLE, FS_AXTITLE, FS_LABEL, FS_TICK = 14, 12, 10, 10
FS_TEXT = FS_LABEL


def set_style() -> None:
    import logging
    logging.getLogger("matplotlib.font_manager").setLevel(logging.ERROR)
    matplotlib.rcParams.update({
        "figure.dpi": 110, "savefig.dpi": 300,
        "font.family": "serif", "font.serif": FONT_FAMILY, "mathtext.fontset": "stix",
        "font.size": FS_LABEL, "figure.titlesize": FS_TITLE, "axes.titlesize": FS_AXTITLE,
        "axes.labelsize": FS_LABEL, "xtick.labelsize": FS_TICK, "ytick.labelsize": FS_TICK,
        "legend.fontsize": FS_TEXT, "pdf.fonttype": 42, "ps.fonttype": 42,
        "axes.edgecolor": "#b5b4ae", "axes.linewidth": 0.8, "axes.grid": True, "grid.color": GRID,
        "grid.linewidth": 0.6, "axes.axisbelow": True, "axes.spines.top": False, "axes.spines.right": False,
        "legend.frameon": False, "xtick.color": INK2, "ytick.color": INK2,
        "axes.labelcolor": INK, "text.color": INK,
    })


def _save(fig, out: Path, name: str) -> None:
    fig.savefig(out / f"{name}.png", dpi=300, bbox_inches="tight")
    fig.savefig(out / f"{name}.pdf", bbox_inches="tight")
    plt.close(fig)


def _modes_present(s: pd.DataFrame) -> list:
    return [m for m in MODES if m in set(s.attack_mode)]


def plot_asr_utility(summ: pd.DataFrame, out: Path) -> None:
    """Main figure: rows = ASR / utility, columns = workflow; paired bars no defense vs LEDGER, Wilson 95% CI,
    k/n printed on every bar (so a zero is visible), residual modes shaded."""
    wfs = [w for w in ["moneycontrol", "recruiter"] if w in set(summ.workflow)] + \
          [w for w in summ.workflow.unique() if w not in ("moneycontrol", "recruiter")]
    fig, axes = plt.subplots(3, len(wfs), figsize=(6.6 * len(wfs), 10.8), squeeze=False, sharey=True)
    w = 0.38
    for j, wf in enumerate(wfs):
        s = summ[summ.workflow == wf]
        modes = _modes_present(s)
        x = np.arange(len(modes))
        for row, (metric, kcol, ylab) in enumerate([("ASR", "asr_k", "Attack success rate (ASR)"),
                                                   ("utility", "ut_k", "Utility (clean, bound output)"),
                                                   ("selected", "sel_k", "Injected record chosen\n(residual influence)")]):
            ax = axes[row, j]
            for i, m in enumerate(modes):
                if m in RESIDUAL_MODES:
                    ax.axvspan(i - 0.5, i + 0.5, color="#f6efe0", zorder=0, lw=0)
            for k, dfn in enumerate(["no defense", "LEDGER"]):
                v = s[s.defense == dfn].set_index("attack_mode").reindex(modes)
                y = v[metric].to_numpy(float)
                lo = np.clip(y - v[f"{metric}_lo"].to_numpy(float), 0, None)
                hi = np.clip(v[f"{metric}_hi"].to_numpy(float) - y, 0, None)
                xs = x + (k - 0.5) * w
                ax.bar(xs, np.nan_to_num(y), w * 0.92, color=COLORS[dfn], label=dfn,
                       yerr=[np.nan_to_num(lo), np.nan_to_num(hi)],
                       error_kw={"elinewidth": 0.8, "capsize": 2, "ecolor": INK2})
                for xi, yi, kk, nn in zip(xs, y, v[kcol].to_numpy(), v["n"].to_numpy()):
                    if np.isnan(yi):
                        ax.text(xi, 0.02, "not run", ha="center", va="bottom", fontsize=FS_TEXT, color=INK2, rotation=90)
                    else:
                        ax.text(xi, max(yi, 0) + 0.03, f"{int(kk)}/{int(nn)}", ha="center", va="bottom",
                                fontsize=FS_TEXT, color=COLORS[dfn] if dfn == "LEDGER" else INK2, fontweight="bold")
            ax.set_xticks(x)
            ax.set_xticklabels([MODE_LABELS.get(m, m) for m in modes], rotation=18, ha="right")
            ax.set_ylim(0, 1.18)
            ax.grid(axis="x", visible=False)
            ax.set_yticks([0, 0.25, 0.5, 0.75, 1.0])
            if j == 0:
                ax.set_ylabel(ylab)
            if row == 0:
                ax.set_title(WF_LABELS.get(wf, wf))
    h, l = axes[0, 0].get_legend_handles_labels()
    import matplotlib.patches as mpatches
    h.append(mpatches.Patch(color="#f6efe0")); l.append("residual threat (no structural violation; outside Layer F)")
    fig.legend(h, l, loc="upper center", ncol=3, bbox_to_anchor=(0.5, 1.03))
    fig.suptitle("LEDGER vs no defense on live agent workflows" + TAG + "\n(bars: rate, whiskers: Wilson 95% CI, labels: k/n)",
                 y=1.08)
    fig.tight_layout()
    _save(fig, out, "n8n_asr_utility")


def plot_outcome_grid(df: pd.DataFrame, out: Path) -> None:
    """One row per run: what LEDGER did and what reached the inbox. Readable even with very few runs."""
    d = df.copy()
    order = {m: i for i, m in enumerate(MODES)}
    d["_o"] = d.attack_mode.map(order).fillna(99)
    d = d.sort_values(["workflow", "_o", "defense", "execution_id"]).reset_index(drop=True)
    cols = [("flagged_bool", "Layer F\nflagged"), ("confirmed", "Replay\nconfirmed"), ("blocked_any", "Memory/records\nblocked"),
            ("attack_success", "Attack reached\ninbox"), ("injected_selected", "Injected record\nchosen (residual)"),
            ("utility", "Useful clean\nemail")]
    d["blocked_any"] = d["memory_records_blocked"].fillna(0) > 0
    fig, ax = plt.subplots(figsize=(11.5, 0.42 * len(d) + 2.2))
    for i, r in d.iterrows():
        for j, (c, _) in enumerate(cols):
            val = bool(r[c])
            bad = c in ("attack_success", "injected_selected")
            col = (("#d64545" if c == "attack_success" else "#eda100") if val else "#e8f4ee") if bad else (("#2a78d6" if c != "utility" else "#1baf7a") if val else "#f2f1ee")
            ax.add_patch(plt.Rectangle((j, i), 0.94, 0.86, color=col, lw=0))
            ax.text(j + 0.47, i + 0.43, "yes" if val else "no", ha="center", va="center", fontsize=FS_TEXT,
                    color="white" if (val and col not in ("#e8f4ee", "#f2f1ee")) else INK2)
        ax.text(len(cols) + 0.1, i + 0.43, f"{r.verdict}", va="center", fontsize=FS_TEXT,
                color=VERDICT_COLORS.get(r.verdict, INK), fontweight="bold")
    ax.set_xlim(0, len(cols) + 0.7)
    ax.set_ylim(len(d), 0)
    ax.set_xticks([j + 0.47 for j in range(len(cols))] + [len(cols) + 0.3])
    ax.set_xticklabels([c[1] for c in cols] + ["verdict"], fontsize=FS_TEXT)
    ax.xaxis.tick_top()
    ax.set_yticks([i + 0.43 for i in range(len(d))])
    ax.set_yticklabels([f"{'news' if r.workflow == 'moneycontrol' else r.workflow} · {r.attack_mode} · {'LEDGER' if r.ledger_enabled else 'off'} · #{r.execution_id}"
                        for _, r in d.iterrows()], fontsize=FS_TEXT)
    ax.grid(False)
    for sp in ax.spines.values():
        sp.set_visible(False)
    ax.tick_params(length=0)
    ax.set_title("Per-run outcomes" + TAG, pad=34)
    _save(fig, out, "n8n_outcome_grid")


def plot_confirmation(df: pd.DataFrame, out: Path) -> None:
    """Replay confirmation: violating replays with all records (x_u) vs with suspects masked (x_m).
    Background = one-sided Fisher p-value for q=4; confirmation region p <= 0.05 outlined."""
    from math import comb
    q = 4

    def fisher(xu, xm, n=q):
        K, N = xu + xm, 2 * n
        if K == 0:
            return 1.0
        return min(1.0, sum(comb(n, x) * comb(n, K - x) for x in range(xu, min(n, K) + 1)) / comb(N, K))

    P = np.array([[fisher(xu, xm) for xu in range(q + 1)] for xm in range(q + 1)])
    fig, ax = plt.subplots(figsize=(7.4, 6.6))
    im = ax.imshow(P, origin="lower", cmap="Blues_r", vmin=0, vmax=1, extent=(-0.5, q + 0.5, -0.5, q + 0.5))
    for xm in range(q + 1):
        for xu in range(q + 1):
            p = P[xm, xu]
            ax.text(xu - 0.44, xm + 0.42, f"p={p:.3f}" if p < 0.1 else f"p={p:.2f}", ha="left", va="top", fontsize=FS_TEXT,
                    color="white" if p < 0.4 else INK2)
            if p <= 0.05:
                ax.add_patch(plt.Rectangle((xu - 0.5, xm - 0.5), 1, 1, fill=False, ec="#d64545", lw=1.6))
    f = df[df.x_unmasked.notna()].copy()
    if len(f):
        f["xu"] = f.x_unmasked.clip(0, q).astype(int)
        f["xm"] = f.x_masked.clip(0, q).astype(int)
        for (xu, xm), g in f.groupby(["xu", "xm"]):
            nconf = int(g.confirmed.sum())
            ax.scatter(xu, xm, s=120 + 60 * len(g), color="#eb6834" if nconf else "#ffffff",
                       edgecolor=INK, lw=1.2, zorder=3, alpha=0.95)
            ax.text(xu, xm, str(len(g)), ha="center", va="center", fontsize=FS_TEXT, fontweight="bold", zorder=4,
                    color="white" if nconf else INK)
            idl = [f"#{e}" for e in g.execution_id.astype(str).tolist()]
            ids = ", ".join(idl[:3]) + ("\n" + ", ".join(idl[3:6]) if len(idl) > 3 else "") + (" …" if len(idl) > 6 else "")
            ax.annotate(ids, (xu, xm), fontsize=FS_TEXT, xytext=(0, -20), textcoords="offset points", ha="center",
                        color=INK, bbox={"boxstyle": "round,pad=0.15", "fc": "white", "ec": "none", "alpha": 0.8}, zorder=5)
    ax.set_xlabel("violating replays WITH suspect records (x_u of 4)")
    ax.set_ylabel("violating replays WITHOUT suspects (x_m of 4)")
    ax.set_xticks(range(q + 1)); ax.set_yticks(range(q + 1))
    ax.grid(False)
    cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    cb.set_label("one-sided Fisher p")
    ax.set_title("Replay confirmation (q = 4)" + TAG + "\nred box: confirmed (p ≤ 0.05); circle: runs (count inside);\norange: quarantined")
    _save(fig, out, "n8n_confirmation")


def plot_cost(df: pd.DataFrame, out: Path) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(12.5, 4.8))
    groups = []
    for wf in ["moneycontrol", "recruiter"]:
        for dfn in ["no defense", "LEDGER"]:
            for fl in [False, True]:
                g = df[(df.workflow == wf) & (df.defense == dfn) & (df.flagged_bool == fl)]
                if dfn == "no defense" and fl:
                    continue
                if len(g) or not fl:
                    groups.append((wf, dfn, fl, g))
    for ax, col, lab in [(axes[0], "llm_calls", "LLM calls per run"), (axes[1], "duration_s", "Wall-clock time per run (s)")]:
        for i, (wf, dfn, fl, g) in enumerate(groups):
            vals = g[col].dropna().to_numpy()
            xs = i + np.linspace(-0.12, 0.12, max(len(vals), 1))[:len(vals)]
            ax.scatter(xs, vals, s=28, color=COLORS[dfn], edgecolor="white", lw=0.6, zorder=3,
                       marker="o" if not fl else "^")
            if len(vals):
                ax.hlines(vals.mean(), i - 0.25, i + 0.25, color=INK, lw=1.4, zorder=4)
                ax.text(i + 0.28, vals.mean(), f"{vals.mean():.0f}", va="center", fontsize=FS_TEXT, color=INK2)
        ax.set_xticks(range(len(groups)))
        ax.set_xticklabels([f"{'news' if wf == 'moneycontrol' else 'recruiter'}\n{'off' if dfn == 'no defense' else 'LEDGER'}\n{'flagged' if fl else 'clean'}"
                            for wf, dfn, fl, _ in groups], fontsize=FS_TEXT)
        ax.set_title(lab)
        ax.set_ylim(bottom=0)
        ax.grid(axis="x", visible=False)
    fig.suptitle("Cost of LEDGER" + TAG + "\n(bar = mean; replays are paid only when Layer F flags a run)")
    fig.tight_layout()
    _save(fig, out, "n8n_cost")


def plot_verdicts(df: pd.DataFrame, out: Path) -> pd.DataFrame:
    tab = pd.crosstab([df.workflow, df.attack_mode, df.defense], df.verdict)
    order = {m: i for i, m in enumerate(MODES)}
    tab = tab.iloc[sorted(range(len(tab)), key=lambda i: (tab.index[i][0], order.get(tab.index[i][1], 99), tab.index[i][2]))]
    fig, ax = plt.subplots(figsize=(10.5, 0.42 * len(tab) + 2.0))
    left = np.zeros(len(tab))
    for v in [c for c in ["V0", "V2", "V3", "OFF"] if c in tab.columns] + [c for c in tab.columns if c not in VERDICT_COLORS]:
        ax.barh(range(len(tab)), tab[v], left=left, color=VERDICT_COLORS.get(v, "#5f6368"), label=VERDICT_LABELS.get(v, v),
                height=0.75)
        left += tab[v].to_numpy()
    ax.set_yticks(range(len(tab)))
    ax.set_yticklabels([f"{'news' if a == 'moneycontrol' else a} | {b} | {c}" for a, b, c in tab.index], fontsize=FS_TEXT)
    ax.invert_yaxis()
    ax.set_xlabel("runs")
    ax.xaxis.get_major_locator().set_params(integer=True)
    ax.legend(ncol=4, loc="upper center", bbox_to_anchor=(0.5, 1.12))
    ax.set_title("Verdicts per cell" + TAG, pad=26)
    _save(fig, out, "n8n_verdicts")
    return tab


def analyze(csv_path: str | Path, out_dir: str | Path = "results/n8n") -> dict:
    set_style()
    out = Path(out_dir)
    (out / "tables").mkdir(parents=True, exist_ok=True)
    (out / "figures").mkdir(parents=True, exist_ok=True)
    df = load_runs(csv_path)
    summ = summary_table(df)
    summ.to_csv(out / "tables" / "n8n_summary.csv", index=False)
    write_tex(summ, out / "tables" / "n8n_summary.tex")
    conf = df[df["flagged_bool"] & df["ledger_enabled"]][
        ["workflow", "execution_id", "attack_mode", "verdict", "x_unmasked", "x_masked", "p_value", "confirmed", "suspects", "violation_reason"]]
    conf.to_csv(out / "tables" / "n8n_confirmation.csv", index=False)
    plot_asr_utility(summ, out / "figures")
    plot_outcome_grid(df, out / "figures")
    plot_confirmation(df, out / "figures")
    plot_cost(df, out / "figures")
    verd = plot_verdicts(df, out / "figures")
    verd.to_csv(out / "tables" / "n8n_verdicts.csv")
    return {"runs": df, "summary": summ, "confirmation": conf, "verdicts": verd}


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else "integrations/n8n/data/ledger_runs.csv"
    res = analyze(path)
    pd.set_option("display.width", 200)
    print(res["summary"][["workflow", "attack_mode", "defense", "n", "ASR", "utility", "flag_rate", "confirm_rate", "llm_calls_mean", "duration_s_mean"]].to_string(index=False))
