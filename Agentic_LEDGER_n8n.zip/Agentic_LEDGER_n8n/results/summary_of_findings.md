# Summary of findings [SIM]

- **pipeline**: ASR none 90.8%, MELON 47.6%, LEDGER 0.8%; UA MELON 47.6% vs LEDGER 88.4%; BU MELON 81.0% vs LEDGER 99.2%; benign LLM calls/task MELON 9.00 vs LEDGER 5.03; false confirmations LEDGER 0.0%.
- **cyclic**: ASR none 90.8%, MELON 46.4%, LEDGER 0.8%; UA MELON 47.0% vs LEDGER 80.1%; BU MELON 81.0% vs LEDGER 99.2%; benign LLM calls/task MELON 9.00 vs LEDGER 5.03; false confirmations LEDGER 0.0%.
- Localisation (top-1 record in poisoned family at first verdict): 89.4%; exactly the injected record: 56.8%; median detection delay 5 events.
- Stealth (in-alphabet value, no visible instruction): LEDGER ASR 0.0% (source-bound extractors).
- Residual threat (adversary controls the designated source): LEDGER ASR 100.0%, as for every defense; influence bounded to 3.46 bits (set-point) / 2.58 bits (vendor).
- RQ2: cosine AUC 0.797; exact pi (FPR, TPR) = (0.071, 0.673); max empirical false-confirmation rate 0.0202 <= alpha_c = 0.05.
- RQ3: persistence with finite record lifetime, R0<1: 0.0%, R0>=1: 27.3%; never-expiring records persist in 86.2% of settings (reservoir effect, delta_r = 0).
- RQ3 flood (N=200): ASR LEDGER (grouping) 0.0% (rho_h 0.1), LEDGER -Grouping 22.5% (rho_h 30.2), No defense 25.0% (rho_h 35.4).