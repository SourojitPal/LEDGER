# ---------------------------------------------------------------------------------------------
# Put your OpenAI API key between the quotes below (it starts with "sk-").
# This is the ONLY place the code reads it from (unless OPENAI_API_KEY is already set in your
# environment, which takes precedence). Do not share or upload this file.
# ---------------------------------------------------------------------------------------------
OPENAI_API_KEY = ""
