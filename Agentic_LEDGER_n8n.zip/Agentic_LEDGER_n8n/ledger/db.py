"""Shared database D with record-level provenance (Sec. III-A).

Each record carries: content, label in {T,U}, writer (agent id or 'external'),
parents (provenance DAG), created_at, expires_at, quarantined, rolled_back.

Ground-truth fields (``payload``, ``tainted_by``) exist only for scoring and
for the simulated agents; the defense never reads them.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Iterable, Tuple, Any

import numpy as np

from .events import T, U, join
from .embed import cosine

MASK_TEXT = "[content withheld by LEDGER for counterfactual re-execution]"


@dataclass
class Record:
    rid: str
    content: str
    label: str
    writer: str
    kind: str
    parents: List[str]
    created_at: int
    expires_at: Optional[int]
    facts: Dict[str, Any] = field(default_factory=dict)
    retrievable: bool = False
    quarantined: bool = False
    rolled_back: bool = False
    # --- ground truth (never visible to the defense) ---
    payload: Optional[Dict[str, Any]] = None
    tainted_by: Set[str] = field(default_factory=set)
    is_seed: bool = False


class SharedDB:
    def __init__(self, embedder, ttl: Optional[int]):
        self.records: Dict[str, Record] = {}
        self.children: Dict[str, Set[str]] = {}
        self.embedder = embedder
        self.ttl = ttl
        self._n = 0
        # quarantine of read edges: (reader, writer) -> (until round, suspect sources). A cut edge hides
        # U records written by `writer` from `reader` only if they descend from the suspect sources.
        self.cut_edges: Dict[Tuple[str, str], Tuple[int, Set[str]]] = {}

    # ---------------------------------------------------------------- writes
    def write(self, writer: str, kind: str, content: str, label: str, parents: Iterable[str],
              round_: int, facts=None, retrievable=False, payload=None, tainted_by=None,
              is_seed=False, ttl: Optional[int] = -1) -> Record:
        self._n += 1
        rid = f"r{self._n}"
        life = self.ttl if ttl == -1 else ttl
        rec = Record(rid=rid, content=content, label=label, writer=writer, kind=kind,
                     parents=list(parents), created_at=round_,
                     expires_at=None if life is None else round_ + life,
                     facts=dict(facts or {}), retrievable=retrievable, payload=payload,
                     tainted_by=set(tainted_by or ()), is_seed=is_seed)
        self.records[rid] = rec
        self.children.setdefault(rid, set())
        for p in rec.parents:
            self.children.setdefault(p, set()).add(rid)
        return rec

    # ---------------------------------------------------------------- reads
    def alive(self, rec: Record, round_: int) -> bool:
        if rec.rolled_back or rec.quarantined:
            return False
        if rec.expires_at is not None and round_ >= rec.expires_at:
            return False
        return True

    def cut(self, reader: str, writer: str, until: int, sources: Iterable[str]) -> None:
        old = self.cut_edges.get((reader, writer), (until, set()))
        self.cut_edges[(reader, writer)] = (max(until, old[0]), set(old[1]) | set(sources))

    def readable_by(self, rec: Record, reader: str, round_: int = 0) -> bool:
        if rec.label != U:
            return True
        c = self.cut_edges.get((reader, rec.writer))
        if c is None or round_ > c[0]:
            return True
        return not (self.ancestors([rec.rid]) & c[1])

    def query(self, round_: int, reader: str, kinds: Iterable[str], writers: Optional[Iterable[str]] = None,
              since: Optional[int] = None) -> List[Record]:
        kinds = set(kinds)
        ws = None if writers is None else set(writers)
        out = []
        for r in self.records.values():
            if r.kind not in kinds or not self.alive(r, round_) or not self.readable_by(r, reader, round_):
                continue
            if ws is not None and r.writer not in ws:
                continue
            if since is not None and r.created_at < since:
                continue
            out.append(r)
        return out

    def retrieve(self, query_text: str, round_: int, reader: str, k: int, kinds: Iterable[str],
                 writers: Optional[Iterable[str]] = None) -> List[Record]:
        """Eq. (4): R(q) = top-k_{m in M} cos(e(q), e(m)) over alive retrievable records."""
        pool = [r for r in self.query(round_, reader, kinds, writers) if r.retrievable]
        if not pool:
            return []
        qv = self.embedder(query_text)
        scored = sorted(pool, key=lambda r: -cosine(qv, self.embedder(r.content)))
        return scored[:k]

    # ------------------------------------------------------------ provenance
    def ancestors(self, rids: Iterable[str]) -> Set[str]:
        seen: Set[str] = set()
        stack = list(rids)
        while stack:
            x = stack.pop()
            if x in seen or x not in self.records:
                continue
            seen.add(x)
            stack.extend(self.records[x].parents)
        return seen

    def descendants(self, rids: Iterable[str]) -> Set[str]:
        """Provenance closure used for rollback (Sec. III-E)."""
        seen: Set[str] = set()
        stack = list(rids)
        while stack:
            x = stack.pop()
            if x in seen:
                continue
            seen.add(x)
            stack.extend(self.children.get(x, ()))
        return seen

    def rollback(self, rids: Iterable[str]) -> Set[str]:
        closure = self.descendants(rids)
        for x in closure:
            if x in self.records:
                self.records[x].rolled_back = True
        return closure

    def quarantine(self, rids: Iterable[str]) -> None:
        for x in rids:
            if x in self.records:
                self.records[x].quarantined = True

    def content_view(self, rec: Record, masked: Set[str]) -> str:
        return MASK_TEXT if rec.rid in masked else rec.content

    # ----------------------------------------------------------- ground truth
    def poisoned_ids(self, round_: Optional[int] = None) -> Set[str]:
        out = set()
        for r in self.records.values():
            if r.tainted_by and (round_ is None or self.alive(r, round_)):
                out.add(r.rid)
        return out

    def active_payload_records(self, round_: int) -> List[Record]:
        return [r for r in self.records.values() if r.payload is not None and self.alive(r, round_)]
