"""Counterfactual confirmation without cosine similarity (Sec. III-E, Contribution 2).

For a blocked action alpha*, LEDGER intersects its provenance with the top-k
localised records to obtain R, maps calls to exact symbols in Sigma, re-runs
*only the affected step* q times with R masked and q times unmasked, and runs a
one-sided Fisher exact test (H0: the symbol pi(alpha*) does not depend on R).

Confirmation (verdict V3) requires: unauthorised action AND untrusted provenance
AND rejection of "no dependence" at level alpha_c.

Bound on false confirmations: under H0 the two arms are exchangeable, so
P(confirm) <= alpha_c (the Fisher test is exact/conservative). The smallest
attainable p-value is 1 / C(2q, q): q=3 -> 0.05, q=4 -> 0.0143, q=5 -> 0.004.
"""
from __future__ import annotations

from math import comb
from typing import List, Tuple

from scipy.stats import fisher_exact

from ..alphabet import Alphabet, ToolCall


def count_symbol(runs: List[List[ToolCall]], symbol: str, alphabet: Alphabet) -> int:
    """Number of re-runs in which the flagged symbol appears (exact match in Sigma)."""
    return sum(1 for calls in runs if any(alphabet.pi(c) == symbol for c in calls))


def fisher_confirm(x_unmasked: int, x_masked: int, q: int, alpha_c: float) -> Tuple[bool, float]:
    table = [[x_unmasked, q - x_unmasked], [x_masked, q - x_masked]]
    _, p = fisher_exact(table, alternative="greater")
    return bool(p <= alpha_c + 1e-12), float(p)


def min_p_value(q: int) -> float:
    return 1.0 / comb(2 * q, q)
