"""Layer T: topology of agent trajectories (Sec. III-D).

For agent a_i with outputs o_1..o_m and frozen encoder phi:
    X_i = {x_k = (phi(o_k), gamma k)}_{k=1..m}                      (Eq. 10)
LEDGER builds the Vietoris-Rips filtration and persistence diagrams Dgm0, Dgm1.

  T1 = largest finite H0 death time  theta_0(X_i)   (semantic discontinuity)
  T2 = longest H1 lifetime
  T3 = Wasserstein distance from Dgm(X_i) to benign reference diagrams

Spanning-path lemma: if consecutive points are at most s apart then theta_0(X_i) <= s,
so T1 above the largest calibrated benign step certifies a trajectory jump.

Pure numpy/scipy implementation (no ripser/gudhi needed): H0 via Kruskal / MST,
H1 via Z/2 column reduction of the Rips boundary matrix up to dimension 2
(m <= ~20 points, so this is cheap).
"""
from __future__ import annotations

from itertools import combinations
from typing import List, Tuple, Dict, Sequence, Optional

import numpy as np
from scipy.optimize import linear_sum_assignment
from scipy.spatial.distance import pdist, squareform

Diagram = List[Tuple[float, float]]


def trajectory_points(embs: Sequence[np.ndarray], gamma: float) -> np.ndarray:
    if len(embs) == 0:
        return np.zeros((0, 1))
    X = np.stack(embs)
    k = np.arange(len(embs), dtype=float)[:, None] * gamma
    return np.hstack([X, k])


def _find(parent, x):
    while parent[x] != x:
        parent[x] = parent[parent[x]]
        x = parent[x]
    return x


def h0_diagram(D: np.ndarray) -> Diagram:
    n = D.shape[0]
    if n < 2:
        return []
    edges = sorted((D[i, j], i, j) for i in range(n) for j in range(i + 1, n))
    parent = list(range(n))
    dgm = []
    for w, i, j in edges:
        ri, rj = _find(parent, i), _find(parent, j)
        if ri != rj:
            parent[ri] = rj
            dgm.append((0.0, float(w)))
            if len(dgm) == n - 1:
                break
    return dgm


def h1_diagram(D: np.ndarray) -> Diagram:
    """Persistent H1 of the Vietoris-Rips filtration (standard Z/2 reduction)."""
    n = D.shape[0]
    if n < 3:
        return []
    edges = [(D[i, j], (i, j)) for i, j in combinations(range(n), 2)]
    edges.sort()
    eidx = {e: k for k, (_, e) in enumerate(edges)}
    tris = []
    for i, j, k in combinations(range(n), 3):
        tris.append((max(D[i, j], D[i, k], D[j, k]), (i, j, k)))
    tris.sort()
    # reduce boundary columns of triangles (rows = edges in filtration order)
    low_to_col: Dict[int, int] = {}
    cols: List[set] = []
    pairs = []
    for c, (val, (i, j, k)) in enumerate(tris):
        col = {eidx[(i, j)], eidx[(i, k)], eidx[(j, k)]}
        while col:
            low = max(col)
            if low in low_to_col:
                col ^= cols[low_to_col[low]]
            else:
                break
        cols.append(col)
        if col:
            low = max(col)
            low_to_col[low] = c
            b = edges[low][0]
            if val > b:
                pairs.append((float(b), float(val)))
    # edges that create cycles but are never killed would be essential; in a full Rips
    # complex every 1-cycle dies, so all H1 classes are captured by ``pairs``.
    return pairs


def wasserstein(d1: Diagram, d2: Diagram, p: int = 1) -> float:
    """p-Wasserstein distance between persistence diagrams (L_inf ground metric,
    points may be matched to the diagonal)."""
    a = np.array(d1, dtype=float).reshape(-1, 2)
    b = np.array(d2, dtype=float).reshape(-1, 2)
    na, nb = len(a), len(b)
    if na == 0 and nb == 0:
        return 0.0
    n = na + nb
    C = np.zeros((n, n))
    big = 1e9
    if na and nb:
        C[:na, :nb] = np.max(np.abs(a[:, None, :] - b[None, :, :]), axis=2) ** p
    diag_a = ((a[:, 1] - a[:, 0]) / 2.0) ** p if na else np.zeros(0)
    diag_b = ((b[:, 1] - b[:, 0]) / 2.0) ** p if nb else np.zeros(0)
    if na:
        C[:na, nb:] = big
        C[np.arange(na), nb + np.arange(na)] = diag_a
    if nb:
        C[na:, :nb] = big
        C[na + np.arange(nb), np.arange(nb)] = diag_b
    r, c = linear_sum_assignment(C)
    return float(C[r, c].sum() ** (1.0 / p))


class TopologyLayer:
    def __init__(self, gamma: float, traj_len: int, max_refs: int = 8):
        self.gamma = gamma
        self.traj_len = traj_len
        self.refs: Dict[str, List[Tuple[Diagram, Diagram]]] = {}
        self.max_refs = max_refs

    def diagrams(self, embs: Sequence[np.ndarray]) -> Tuple[Diagram, Diagram, np.ndarray]:
        X = trajectory_points(list(embs)[-self.traj_len:], self.gamma)
        if len(X) < 2:
            return [], [], X
        D = squareform(pdist(X))
        return h0_diagram(D), h1_diagram(D), X

    def scores(self, role: str, embs: Sequence[np.ndarray]) -> Tuple[float, float, float]:
        h0, h1, _ = self.diagrams(embs)
        t1 = max((d for _, d in h0), default=0.0)
        t2 = max((d - b for b, d in h1), default=0.0)
        refs = self.refs.get(role, [])
        if refs:
            t3 = float(np.mean([wasserstein(h0, r0) + wasserstein(h1, r1) for r0, r1 in refs]))
        else:
            t3 = 0.0
        return t1, t2, t3

    def add_reference(self, role: str, embs: Sequence[np.ndarray]) -> None:
        lst = self.refs.setdefault(role, [])
        if len(lst) < self.max_refs and len(embs) >= 3:
            h0, h1, _ = self.diagrams(embs)
            lst.append((h0, h1))


def max_consecutive_step(X: np.ndarray) -> float:
    if len(X) < 2:
        return 0.0
    return float(np.max(np.linalg.norm(np.diff(X, axis=0), axis=1)))


def corroborate(post_points: Dict[str, List[np.ndarray]], scale: float) -> bool:
    """Cross-agent corroboration: do post-alarm outputs of >= 2 agents that read the
    candidate record fall into one H0 cluster at the benign scale?"""
    pts, owner = [], []
    for a, P in post_points.items():
        for p in P:
            pts.append(p)
            owner.append(a)
    if len(set(owner)) < 2:
        return False
    X = np.stack(pts)
    D = squareform(pdist(X))
    n = len(pts)
    parent = list(range(n))
    for i in range(n):
        for j in range(i + 1, n):
            if D[i, j] <= scale:
                ri, rj = _find(parent, i), _find(parent, j)
                if ri != rj:
                    parent[ri] = rj
    comps: Dict[int, set] = {}
    for i in range(n):
        comps.setdefault(_find(parent, i), set()).add(owner[i])
    return any(len(s) >= 2 for s in comps.values())
