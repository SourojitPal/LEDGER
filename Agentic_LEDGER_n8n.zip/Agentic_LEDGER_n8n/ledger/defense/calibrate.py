"""Calibration (Sec. III-E): conformal p-values with Bonferroni control, Page CUSUM.

    p_z = (1 + |{j : z_j >= z}|) / (N + 1),      alarm  iff  min_k p_k <= alpha / K   (Eq. 11)

Calibration scores z_j are the *per-run maxima* of each statistic over benign
calibration runs of the same task template. Comparing every online value with
the distribution of benign run-maxima makes the run-level false-alarm rate
<= alpha under exchangeability (a statistical alarm is *not* an IPI verdict; it only
gates quarantine and confirmation).
"""
from __future__ import annotations

from typing import Dict, List, Sequence

import numpy as np


def conformal_p(z: float, calib: Sequence[float]) -> float:
    calib = np.asarray(calib, dtype=float)
    return float((1 + np.sum(calib >= z)) / (len(calib) + 1))


class Calibrator:
    def __init__(self, names: Sequence[str]):
        self.names = list(names)
        self.scores: Dict[str, List[float]] = {n: [] for n in names}
        self._sorted: Dict[str, np.ndarray] = {}
        self.mu: Dict[str, float] = {}
        self.sd: Dict[str, float] = {}

    def add_run(self, run_max: Dict[str, float]) -> None:
        for n in self.names:
            if n in run_max:
                self.scores[n].append(float(run_max[n]))

    def freeze(self) -> None:
        for n in self.names:
            arr = np.sort(np.asarray(self.scores[n], dtype=float))
            self._sorted[n] = arr
            self.mu[n] = float(arr.mean()) if len(arr) else 0.0
            self.sd[n] = float(arr.std() + 1e-9) if len(arr) else 1.0

    def p_value(self, name: str, z: float) -> float:
        arr = self._sorted.get(name)
        if arr is None or len(arr) == 0:
            return 1.0
        n_ge = len(arr) - np.searchsorted(arr, z, side="left")
        return float((1 + n_ge) / (len(arr) + 1))

    def min_p(self, values: Dict[str, float]) -> (float, str):
        best, arg = 1.0, ""
        for n, z in values.items():
            p = self.p_value(n, z)
            if p < best:
                best, arg = p, n
        return best, arg

    @property
    def n(self) -> int:
        return min((len(v) for v in self.scores.values()), default=0)


class PageCUSUM:
    """g_t = max(0, g_{t-1} + z_t - k); alarm when g_t > h (h calibrated on benign runs)."""

    def __init__(self, k: float = 0.5, h: float = 5.0):
        self.k, self.h, self.g = k, h, 0.0

    def update(self, z: float) -> bool:
        self.g = max(0.0, self.g + z - self.k)
        return self.g > self.h

    def reset(self) -> None:
        self.g = 0.0
