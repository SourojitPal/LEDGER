"""Defenses compared in the paper.

* ``NoDefense``
* ``Melon``        - masked re-execution at *every* agent step; a call is flagged when
                     cos(e(a_t), e(a~_t)) > theta (Eq. 3); a flagged step is stopped.
* ``MelonExact``   - identical, but the cosine test is replaced by exact symbol
                     equality pi(a_t) == pi(a~_t) (isolates Contribution 2 inside MELON).
* ``AgentGraph``   - agent-level spectral monitor (Eq. 5 / CASPIAN-style): alarms on the
                     agent graph, contains by resetting/isolating the most-changed agent;
                     no record localisation, no rollback, no action gate.
* ``Ledger``       - the proposed defense: Layer F gate (V2) -> alarm-gated
                     counterfactual confirmation (V3) -> rollback + quarantine; Layers S/T
                     anomaly alarms (V1) -> quarantine + hold of high-risk actions;
                     reviewer requests grouped by source record.

Verdicts: V0 benign, V1 anomaly, V2 violation (blocked), V3 confirmed IPI.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Set, Tuple, Any

import numpy as np

from ..alphabet import Alphabet, ToolCall
from ..embed import cosine
from ..events import EventLog, U, T
from .layer_f import Monitor, PlanDAG
from .layer_s import SpectralLayer, localize, r0_hat, rates_from_cfg, quarantine_cut, expected_access
from .layer_t import TopologyLayer
from .confirm import count_symbol, fisher_confirm
from .calibrate import PageCUSUM


@dataclass
class StepCtx:
    agent: str
    task: Any
    plan: PlanDAG
    records: List[Any]                     # Record objects read in this step
    label: str
    round: int
    rerun: Callable[[Set[str], bool], Any]  # (mask ids, masked_task) -> StepOutput


class BaseDefense:
    name = "none"
    grouping = False

    def __init__(self, cfg, alphabet: Alphabet, agents: List[str], db, log: EventLog, calib=None):
        self.cfg, self.alphabet, self.agents, self.db, self.log, self.calib = cfg, alphabet, agents, db, log, calib
        self.cost = {"rerun_calls": 0, "melon_calls": 0, "embed_calls": 0, "rerun_prompt_tokens": 0,
                     "rerun_completion_tokens": 0, "rerun_latency_s": 0.0, "cpu_s": 0.0}
        self.verdicts: List[Dict[str, Any]] = []
        self.series: List[Dict[str, Any]] = []
        self.skip_until: Dict[str, int] = {}
        self.reset_round: Dict[str, int] = {}

    # hooks ------------------------------------------------------------------
    def on_round(self, r: int, task, plan: PlanDAG) -> None:
        pass

    def on_externals(self, r: int, task, plan: PlanDAG, db) -> None:
        pass

    def skip_agent(self, agent: str, r: int) -> bool:
        return self.skip_until.get(agent, -1) >= r

    def context_since(self, agent: str) -> int:
        return self.reset_round.get(agent, -10 ** 9)

    def check_write(self, agent: str, kind: str, plan: PlanDAG) -> bool:
        return True

    def melon(self, sc: StepCtx, calls: List[ToolCall]) -> bool:
        return False

    def gate(self, sc: StepCtx, call: ToolCall) -> str:
        return "allow"

    def after_step(self, sc: StepCtx, out, out_emb: np.ndarray) -> None:
        pass

    def end_round(self, r: int) -> None:
        pass

    # helpers ----------------------------------------------------------------
    def _account(self, outs) -> None:
        for o in outs:
            self.cost["rerun_prompt_tokens"] += o.prompt_tokens
            self.cost["rerun_completion_tokens"] += o.completion_tokens
            self.cost["rerun_latency_s"] += o.latency_s

    def _verdict(self, r: int, v: str, **kw) -> None:
        d = {"round": r, "t": self.log.now, "verdict": v}
        d.update(kw)
        self.verdicts.append(d)
        self.log.emit(r, "alarm" if v == "V1" else ("confirm" if v == "V3" else "block"), verdict=v,
                      agent=kw.get("agent", ""), info={k: v2 for k, v2 in kw.items() if k != "agent"})


class NoDefense(BaseDefense):
    name = "none"


class Melon(BaseDefense):
    name = "melon"
    exact = False

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.bank: Dict[str, List[ToolCall]] = {}
        self.embedder = self.db.embedder
        self.scores: List[Tuple[float, bool]] = []

    def _similar(self, a: ToolCall, b: ToolCall) -> Tuple[bool, float]:
        if self.exact:
            m = self.alphabet.match(a, b)
            return m, 1.0 if m else 0.0
        self.cost["embed_calls"] += 2
        s = cosine(self.embedder(a.text()), self.embedder(b.text()))
        return s > self.cfg.melon_theta, s

    def melon(self, sc: StepCtx, calls: List[ToolCall]) -> bool:
        t0 = time.perf_counter()
        masked = sc.rerun(set(), True)       # one masked re-execution per agent step (~2T calls)
        self.cost["melon_calls"] += 1
        self._account([masked])
        bank = self.bank.setdefault(sc.agent, [])
        from ..scenario import approval_call
        for mc in masked.calls + [approval_call(c) for c, _ in masked.approvals]:
            if all(mc.text() != b.text() for b in bank):
                bank.append(mc)
        flagged = False
        best = -1.0
        for oc in calls:
            for mc in bank:
                hit, s = self._similar(oc, mc)
                best = max(best, s)
                if hit:
                    flagged = True
                    break
            if flagged:
                break
        if calls:
            self.scores.append((best, flagged))
        self.cost["cpu_s"] += time.perf_counter() - t0
        if flagged:
            self._verdict(sc.round, "V2", agent=sc.agent, reason="melon-similar", score=best)
            self.log.emit(sc.round, "melon_abort", agent=sc.agent)
        return flagged


class MelonExact(Melon):
    name = "melon_exact"
    exact = True


class _SpectralMixin:
    def _init_spectral(self):
        self.spec = SpectralLayer(self.agents)
        if self.calib is not None and self.calib.L_bar is not None:
            self.spec.L_bar = self.calib.L_bar
            self.spec.lam2_bar = self.calib.lam2_bar
        h = self.calib.cusum_h if self.calib is not None else 5.0
        self.cusum = PageCUSUM(self.cfg.cusum_k, h)
        self.delta_a, self.delta_r = rates_from_cfg(self.cfg)
        self.beta_r_hat = self.calib.beta_r_hat if self.calib is not None else 0.5
        self.beta_w_hat = self.calib.beta_w_hat if self.calib is not None else 0.5

    def _window(self, r: int):
        return self.spec.window(self.log.events, r, self.cfg.window, self.db)

    def _z_s1(self, s1: float) -> float:
        if self.calib is None:
            return 0.0
        return (s1 - self.calib.s1_mu) / (self.calib.s1_sd + 1e-9)


class AgentGraph(BaseDefense, _SpectralMixin):
    """Agent-level baseline: same spectral score, but the unit of containment is the agent."""
    name = "agent_graph"

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self._init_spectral()
        self.alarm_until = -1

    def after_step(self, sc: StepCtx, out, out_emb) -> None:
        t0 = time.perf_counter()
        ws = self._window(sc.round)
        s1 = self.spec.S1(ws)
        p = self.calib.calib.p_value("S1", s1) if (self.calib is not None and self.calib.calib is not None) else 1.0
        cus = self.cusum.update(self._z_s1(s1))
        if (p <= self.cfg.alpha or cus) and sc.round > self.alarm_until:
            # isolate the agent whose weighted degree deviates most from the benign reference
            deg = ws.W.sum(axis=1)[:len(self.agents)]
            ref = (self.calib.W_bar.sum(axis=1)[:len(self.agents)] if self.calib is not None
                   else np.zeros(len(self.agents)))
            a = self.agents[int(np.argmax(np.abs(deg - ref)))]
            self.skip_until[a] = sc.round + 1
            self.reset_round[a] = sc.round + 1
            self.alarm_until = sc.round + self.cfg.window
            self.cusum.reset()
            self._verdict(sc.round, "V1", agent=a, stat="S1" if p <= self.cfg.alpha else "CUSUM", p=p)
            self.log.emit(sc.round, "agent_reset", agent=a)
        self.series.append({"round": sc.round, "agent": sc.agent, "lam2": ws.lam2, "S1": s1})
        self.cost["cpu_s"] += time.perf_counter() - t0


class Ledger(BaseDefense, _SpectralMixin):
    name = "ledger"

    def __init__(self, *a, observe_only: bool = False, **kw):
        super().__init__(*a, **kw)
        self.grouping = self.cfg.use_grouping
        self.observe_only = observe_only
        self.monitor = Monitor(self.alphabet)
        self._init_spectral()
        self.topo = TopologyLayer(self.cfg.traj_gamma, self.cfg.traj_len)
        if self.calib is not None:
            self.topo.refs = self.calib.t_refs
        # trajectories per (agent, task template), warm-started with benign history so that
        # T1-T3 compare like with like ("calibrated on benign runs of the same task template")
        self.traj: Dict[str, List[np.ndarray]] = {}
        if self.calib is not None and getattr(self.calib, "warm", None):
            self.traj = {k: list(v) for k, v in self.calib.warm.items()}
        self.alarm_until = -1
        self.suspects: Set[str] = set()
        self.first_alarm: Optional[Dict[str, Any]] = None
        self.localised_top1: List[Tuple[int, str]] = []
        self.rolled_back: Set[str] = set()
        self.run_max: Dict[str, float] = {}
        self.last_ws = None
        self.Ls: List[np.ndarray] = []     # observe-only: Laplacians for L_bar
        self.Ws: List[np.ndarray] = []
        self.recent_confirm: Dict[Tuple[str, str], int] = {}   # (agent, symbol) -> round of last V3
        self.recent_tested: Dict[Tuple[str, str], int] = {}    # (agent, symbol) -> round of last test
        self.run_min_p = 1.0

    # ------------------------------------------------------------------ hooks
    def on_round(self, r: int, task, plan: PlanDAG) -> None:
        self.monitor.load(plan)
        self.plan = plan
        if r > self.alarm_until:
            self.suspects = set()         # suspicion expires with the alarm window

    def on_externals(self, r: int, task, plan: PlanDAG, db) -> None:
        if self.cfg.use_layer_f and self.cfg.bind_extractors and not self.observe_only:
            from ..scenario import system_extract
            recs = [x for x in db.records.values() if x.created_at == r]
            self.monitor.bind(task.tid, system_extract(task, plan, recs))

    def check_write(self, agent: str, kind: str, plan: PlanDAG) -> bool:
        if not self.cfg.use_layer_f or self.observe_only:
            return True
        return self.monitor.check_write(plan, agent, kind)

    def gate(self, sc: StepCtx, call: ToolCall) -> str:
        if self.observe_only:
            return "allow"
        t0 = time.perf_counter()
        try:
            prov = self._u_provenance(sc)
            if self.cfg.use_layer_f:
                ok, reason = self.monitor.check(sc.task.tid, sc.agent, call, sc.label)
                if not ok:
                    sym = self.alphabet.pi(call)
                    fixed = (self.monitor.repair(sc.task.tid, sc.agent, call)
                             if self.cfg.bind_extractors else None)
                    self._verdict(sc.round, "V2", agent=sc.agent, symbol=sym,
                                  reason="source-binding" if fixed is not None else reason)
                    last = self.recent_tested.get((sc.agent, sym))
                    if last is not None and sc.round - last < self.cfg.window:
                        pass        # same violation already tested in this window: block, no new re-runs
                    elif self.cfg.use_confirm and prov:
                        self.cost["cpu_s"] += time.perf_counter() - t0
                        t0 = time.perf_counter()
                        self._confirm(sc, call, prov)
                    if fixed is not None:
                        return ("repair", fixed)   # system fills the slot with chi(designated source)
                    return "block"
                if reason == "approved-by-reviewer":
                    return "allow"            # human override: a local decision by h is final
            if self.alphabet.is_hc(call) and prov:
                if self.cfg.always_confirm:
                    if self._dependence_on_suspects(sc, call, prov):
                        self._verdict(sc.round, "V1", agent=sc.agent, stat="always-confirm",
                                      symbol=self.alphabet.pi(call))
                        return "hold"
                elif sc.round <= self.alarm_until and (prov & self.suspects):
                    # V1: pause the high-risk action and re-derive the step once with the suspects
                    # masked (chain replay). Same symbol -> release; same tool, other args -> repair.
                    return self._hold_or_repair(sc, call, prov & self.suspects)
            return "allow"
        finally:
            self.cost["cpu_s"] += time.perf_counter() - t0

    def after_step(self, sc: StepCtx, out, out_emb: np.ndarray) -> None:
        t0 = time.perf_counter()
        key = f"{sc.agent}:{sc.task.kind}"
        self.traj.setdefault(key, []).append(out_emb)
        stats: Dict[str, float] = {}
        ws = self._window(sc.round)
        self.last_ws = ws
        if self.observe_only:
            self.Ls.append(ws.L)
            self.Ws.append(ws.W)
        s1 = self.spec.S1(ws)
        if self.cfg.use_layer_s:
            stats["S1"] = s1
        t1 = t2 = t3 = 0.0
        if self.cfg.use_layer_t and len(self.traj[key]) >= 3:
            t1, t2, t3 = self.topo.scores(key, self.traj[key])
            stats[f"T1:{key}"] = t1
            stats[f"T2:{key}"] = t2
            stats[f"T3:{key}"] = t3
        r0 = r0_hat(ws.rho_RW, self.beta_r_hat, self.beta_w_hat, self.delta_a, self.delta_r)
        z = self._z_s1(s1)
        cus = self.cusum.update(z) if self.cfg.use_layer_s else False
        for k, v in stats.items():
            self.run_max[k] = max(self.run_max.get(k, -1e9), v)
        self.run_max["CUSUM"] = max(self.run_max.get("CUSUM", 0.0), self.cusum.g)
        top, ipr, sig = localize(ws.B, ws.records, self.cfg.top_k_local, self._expected(ws))
        p_min, which = (1.0, "")
        if self.calib is not None and self.calib.calib is not None and stats:
            p_min, which = self.calib.calib.min_p(stats)
        K = max(1, (1 if self.cfg.use_layer_s else 0) + (3 if self.cfg.use_layer_t else 0))
        tau = getattr(self.calib, "tau", None) if self.calib is not None else None
        level = tau if tau is not None else self.cfg.alpha / K   # run-level conformal threshold
        self.run_min_p = min(self.run_min_p, p_min)
        alarm = (p_min <= level) or cus
        self.series.append({"round": sc.round, "agent": sc.agent, "t": self.log.now, "lam2": ws.lam2, "S1": s1,
                            "HW_rhs": self.spec.hoffman_wielandt_rhs(ws), "R0": r0, "rho_RW": ws.rho_RW,
                            "IPR": ipr, "sigma1": sig, "T1": t1, "T2": t2, "T3": t3, "cusum": self.cusum.g,
                            "p_min": p_min, "alarm": bool(alarm)})
        if alarm and not self.observe_only and (self.cfg.use_layer_s or self.cfg.use_layer_t):
            new = sc.round > self.alarm_until
            stat = which if p_min <= level else "CUSUM"
            self.suspects |= set(top)
            self.alarm_until = sc.round + self.cfg.window
            if new:
                self._verdict(sc.round, "V1", agent=sc.agent, stat=stat, p=p_min, top=list(top), ipr=ipr)
                if top:
                    self.localised_top1.append((sc.round, top[0]))
                if self.first_alarm is None:
                    self.first_alarm = {"t": self.log.now, "round": sc.round, "top": list(top)}
                if self.cfg.use_quarantine:
                    self._quarantine(sc.round, top[:1], ws)
            self.cusum.reset()
        self.cost["cpu_s"] += time.perf_counter() - t0

    # --------------------------------------------------------------- internals
    def screen_requests(self, r: int, requests):
        """V1 also pauses escalations: a burst of approval requests (more than the suspicious-card
        size) whose untrusted sources are current suspects or quarantined is withheld from h and
        logged, instead of being queued on the reviewer."""
        if self.observe_only or not self.cfg.use_grouping:
            return requests
        bad = self.suspects | {x for x, rec in self.db.records.items() if rec.quarantined}
        groups: Dict[frozenset, list] = {}
        for rq in requests:
            groups.setdefault(rq.sources, []).append(rq)
        keep = []
        for src, lst in groups.items():
            if len(lst) > self.cfg.group_suspicious_size and (src & bad):
                self._verdict(r, "V1", agent="h", stat="escalation-hold", top=sorted(src & bad), n=len(lst))
                continue
            keep += lst
        return keep

    def on_reviewer_reject(self, r: int, sources) -> None:
        """A suspicious grouped card rejected by h is human evidence against its source records."""
        if self.observe_only or not sources:
            return
        srcs = [x for x in sources if x in self.db.records]
        self.suspects |= set(srcs)
        self._verdict(r, "V1", agent="h", stat="reviewer-reject", top=srcs)
        if self.cfg.use_quarantine:
            self.db.quarantine(srcs)
            self.log.emit(r, "quarantine", agent="h", info={"records": srcs})

    def _u_provenance(self, sc: StepCtx) -> Set[str]:
        ids = [r.rid for r in sc.records]
        anc = self.db.ancestors(ids)
        return {x for x in anc if self.db.records[x].label == U}

    def _expected(self, ws):
        base = getattr(self.calib, "read_baseline", None) if self.calib is not None else None
        return expected_access(ws.records, self.agents, self.db, base)

    def _localised(self, r: int) -> List[str]:
        ws = self.last_ws if self.last_ws is not None else self._window(r)
        top, _, _ = localize(ws.B, ws.records, self.cfg.top_k_local, self._expected(ws))
        return top

    def _arms(self, sc: StepCtx, mask: Set[str]):
        q = self.cfg.q
        un = [sc.rerun(set(), False) for _ in range(q)]
        ma = [sc.rerun(mask, False) for _ in range(q)]
        # masked arm re-derives the descendants of R in the step context (chain replay)
        self.cost["rerun_calls"] += 2 * q + sum(getattr(o, "extra_calls", 0) for o in ma)
        self._account(un + ma)
        self.log.emit(sc.round, "read", agent=sc.agent, info={"replay": True, "n": 2 * q})
        return un, ma

    def _test(self, sc: StepCtx, call: ToolCall, mask: Set[str], alpha: float):
        """Curtailed one-sided Fisher test. Re-runs are drawn one at a time (unmasked arm first, it
        needs no chain replay) and stop as soon as rejection at level alpha has become impossible.
        The decision equals that of the full q-vs-q test; only the number of LLM calls changes."""
        q = self.cfg.q
        outs_u, outs_m = [], []
        x_u = x_m = 0
        n_calls = 0

        def can_reject(xu, nu, xm, nm):
            best_u, best_m = xu + (q - nu), xm          # remaining unmasked hit, remaining masked miss
            return fisher_confirm(best_u, best_m, q, alpha)[0]

        for i in range(q):
            o = sc.rerun(set(), False)
            outs_u.append(o)
            n_calls += 1
            x_u += self._count([o], call)
            if not can_reject(x_u, i + 1, 0, 0):
                break
        if can_reject(x_u, len(outs_u), 0, 0):
            for j in range(q):
                o = sc.rerun(mask, False)
                outs_m.append(o)
                n_calls += 1 + getattr(o, "extra_calls", 0)
                x_m += self._count([o], call)
                if not can_reject(x_u, q, x_m, j + 1):
                    break
        self.cost["rerun_calls"] += n_calls
        self._account(outs_u + outs_m)
        self.log.emit(sc.round, "read", agent=sc.agent, info={"replay": True, "n": len(outs_u) + len(outs_m)})
        if len(outs_u) < q or len(outs_m) < q:
            return False, 1.0, x_u, x_m
        ok, p = fisher_confirm(x_u, x_m, q, alpha)
        return ok, p, x_u, x_m

    def _confirm(self, sc: StepCtx, call: ToolCall, prov: Set[str]) -> bool:
        """Alarm-gated counterfactual test (Sec. III-E). Returns True on V3."""
        sym = self.alphabet.pi(call)
        anc_rank = self._rank_ancestors(prov)
        top_list = [x for x in anc_rank] + [x for x in self._localised(sc.round) if x not in anc_rank]
        top = set(anc_rank) | (set(self._localised(sc.round)) & prov) | (self.suspects & prov)
        R1 = prov & top
        direct = {r.rid for r in sc.records if r.label == U}
        tests = [(R1, "localised")] if R1 else []
        if direct and direct != R1:
            tests.append((direct, "context"))
        alpha_each = self.cfg.alpha_c / len(tests)       # Bonferroni over sequential suspect sets
        self.recent_tested[(sc.agent, sym)] = sc.round
        for R, how in tests:
            ok, p, x_u, x_m = self._test(sc, call, set(R), alpha_each)
            if ok:
                first_read = min((e.t for e in self.log.events if e.type == "read" and e.record in R), default=-1)
                rank = {x: i for i, x in enumerate(top_list)}
                ordered = sorted(R, key=lambda x: (rank.get(x, 99), -int(x[1:])))
                self._verdict(sc.round, "V3", agent=sc.agent, symbol=sym, records=ordered, how=how, p=p,
                              x_unmasked=x_u, x_masked=x_m, first_read=first_read)
                self.localised_top1.append((sc.round, ordered[0]))
                if self.first_alarm is None:
                    self.first_alarm = {"t": self.log.now, "round": sc.round, "top": ordered}
                if self.cfg.use_rollback:
                    closure = self.db.rollback(R)
                    self.rolled_back |= closure
                    self.log.emit(sc.round, "rollback", agent=sc.agent, info={"n": len(closure)})
                if self.cfg.use_quarantine and self.last_ws is not None:
                    self._quarantine(sc.round, [], self.last_ws)
                self.suspects |= set(R)
                self.alarm_until = sc.round + self.cfg.window
                self.recent_confirm[(sc.agent, sym)] = sc.round
                return True
        return False

    def _rank_ancestors(self, prov: Set[str]) -> List[str]:
        """Rank untrusted ancestors by how much more they are read than records of their kind
        normally are (residual of B over the record's lifetime); top-k with positive residual."""
        from .layer_s import record_key
        base = getattr(self.calib, "read_baseline", None) if self.calib is not None else None
        if not prov:
            return []
        reads: Dict[str, Dict[str, int]] = {}
        for e in self.log.events:
            if e.type == "read" and e.record in prov and e.agent in self.agents:
                reads.setdefault(e.record, {}).setdefault(e.agent, 0)
                reads[e.record][e.agent] += 1
        now = max((e.round for e in self.log.events), default=0)
        scores = {}
        for rid, per in reads.items():
            rec = self.db.records[rid]
            alive = max(1, now - rec.created_at + 1)
            sc_ = 0.0
            for a, n in per.items():
                exp = base.get((record_key(rec), a), 0.0) if base else 0.0
                sc_ += max(0.0, n / alive - exp)
            if sc_ > 1e-9:
                scores[rid] = sc_ * len(per)          # widely read *and* above its kind's rate
        ranked = sorted(scores, key=lambda x: (-scores[x], -int(x[1:])))
        return ranked[: self.cfg.top_k_local]

    def _hold_or_repair(self, sc: StepCtx, call: ToolCall, R: Set[str]):
        key = (sc.round, sc.agent, frozenset(R))
        cache = getattr(sc, "_masked_cache", None)
        if cache is None or cache[0] != key:
            out = sc.rerun(set(R), False)
            self.cost["rerun_calls"] += 1 + getattr(out, "extra_calls", 0)
            self._account([out])
            sc._masked_cache = (key, out)
        out = sc._masked_cache[1]
        sym = self.alphabet.pi(call)
        if any(self.alphabet.pi(c) == sym for c in out.calls):
            return "allow"
        alt = [c for c in out.calls if c.tool == call.tool]
        self._verdict(sc.round, "V1", agent=sc.agent, stat="hold", symbol=sym, records=sorted(R))
        self.log.emit(sc.round, "hold", agent=sc.agent, symbol=sym)
        if alt:
            return ("repair", alt[0])
        return "hold"

    def _count(self, outs, call: ToolCall) -> int:
        """Runs whose calls contain the flagged action: exact symbol equality (LEDGER) or,
        for the RQ2 ablation, MELON-style cosine > theta."""
        if getattr(self.cfg, "confirm_compare", "exact") == "cosine":
            e = self.db.embedder
            ref = e(call.text())
            self.cost["embed_calls"] += 1 + sum(len(o.calls) for o in outs)
            return sum(1 for o in outs if any(cosine(ref, e(c.text())) > self.cfg.melon_theta for c in o.calls))
        return count_symbol([o.calls for o in outs], self.alphabet.pi(call), self.alphabet)

    def _dependence_on_suspects(self, sc: StepCtx, call: ToolCall, prov: Set[str]) -> bool:
        """Ablation 'always-confirm': run the counterfactual test on every HC action with U provenance."""
        sym = self.alphabet.pi(call)
        R = prov & set(self._localised(sc.round))
        if not R:
            return False
        ok, _, _, _ = self._test(sc, call, set(R), self.cfg.alpha_c)
        return ok

    def _quarantine(self, r: int, records: List[str], ws) -> None:
        if records:
            self.db.quarantine(records)
            self.log.emit(r, "quarantine", info={"records": list(records)})
        # cut reader<-writer edges until R0 < 1  (Sec. III-E)
        pairs: Dict[Tuple[str, str], float] = {}
        for i, a in enumerate(self.agents):
            for c, rid in enumerate(ws.records):
                w = self.db.records[rid].writer
                if ws.R[i, c] > 0 and w in self.agents:
                    pairs[(a, w)] = pairs.get((a, w), 0.0) + ws.R[i, c] / max(1, self.cfg.window)
        cuts, r0_after = quarantine_cut(pairs, self.agents, self.beta_r_hat, self.beta_w_hat,
                                        self.delta_a, self.delta_r)
        for c in cuts:
            self.db.cut(c[0], c[1], r + 2 * self.cfg.window, self.suspects | set(records))
        if cuts:
            self.log.emit(r, "quarantine", info={"cut_edges": cuts, "R0_after": r0_after})


class Probe(BaseDefense):
    """Records, for every agent step with tool calls, the MELON comparison between the
    original and the masked (u -> u~) run under both rules, without intervening."""
    name = "probe"

    def __init__(self, *a, attack=None, **kw):
        super().__init__(*a, **kw)
        self.rows: List[Dict[str, Any]] = []
        self.attack = attack

    def melon(self, sc: StepCtx, calls: List[ToolCall]) -> bool:
        if not calls:
            return False
        from ..scenario import approval_call, attacker_goal
        masked = sc.rerun(set(), True)
        mcalls = masked.calls + [approval_call(c) for c, _ in masked.approvals]
        e = self.db.embedder
        for oc in calls:
            cos = max((cosine(e(oc.text()), e(mc.text())) for mc in mcalls), default=0.0)
            ex = any(self.alphabet.match(oc, mc) for mc in mcalls)
            harmful = bool(self.attack) and (attacker_goal(self.attack, [oc]) or bool(oc.meta.get("harmful"))
                                             or bool(oc.args.get("_inj")))
            self.rows.append({"agent": sc.agent, "round": sc.round, "tool": oc.tool, "cosine": cos,
                              "exact": ex, "attack_driven": harmful, "attack": self.attack or "benign"})
        return False


def make_defense(name: str, cfg, alphabet, agents, db, log, calib=None, observe_only=False) -> BaseDefense:
    if name == "none":
        return NoDefense(cfg, alphabet, agents, db, log, calib)
    if name == "melon":
        return Melon(cfg, alphabet, agents, db, log, calib)
    if name == "melon_exact":
        return MelonExact(cfg, alphabet, agents, db, log, calib)
    if name == "agent_graph":
        return AgentGraph(cfg, alphabet, agents, db, log, calib)
    if name == "probe":
        return Probe(cfg, alphabet, agents, db, log, calib)
    if name == "ledger":
        return Ledger(cfg, alphabet, agents, db, log, calib, observe_only=observe_only)
    raise ValueError(name)
