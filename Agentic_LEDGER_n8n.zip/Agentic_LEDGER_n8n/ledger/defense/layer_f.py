"""Layer F: formal admissibility and taint prevention (Sec. III-B).

* A *trusted planner* sees only the user request u and the tool schema and emits
  a labelled plan DAG P_u = (N, <, lambda, own).
* The plan induces a regular language L_u over Sigma recognised by a DFA
  M_u = (Q, Sigma, delta, q0, F_acc). Q = down-sets (completed steps) of the DAG,
  so the multi-agent partial order is enforced.
* Before action k executes, LEDGER checks pi(w_{1:k}) in Pref(L_u)  (Eq. 7):
  one DFA transition per action (Schneider's prefix-closed safety monitor).
* Sinks: high-consequence slots need clearance T. Untrusted text may reach them
  only through a plan-approved extractor chi: text -> S with finite codomain S,
  which bounds attacker influence by log2|S| bits; ``mincut_bits`` gives the
  plan-level max-flow/min-cut bound.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Any, Optional, FrozenSet, Set

import networkx as nx

from ..alphabet import Alphabet, ToolCall, norm_value
from ..events import T, U


@dataclass
class ArgRule:
    kind: str                      # "const" (plan constant from u, label T) | "extract" (chi with codomain S)
    value: Any = None
    codomain: Tuple[Any, ...] = ()
    source: str = ""               # plan-designated source "<record kind>.<field>" the extractor reads
    bound: Any = None              # chi(designated source), filled in by the system at run time

    def admits(self, v: Any) -> bool:
        if self.kind == "const":
            return norm_value(v) == norm_value(self.value)
        if norm_value(v) not in {norm_value(c) for c in self.codomain}:
            return False
        # source binding: an extracted slot must carry chi(plan-designated source), not a value
        # an agent picked up from some other untrusted record
        return self.bound is None or norm_value(v) == norm_value(self.bound)


@dataclass
class PlanStep:
    sid: str
    owner: str
    tool: str
    rules: Dict[str, ArgRule] = field(default_factory=dict)
    deps: Tuple[str, ...] = ()


@dataclass
class PlanDAG:
    task_id: str
    steps: List[PlanStep]
    write_kinds: Dict[str, Tuple[str, ...]] = field(default_factory=dict)  # db-write targets per agent (T)

    def step(self, sid: str) -> PlanStep:
        return next(s for s in self.steps if s.sid == sid)


class TrustedPlanner:
    """Maps (u, tool schema) -> PlanDAG.  It never sees untrusted records.

    The scenario supplies a deterministic compiler from the request template
    (``scenario.compile_plan``); in LLM mode an LLM planner can be plugged in, but
    a template compiler keeps the trusted component deterministic and auditable.
    """

    def __init__(self, scenario):
        self.scenario = scenario
        self.calls = 0

    def make_plan(self, task) -> PlanDAG:
        self.calls += 1
        return self.scenario.compile_plan(task)


class PlanDFA:
    """DFA over (agent, call) symbols; state = frozenset of completed plan steps."""

    def __init__(self, plan: PlanDAG):
        self.plan = plan
        self.q0: FrozenSet[str] = frozenset()

    def _match(self, step: PlanStep, agent: str, call: ToolCall) -> bool:
        if step.owner != agent or step.tool != call.tool:
            return False
        for name, rule in step.rules.items():
            if name not in call.args or not rule.admits(call.args[name]):
                return False
        return True

    def delta(self, q: FrozenSet[str], agent: str, call: ToolCall) -> Optional[FrozenSet[str]]:
        for s in self.plan.steps:
            if s.sid in q or not set(s.deps) <= q:
                continue
            if self._match(s, agent, call):
                return q | {s.sid}
        return None

    def accepting(self, q: FrozenSet[str]) -> bool:
        return len(q) == len(self.plan.steps)

    def n_states(self) -> int:
        """|Q|: number of reachable down-sets (for reporting the automaton size)."""
        seen = {self.q0}
        frontier = [self.q0]
        while frontier:
            q = frontier.pop()
            for s in self.plan.steps:
                if s.sid not in q and set(s.deps) <= q:
                    nq = q | {s.sid}
                    if nq not in seen:
                        seen.add(nq)
                        frontier.append(nq)
        return len(seen)


class Monitor:
    """Runtime monitor: one DFA per active plan + sink clearance checks.

    ``check`` returns (ok, reason). It costs one DFA transition per action.
    """

    def __init__(self, alphabet: Alphabet):
        self.alphabet = alphabet
        self.plans: Dict[str, Tuple[PlanDFA, FrozenSet[str]]] = {}
        self.approved: List[Tuple[str, str]] = []   # (agent, symbol) authorised by the human reviewer
        self.transitions = 0

    def load(self, plan: PlanDAG) -> None:
        dfa = PlanDFA(plan)
        self.plans[plan.task_id] = (dfa, dfa.q0)

    def authorise(self, agent: str, call: ToolCall) -> None:
        self.approved.append((agent, self.alphabet.pi(call)))

    def check(self, task_id: str, agent: str, call: ToolCall, context_label: str) -> Tuple[bool, str]:
        self.transitions += 1
        sym = self.alphabet.pi(call)
        if (agent, sym) in self.approved:
            self.approved.remove((agent, sym))
            return True, "approved-by-reviewer"
        if task_id not in self.plans:
            return False, "no-plan"
        dfa, q = self.plans[task_id]
        nq = dfa.delta(q, agent, call)
        if nq is None:
            # distinguish taint violations from control-flow violations for reporting
            spec = self.alphabet.specs.get(call.tool)
            same_tool = [s for s in dfa.plan.steps if s.tool == call.tool and s.owner == agent]
            if spec is not None and same_tool and context_label == U:
                return False, "sink-clearance"
            return False, "not-in-Pref(L_u)"
        self.plans[task_id] = (dfa, nq)
        return True, "ok"

    def bind(self, task_id: str, values: Dict[str, Any]) -> None:
        """Bind extractor slots ("<step>.<arg>") to chi(designated source) for this task."""
        if task_id not in self.plans:
            return
        dfa, _ = self.plans[task_id]
        for s in dfa.plan.steps:
            for name, rule in s.rules.items():
                key = f"{s.sid}.{name}"
                if rule.kind == "extract" and key in values and values[key] is not None:
                    rule.bound = values[key]

    def repair(self, task_id: str, agent: str, call: ToolCall) -> Optional[ToolCall]:
        """If the call only differs from an admissible step in extractor-bound slots, return the call
        with chi(designated source) substituted (the system fills the slot, as in CaMeL-style
        data-flow enforcement). Otherwise None."""
        if task_id not in self.plans:
            return None
        dfa, q = self.plans[task_id]
        for s in dfa.plan.steps:
            if s.sid in q or not set(s.deps) <= q or s.owner != agent or s.tool != call.tool:
                continue
            fixed = ToolCall(call.tool, dict(call.args), call.agent, dict(call.meta))
            ok = True
            for name, rule in s.rules.items():
                if name in fixed.args and rule.admits(fixed.args[name]):
                    continue
                if rule.kind == "extract" and rule.bound is not None:
                    fixed.args[name] = rule.bound
                else:
                    ok = False
                    break
            if ok and dfa.delta(q, agent, fixed) is not None:
                return fixed
        return None

    def check_write(self, plan: Optional[PlanDAG], agent: str, kind: str) -> bool:
        """Database-write targets are high-consequence sinks: they must be plan constants."""
        if plan is None:
            return True
        allowed = plan.write_kinds.get(agent)
        return allowed is None or kind in allowed

    def accepted(self, task_id: str) -> bool:
        if task_id not in self.plans:
            return False
        dfa, q = self.plans[task_id]
        return dfa.accepting(q)


def extract(value: Any, codomain: Tuple[Any, ...], default: Any = None) -> Any:
    """chi: text -> S. Anything outside the finite codomain is rejected (returns default)."""
    cod = {norm_value(c): c for c in codomain}
    return cod.get(norm_value(value), default)


def mincut_bits(plan: PlanDAG) -> float:
    """Plan-level bound on attacker influence (bits).

    Extractor edges get capacity log2|S_e|, all other untrusted edges infinite.
    Max-flow(U -> sinks) = min-cut = #bits an attacker controlling every U record
    can steer into high-consequence slots. Infinite <=> monitor violation possible.
    """
    g = nx.DiGraph()
    g.add_node("U")
    g.add_node("SINK")
    for s in plan.steps:
        for name, rule in s.rules.items():
            slot = f"{s.sid}.{name}"
            g.add_edge(slot, "SINK")  # infinite capacity (no 'capacity' attr)
            if rule.kind == "extract":
                cap = math.log2(max(1, len(rule.codomain)))
                src = f"chi:{rule.source or slot}"
                if g.has_edge("U", src):
                    pass
                else:
                    g.add_edge("U", src, capacity=cap)
                g.add_edge(src, slot)
            # const slots are fed by u (label T): no edge from U
    if g.out_degree("U") == 0:
        return 0.0
    val, _ = nx.maximum_flow(g, "U", "SINK")
    return float(val)
