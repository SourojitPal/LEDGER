"""Layer S: spectral propagation and record localisation (Sec. III-C).

For each window [t-Delta, t] LEDGER builds a weighted graph over A u {h}  (Eq. 8):

    W_ij = c^msg_ij + sum_{r in D} (omega_ir rho_jr + omega_jr rho_ir),
    L_t  = I - D_t^{-1/2} W_t D_t^{-1/2}

with omega_ir = writes of record r by i and rho_jr = reads of r by j in the window.
Structural score S1(t) = |lambda_2(L_t) - lambda_2(L_bar)|, with the
Hoffman-Wielandt bound S1(t) <= ||L_t - L_bar||_F.

Propagation (record-mediated SIS, Eq. 9):  R0 = beta_r beta_w / (delta_a delta_r) * rho(R W)
with R the agent x record read-rate matrix and W the record x agent write-rate matrix.

Localisation: leading right singular vector of the agent x record access matrix
B_t; the record with the largest entry is the candidate source; concentration is
summarised by the inverse participation ratio IPR = sum_r v_r^4.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple, Sequence, Optional

import numpy as np

from ..events import Event, U


REG_TAU = 0.1


def normalized_laplacian(W: np.ndarray, tau: float = REG_TAU) -> np.ndarray:
    """L = I - D^{-1/2} W D^{-1/2}.

    W is symmetrised and regularised with tau/n on every off-diagonal entry (regularised
    spectral clustering, Amini et al. 2013) so that a node that is idle in a window (e.g. the
    reviewer h) does not force lambda_2 = 0; isolated nodes otherwise get a zero row."""
    W = 0.5 * (W + W.T)
    n = W.shape[0]
    if tau > 0 and n > 1:
        W = W + (tau / n) * (np.ones((n, n)) - np.eye(n))
    d = W.sum(axis=1)
    inv = np.zeros_like(d)
    nz = d > 0
    inv[nz] = 1.0 / np.sqrt(d[nz])
    L = -inv[:, None] * W * inv[None, :]
    L[np.diag_indices_from(L)] += nz.astype(float)
    return L


def lambda2(L: np.ndarray) -> float:
    ev = np.sort(np.linalg.eigvalsh(0.5 * (L + L.T)))
    return float(ev[1]) if len(ev) > 1 else 0.0


@dataclass
class WindowStats:
    W: np.ndarray
    L: np.ndarray
    lam2: float
    R: np.ndarray            # agents x records (reads / round)
    Wr: np.ndarray           # records x agents (writes / round)
    B: np.ndarray            # agents x U-records access matrix
    records: List[str]       # column ids of R / B (U records)
    rho_RW: float


class SpectralLayer:
    def __init__(self, agents: Sequence[str], reviewer: str = "h"):
        self.nodes = list(agents) + [reviewer]
        self.agents = list(agents)
        self.idx = {a: i for i, a in enumerate(self.nodes)}
        self.L_bar: Optional[np.ndarray] = None
        self.lam2_bar: float = 0.0

    # ----------------------------------------------------------- graph (Eq. 8)
    def window(self, events: List[Event], round_now: int, delta: int, db) -> WindowStats:
        lo = round_now - delta + 1
        ev = [e for e in events if lo <= e.round <= round_now]
        n = len(self.nodes)
        W = np.zeros((n, n))
        writes: Dict[str, Dict[str, float]] = {}
        reads: Dict[str, Dict[str, float]] = {}
        for e in ev:
            if e.type in ("msg", "approval_request", "approval") and e.agent in self.idx and e.target in self.idx:
                i, j = self.idx[e.agent], self.idx[e.target]
                if i != j:
                    W[i, j] += 1.0
                    W[j, i] += 1.0
            elif e.type == "write" and e.agent in self.idx:
                writes.setdefault(e.record, {}).setdefault(e.agent, 0.0)
                writes[e.record][e.agent] += 1.0
            elif e.type == "read" and e.agent in self.idx:
                reads.setdefault(e.record, {}).setdefault(e.agent, 0.0)
                reads[e.record][e.agent] += 1.0
        # records written inside the window may have been written earlier: use db writer
        for rid, rdict in reads.items():
            rec = db.records.get(rid)
            if rec is None or rec.writer not in self.idx:
                continue
            i = self.idx[rec.writer]
            w_ir = writes.get(rid, {}).get(rec.writer, 1.0)
            for reader, rho in rdict.items():
                j = self.idx[reader]
                if i != j:
                    W[i, j] += w_ir * rho
                    W[j, i] += w_ir * rho
        L = normalized_laplacian(W)
        lam = lambda2(L)

        # R, W (rates per round) over U records seen in the window
        span = float(max(1, delta))
        u_recs = sorted({rid for rid in reads if db.records.get(rid) is not None and db.records[rid].label == U},
                        key=lambda x: int(x[1:]))
        na = len(self.agents)
        R = np.zeros((na, len(u_recs)))
        Wr = np.zeros((len(u_recs), na))
        aidx = {a: i for i, a in enumerate(self.agents)}
        for c, rid in enumerate(u_recs):
            for reader, rho in reads[rid].items():
                if reader in aidx:
                    R[aidx[reader], c] += rho / span
            w = db.records[rid].writer
            if w in aidx:
                Wr[c, aidx[w]] = 1.0 / span
        RW = R @ Wr
        rho_rw = float(np.max(np.abs(np.linalg.eigvals(RW)))) if RW.size else 0.0
        B = (R > 0).astype(float) * R + 0.0  # access weights
        return WindowStats(W=W, L=L, lam2=lam, R=R, Wr=Wr, B=B, records=u_recs, rho_RW=rho_rw)

    # ------------------------------------------------------- calibration of L_bar
    def set_reference(self, Ls: List[np.ndarray]) -> None:
        if Ls:
            self.L_bar = np.mean(np.stack(Ls), axis=0)
            self.lam2_bar = lambda2(self.L_bar)

    def S1(self, ws: WindowStats) -> float:
        return abs(ws.lam2 - self.lam2_bar)

    def hoffman_wielandt_rhs(self, ws: WindowStats) -> float:
        if self.L_bar is None:
            return float("nan")
        return float(np.linalg.norm(ws.L - self.L_bar, "fro"))


# ------------------------------------------------------------ Eq. (9): R0
def r0_hat(rho_RW: float, beta_r: float, beta_w: float, delta_a: float, delta_r: float) -> float:
    if rho_RW <= 0:
        return 0.0
    return beta_r * beta_w / (delta_a * max(delta_r, 1e-9)) * rho_RW


def rates_from_cfg(cfg) -> Tuple[float, float]:
    delta_a = 1.0 / max(1, cfg.memory_rounds)
    delta_r = 1.0 / cfg.record_ttl if cfg.record_ttl else 1e-3
    return delta_a, delta_r


# ------------------------------------------------------- localisation (SVD)
def record_key(rec) -> str:
    """Key for the benign read-rate baseline: static knowledge records by content, others by kind."""
    if rec.created_at == 0 and rec.expires_at is None:
        return "static:" + rec.content[:48]
    return rec.kind


def expected_access(records: List[str], agents: List[str], db, baseline: Optional[Dict]) -> Optional[np.ndarray]:
    if not baseline:
        return None
    E = np.zeros((len(agents), len(records)))
    for c, rid in enumerate(records):
        key = record_key(db.records[rid])
        for i, a in enumerate(agents):
            E[i, c] = baseline.get((key, a), 0.0)
    return E


def localize(B: np.ndarray, records: List[str], k: int, expected: Optional[np.ndarray] = None
             ) -> Tuple[List[str], float, float]:
    """Return (top-k record ids by |v1|, IPR of v1, sigma_1).

    If ``expected`` (benign read rates from calibration) is given, the SVD is taken of the
    deviation B_t - E[B_t | benign], clipped at 0, so routinely-read records (manuals, the
    current plan) do not mask a record that is read far more than its kind normally is.
    Records with zero deviation are never returned."""
    if expected is not None and expected.shape == B.shape:
        B = np.clip(B - expected, 0.0, None)
    if B.size == 0 or not records or np.allclose(B, 0):
        return [], 0.0, 0.0
    _, s, Vt = np.linalg.svd(B, full_matrices=False)
    v = np.abs(Vt[0])
    order = [i for i in np.argsort(-v, kind="stable") if v[i] > 1e-9 and B[:, i].sum() > 1e-9]
    ipr = float(np.sum(v ** 4) / (np.sum(v ** 2) ** 2 + 1e-12))
    return [records[i] for i in order[:k]], ipr, float(s[0])


# ------------------------------------------- quarantine: cut until R0 < 1
def quarantine_cut(RW_pairs: Dict[Tuple[str, str], float], agents: List[str], beta_r: float, beta_w: float,
                   delta_a: float, delta_r: float, target: float = 1.0, max_cuts: int = 50):
    """Cut reader<-writer edges in decreasing order of u_i * v_j (first-order eigenvalue
    drop, Tong et al.) until R0 < target. RW_pairs[(reader, writer)] = rate."""
    idx = {a: i for i, a in enumerate(agents)}
    n = len(agents)
    M = np.zeros((n, n))
    for (i, j), w in RW_pairs.items():
        if i in idx and j in idx:
            M[idx[i], idx[j]] += w
    cuts = []
    for _ in range(max_cuts):
        ev, vr = np.linalg.eig(M)
        k = int(np.argmax(np.abs(ev)))
        rho = float(np.abs(ev[k]))
        if r0_hat(rho, beta_r, beta_w, delta_a, delta_r) < target or rho == 0:
            break
        evl, vl = np.linalg.eig(M.T)
        kl = int(np.argmax(np.abs(evl)))
        u = np.abs(np.real(vl[:, kl]))
        v = np.abs(np.real(vr[:, k]))
        score = np.outer(u, v) * (M > 0)
        i, j = np.unravel_index(int(np.argmax(score)), score.shape)
        if score[i, j] <= 0:
            break
        M[i, j] = 0.0
        cuts.append((agents[i], agents[j]))
    final = float(np.max(np.abs(np.linalg.eigvals(M)))) if n else 0.0
    return cuts, r0_hat(final, beta_r, beta_w, delta_a, delta_r)
