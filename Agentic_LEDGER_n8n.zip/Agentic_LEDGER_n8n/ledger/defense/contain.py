"""Containment helpers (Sec. III-E): reviewer-request grouping by source record, and the
simulated human reviewer h with finite service rate mu and fatigue.

Reviewer model (an assumption, after Turan 2026 "Oversight has a capacity"):
cards are served FIFO, at most mu per round; a harmful request in a normal card is
caught with probability p0 * exp(-backlog / kappa). Utilisation rho_h = lambda_h / mu,
with rho_h = 1 the stability boundary.

Grouping: requests whose untrusted provenance roots share a record are merged into
one card per window. A card with more than ``suspicious_size`` requests from one
untrusted source is shown as such and scrutinised by a rested reviewer (p0).
The card arrival rate then no longer grows with the flood size N.
"""
from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from typing import List, FrozenSet, Tuple, Dict

from ..alphabet import ToolCall


@dataclass
class Request:
    call: ToolCall
    agent: str
    task_id: str
    sources: FrozenSet[str]      # untrusted provenance roots (record ids)
    harmful: bool                # ground truth (never visible to defenses)
    round: int


@dataclass
class Card:
    requests: List[Request]
    round: int
    grouped: bool = False


class Reviewer:
    def __init__(self, mu: float, p0: float, kappa: float, rng: random.Random, suspicious_size: int = 3):
        self.mu, self.p0, self.kappa, self.rng = mu, p0, kappa, rng
        self.queue: List[Card] = []
        self.suspicious_size = suspicious_size
        self.arrivals_per_round: Dict[int, int] = {}
        self.harmful_approved = 0
        self.harmful_rejected = 0
        self.served = 0
        self._credit = 0.0
        self.rejected_sources: List[FrozenSet[str]] = []

    def submit(self, requests: List[Request], round_: int, grouping: bool) -> int:
        if not requests:
            return 0
        cards: List[Card] = []
        if grouping:
            buckets: Dict[FrozenSet[str], List[Request]] = {}
            singles: List[Request] = []
            for rq in requests:
                if rq.sources:
                    key = None
                    for k in buckets:
                        if k & rq.sources:
                            key = k
                            break
                    if key is None:
                        buckets[rq.sources] = [rq]
                    else:
                        buckets[key].append(rq)
                else:
                    singles.append(rq)
            for k, lst in buckets.items():
                cards.append(Card(lst, round_, grouped=True))
            cards += [Card([rq], round_) for rq in singles]
        else:
            cards = [Card([rq], round_) for rq in requests]
        self.queue.extend(cards)
        self.arrivals_per_round[round_] = self.arrivals_per_round.get(round_, 0) + len(cards)
        return len(cards)

    def serve(self, round_: int) -> List[Request]:
        """Serve up to mu cards; return approved requests."""
        approved: List[Request] = []
        self._credit += self.mu
        while self.queue and self._credit >= 1.0:
            self._credit -= 1.0
            backlog = len(self.queue)
            card = self.queue.pop(0)
            self.served += 1
            n_from_one_source = len(card.requests)
            scrutinise = card.grouped and n_from_one_source > self.suspicious_size
            p_catch = self.p0 if scrutinise else self.p0 * math.exp(-backlog / self.kappa)
            has_harm = any(r.harmful for r in card.requests)
            if has_harm and self.rng.random() < p_catch:
                self.harmful_rejected += sum(r.harmful for r in card.requests)
                if scrutinise:
                    self.rejected_sources.append(frozenset().union(*[r.sources for r in card.requests]))
                    continue          # whole suspicious card rejected
                approved += [r for r in card.requests if not r.harmful]
            else:
                if scrutinise and not has_harm:
                    # a big card from one untrusted source is still suspicious: reject it
                    self.rejected_sources.append(frozenset().union(*[r.sources for r in card.requests]))
                    continue
                approved += card.requests
                self.harmful_approved += sum(r.harmful for r in card.requests)
        self._credit = min(self._credit, self.mu)
        return approved

    @property
    def backlog(self) -> int:
        return len(self.queue)
