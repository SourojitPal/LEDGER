"""Minimal chat clients for local (Ollama) and cloud (OpenAI-compatible) models.

Only the Python standard library is used (urllib), so nothing extra must be
installed. Token counts and wall-clock latency are returned for the cost
experiment (RQ4). Put API keys in environment variables, never in code:
    set OPENAI_API_KEY=sk-...        (Windows)   /   export OPENAI_API_KEY=...   (Linux)
"""
from __future__ import annotations

import json
import os
import time
import urllib.request
from dataclasses import dataclass
from typing import List, Dict


@dataclass
class ChatResult:
    text: str
    prompt_tokens: int
    completion_tokens: int
    latency_s: float
    prefill_s: float = 0.0     # Ollama prompt_eval_duration (s), 0 if unknown
    decode_s: float = 0.0      # Ollama eval_duration (s), 0 if unknown


class OllamaChat:
    def __init__(self, model: str = "qwen3:8b", url: str = "http://localhost:11434",
                 temperature: float = 0.7, timeout: float = 120.0):
        self.model, self.url, self.temperature, self.timeout = model, url.rstrip("/"), temperature, timeout

    def chat(self, messages: List[Dict[str, str]], seed: int = 0) -> ChatResult:
        body = {"model": self.model, "messages": messages, "stream": False, "format": "json",
                "options": {"temperature": self.temperature, "seed": int(seed)}}
        if self.model.startswith("qwen3"):
            body["think"] = False
        req = urllib.request.Request(self.url + "/api/chat", data=json.dumps(body).encode("utf-8"),
                                     headers={"Content-Type": "application/json"})
        t0 = time.perf_counter()
        with urllib.request.urlopen(req, timeout=self.timeout) as r:
            out = json.loads(r.read().decode("utf-8"))
        dt = time.perf_counter() - t0
        return ChatResult(out.get("message", {}).get("content", ""), int(out.get("prompt_eval_count", 0) or 0),
                          int(out.get("eval_count", 0) or 0), dt,
                          float(out.get("prompt_eval_duration", 0) or 0) / 1e9,
                          float(out.get("eval_duration", 0) or 0) / 1e9)


class OpenAIChat:
    def __init__(self, model: str = "gpt-4o-mini", base_url: str = "https://api.openai.com/v1",
                 temperature: float = 0.7, timeout: float = 120.0):
        self.model, self.base_url, self.temperature, self.timeout = model, base_url.rstrip("/"), temperature, timeout
        self.key = os.environ.get("OPENAI_API_KEY", "")
        if not self.key:
            raise RuntimeError("Set the OPENAI_API_KEY environment variable first.")

    def chat(self, messages: List[Dict[str, str]], seed: int = 0) -> ChatResult:
        body = {"model": self.model, "messages": messages, "temperature": self.temperature, "seed": int(seed),
                "response_format": {"type": "json_object"}}
        req = urllib.request.Request(self.base_url + "/chat/completions", data=json.dumps(body).encode("utf-8"),
                                     headers={"Content-Type": "application/json",
                                              "Authorization": "Bearer " + self.key})
        t0 = time.perf_counter()
        with urllib.request.urlopen(req, timeout=self.timeout) as r:
            out = json.loads(r.read().decode("utf-8"))
        dt = time.perf_counter() - t0
        u = out.get("usage", {})
        return ChatResult(out["choices"][0]["message"]["content"], int(u.get("prompt_tokens", 0)),
                          int(u.get("completion_tokens", 0)), dt)


def make_chat(cfg):
    if cfg.backend == "ollama":
        return OllamaChat(cfg.llm_model, cfg.ollama_url, cfg.llm_temperature, cfg.llm_timeout_s)
    if cfg.backend == "openai":
        return OpenAIChat(cfg.llm_model, cfg.openai_base_url, cfg.llm_temperature, cfg.llm_timeout_s)
    raise ValueError("backend must be 'ollama' or 'openai' for LLM agents")


def ollama_available(url: str = "http://localhost:11434") -> bool:
    try:
        with urllib.request.urlopen(url.rstrip("/") + "/api/tags", timeout=3) as r:
            return r.status == 200
    except Exception:
        return False
