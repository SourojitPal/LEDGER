"""Experiments answering the paper's research questions.

  RQ1  detection, localisation, prevention, recovery            -> rq1_main, rq1_ablation, rq1_localisation
  RQ2  exact finite-action confirmation vs cosine similarity    -> rq2_action_level, rq2_fisher_bound,
                                                                  rq2_confirm_compare
  RQ3  persistence & spread, record lifetime, topology, grouping -> rq3_spread, rq3_containment, rq3_flood
  RQ4  security-utility-cost trade-off at the edge              -> rq4_cost, rq4_scaling, rq4_device_profiles

Calibration runs use seeds >= 100000 and are never reused for evaluation.
"""
from __future__ import annotations

import os
import pickle
import time
from typing import Dict, List, Optional, Sequence, Any

import numpy as np
import pandas as pd

from .config import Config, DEFENSES, ABLATIONS
from .testbed import Testbed, Calibration
from .metrics import run_row, summarize, wilson, two_proportion_p
from .defense.calibrate import Calibrator, PageCUSUM
from .defense.layer_t import TopologyLayer
from .defense.layer_s import lambda2, localize
from .defense.confirm import fisher_confirm, min_p_value
from . import scenario as S

ATTACKS = S.ATTACKS
CAL_SEED = 100000


def _progress(i: int, n: int, label: str, every: int = 0) -> None:
    every = every or max(1, n // 10)
    if i == n - 1 or i % every == 0:
        print(f"  {label}: {i + 1}/{n}", flush=True)


# ===================================================================== calibration
def calibrate(cfg: Config, n_runs: int = 200, n_attack: int = 30, verbose: bool = True,
              policy=None) -> Calibration:
    """Benign calibration of L_bar, T-reference diagrams, conformal run-maxima, CUSUM h,
    and attack calibration of beta_r, beta_w (Sec. III-E; code plan Sec. 8)."""
    t0 = time.time()
    cal = Calibration()
    # ---- pass A: reference Laplacian and benign persistence diagrams
    Ls, Ws = [], []
    topo = TopologyLayer(cfg.traj_gamma, cfg.traj_len, max_refs=8)
    steps = []
    warm: Dict[str, list] = {}
    for i in range(max(10, n_runs // 2)):
        tb = Testbed(cfg, "ledger", None, CAL_SEED + i, observe_only=True, policy=policy)
        tb.run()
        d = tb.defense
        Ls += d.Ls[::2]
        Ws += d.Ws[::2]
        for key, embs in d.traj.items():
            hist = warm.setdefault(key, [])
            hist += embs
            if len(hist) >= cfg.traj_len:
                topo.add_reference(key, hist[-cfg.traj_len:])
            X = np.stack(embs)
            if len(X) > 1:
                steps.append(float(np.max(np.linalg.norm(np.diff(X, axis=0), axis=1))))
    # benign read-rate baseline E[B_t] per (record key, agent) for residual localisation
    from .defense.layer_s import record_key
    acc: Dict[tuple, list] = {}
    for i in range(10):
        tb = Testbed(cfg, "ledger", None, CAL_SEED + 30000 + i, observe_only=True, policy=policy)
        tb.run()
        d = tb.defense
        for r in range(cfg.window, cfg.n_rounds):
            ws = d.spec.window(tb.log.events, r, cfg.window, tb.db)
            for c, rid in enumerate(ws.records):
                key = record_key(tb.db.records[rid])
                for ai, a in enumerate(S.AGENTS):
                    acc.setdefault((key, a), []).append(ws.R[ai, c])
    cal.read_baseline = {k: float(np.quantile(v, 0.9)) for k, v in acc.items()}
    cal.L_bar = np.mean(np.stack(Ls), axis=0)
    cal.lam2_bar = lambda2(cal.L_bar)
    cal.W_bar = np.mean(np.stack(Ws), axis=0)
    cal.t_refs = topo.refs
    cal.warm = {k: v[-(cfg.traj_len - 2):] for k, v in warm.items()}
    cal.benign_step_scale = float(np.quantile(steps, 0.95)) if steps else 0.0
    # ---- attack calibration of beta_r, beta_w (separate seeds, undefended)
    ex = co = ca = 0
    for i in range(n_attack):
        res = Testbed(cfg, "none", "selfrep", CAL_SEED + 20000 + i, policy=policy).run()
        c = res.gt["compliance"]
        ex, co, ca = ex + c["exposed"], co + c["complied"], ca + c["carried"]
    cal.beta_r_hat = co / ex if ex else 0.5
    cal.beta_w_hat = ca / co if co else 0.5
    # ---- pass B: conformal run-maxima and S1 window distribution
    names = ["S1"] + [f"T{k}:{a}:{kind}" for a in S.AGENTS for kind in S.TASK_CYCLE for k in (1, 2, 3)]
    calib = Calibrator(names)
    s1_runs = []
    for i in range(n_runs):
        tb = Testbed(cfg, "ledger", None, CAL_SEED + 50000 + i, calibration=cal, observe_only=True, policy=policy)
        res = tb.run()
        calib.add_run(res.gt["run_max"])
        s1_runs.append([row["S1"] for row in res.series])
    allv = np.concatenate([np.asarray(x) for x in s1_runs])
    cal.s1_mu, cal.s1_sd = float(allv.mean()), float(allv.std() + 1e-9)
    gmax = []
    for seq in s1_runs:
        c = PageCUSUM(cfg.cusum_k, 1e9)
        g = 0.0
        for v in seq:
            c.update((v - cal.s1_mu) / cal.s1_sd)
            g = max(g, c.g)
        gmax.append(g)
    # CUSUM threshold at the (1 - alpha/2) conformal quantile of benign run maxima
    qlev = min(1.0, (1 - cfg.alpha / 2) * (1 + 1.0 / len(gmax)))
    cal.cusum_h = float(np.quantile(gmax, qlev)) + 1e-6
    calib.freeze()
    cal.calib = calib
    cal.n_runs = n_runs
    # ---- pass C: run-level threshold tau on min_k p_k (fresh benign runs). Many statistics are tested
    # at every step, so alpha/K per step does not bound the run-level false-alarm rate; tau does:
    # P(min p over a benign run <= tau) <= alpha/2 by exchangeability with the calibration runs.
    mins = []
    for i in range(n_runs):
        tb = Testbed(cfg, "ledger", None, CAL_SEED + 70000 + i, calibration=cal, observe_only=True, policy=policy)
        tb.run()
        mins.append(tb.defense.run_min_p)
    mins = np.sort(np.asarray(mins))
    k = int(np.floor((cfg.alpha / 2) * (len(mins) + 1)))
    tau = 0.0
    for v in np.unique(mins):
        if np.sum(mins <= v) <= k:
            tau = float(v)
        else:
            break
    cal.tau = tau if tau > 0 else float(mins[0]) * 0.999
    cal.tau_runs = len(mins)
    if verbose:
        print(f"  calibration [{cfg.topology}] {n_runs} benign runs, beta_r_hat={cal.beta_r_hat:.2f}, "
              f"beta_w_hat={cal.beta_w_hat:.2f}, lambda2(L_bar)={cal.lam2_bar:.3f}, CUSUM h={cal.cusum_h:.2f}, "
              f"tau={cal.tau:.2e} "
              f"({time.time() - t0:.0f}s)")
    return cal


def get_calibration(cfg: Config, cache_dir: str, n_runs: int = 200, force: bool = False) -> Calibration:
    os.makedirs(cache_dir, exist_ok=True)
    key = f"calib_v2_{cfg.backend}_{cfg.topology}_ttl{cfg.record_ttl}_M{cfg.memory_rounds}_n{n_runs}.pkl"
    path = os.path.join(cache_dir, key)
    if os.path.exists(path) and not force:
        with open(path, "rb") as f:
            return pickle.load(f)
    cal = calibrate(cfg, n_runs=n_runs)
    with open(path, "wb") as f:
        pickle.dump(cal, f)
    return cal


# ===================================================================== generic grid
def run_grid(cfg: Config, defenses: Sequence[str], attacks: Sequence[Optional[str]], seeds: Sequence[int],
             calibration: Optional[Calibration], label: str = "", keep: int = 0, defense_cfgs=None):
    """Run every (defense, attack, seed). ``defense_cfgs`` maps a display name to
    (defense, cfg overrides) so ablations can share one loop. Returns (df, kept results)."""
    rows, kept = [], []
    items = defense_cfgs or {d: (d, {}) for d in defenses}
    total = len(items) * len(attacks) * len(seeds)
    i = 0
    for disp, (dname, over) in items.items():
        c = cfg.with_(**over) if over else cfg
        for a in attacks:
            for s in seeds:
                res = Testbed(c, dname, a, s, calibration=calibration, keep_log=len(kept) < keep).run()
                row = run_row(res, c)
                row["defense"] = disp
                rows.append(row)
                if keep and res.log is not None:
                    kept.append(res)
                _progress(i, total, label or cfg.topology)
                i += 1
    return pd.DataFrame(rows), kept


# ===================================================================== RQ1
def rq1_main(cfg: Config, calibs: Dict[str, Calibration], n_seeds: int = 40,
             topologies=("pipeline", "cyclic"), defenses=DEFENSES, attacks=ATTACKS):
    dfs, series = [], {}
    for topo in topologies:
        c = cfg.with_(topology=topo)
        df, _ = run_grid(c, defenses, [None] + list(attacks), range(n_seeds), calibs[topo], label=f"RQ1 {topo}")
        dfs.append(df)
    runs = pd.concat(dfs, ignore_index=True)
    return runs, summarize(runs)


def rq1_traces(cfg: Config, calib: Calibration, attack: str = "selfrep", n_seeds: int = 30,
               defenses=("none", "ledger")) -> pd.DataFrame:
    """Per-round trajectories (with seeds) for the timeline / spectral figures."""
    rows = []
    for d in defenses:
        for a in [None, attack]:
            for s in range(n_seeds):
                tb = Testbed(cfg, d if d != "none" else "ledger", a, s, calibration=calib,
                             observe_only=(d == "none"))
                res = tb.run()
                ser = pd.DataFrame(res.series)
                per_round = ser.groupby("round").agg(lam2=("lam2", "last"), S1=("S1", "max"), R0=("R0", "last"),
                                                     IPR=("IPR", "max"), T1=("T1", "max"),
                                                     p_min=("p_min", "min")).reset_index()
                cum_succ = 0
                verd_rounds = {v["round"] for v in res.verdicts}
                for rr in res.rounds:
                    pr = per_round[per_round["round"] == rr["round"]]
                    rows.append({"defense": d, "attack": a or "benign", "seed": s, **rr,
                                 "success_by_now": res.attack_success and res.first_success_round <= rr["round"],
                                 "verdict": rr["round"] in verd_rounds,
                                 **({k: float(pr[k].iloc[0]) for k in ("lam2", "S1", "R0", "IPR", "T1", "p_min")}
                                    if len(pr) else {})})
    return pd.DataFrame(rows)


def rq1_heatmap_counts(cfg: Config, calib: Calibration, attack: str = "selfrep", n_seeds: int = 30):
    """Mean cross-channel event counts per (agent . channel) x phase, no defense vs LEDGER."""
    out = {}
    for d in ("none", "ledger"):
        acc: Dict[str, float] = {}
        for s in range(n_seeds):
            res = Testbed(cfg, d, attack, s, calibration=calib).run()
            for k, v in res.gt["event_counts"].items():
                acc[k] = acc.get(k, 0.0) + v / n_seeds
        out[d] = acc
    return out


def rq1_ablation(cfg: Config, calib: Calibration, n_seeds: int = 30, attacks=ATTACKS):
    items = {name: ("ledger", over) for name, over in ABLATIONS.items()}
    df, _ = run_grid(cfg, [], [None] + list(attacks), range(n_seeds), calib, label="RQ1 ablation",
                     defense_cfgs=items)
    return df, summarize(df)


def rq1_localisation_theory(n_trials: int = 400, n_agents: int = 8, n_records: int = 40, seed: int = 0):
    """Synthetic check of SVD localisation (Layer S): top right singular vector of B
    peaks at the poisoned record as its reader count grows relative to benign records."""
    rng = np.random.default_rng(seed)
    rows = []
    for readers in range(1, n_agents + 1):
        for popular in (1, 2, 3):
            hits = 0
            iprs = []
            for _ in range(n_trials):
                B = (rng.random((n_agents, n_records)) < 0.12).astype(float) * rng.uniform(0.5, 1.5,
                                                                                           (n_agents, n_records))
                # 'popular' benign records read by `popular+1` agents with high weight
                for j in range(1, 1 + 3):
                    idx = rng.choice(n_agents, size=min(n_agents, popular + 1), replace=False)
                    B[idx, j] = rng.uniform(1.0, 2.0, len(idx))
                B[:, 0] = 0.0
                idx = rng.choice(n_agents, size=readers, replace=False)
                B[idx, 0] = rng.uniform(1.0, 2.0, readers)      # poisoned record, read repeatedly
                recs = [f"r{j}" for j in range(n_records)]
                top, ipr, _ = localize(B, recs, 1)
                hits += top[0] == "r0"
                iprs.append(ipr)
            lo, hi = wilson(hits, n_trials)
            rows.append({"readers": readers, "popular_benign_readers": popular + 1, "top1": hits / n_trials,
                         "lo": lo, "hi": hi, "IPR": float(np.mean(iprs))})
    return pd.DataFrame(rows)


# ===================================================================== RQ2
def rq2_action_level(cfg: Config, n_seeds: int = 40, attacks=("hijack", "inplan", "selfrep", "flood")):
    """Original vs masked (u -> u~) tool calls: MELON cosine score vs exact symbol match."""
    rows = []
    for a in [None] + list(attacks):
        for s in range(n_seeds):
            tb = Testbed(cfg, "probe", a, 3000 + s)
            tb.run()
            rows += tb.defense.rows
    return pd.DataFrame(rows)


def roc_points(df: pd.DataFrame):
    y = df["attack_driven"].values.astype(bool)
    sc = df["cosine"].values
    ths = np.unique(np.concatenate([[-1.0, 2.0], sc]))
    pts = []
    P, N = max(1, y.sum()), max(1, (~y).sum())
    for th in ths:
        pred = sc > th
        pts.append((((pred & ~y).sum()) / N, ((pred & y).sum()) / P, th))
    pts = sorted(pts)
    fpr = np.array([p[0] for p in pts])
    tpr = np.array([p[1] for p in pts])
    auc = float(np.trapezoid(tpr, fpr)) if hasattr(np, "trapezoid") else float(np.trapz(tpr, fpr))
    ex = df["exact"].values.astype(bool)
    exact_pt = (float((ex & ~y).sum() / N), float((ex & y).sum() / P))
    th08 = sc > cfg_theta_default()
    cos_pt = (float((th08 & ~y).sum() / N), float((th08 & y).sum() / P))
    return fpr, tpr, auc, exact_pt, cos_pt


def cfg_theta_default() -> float:
    return Config().melon_theta


def rq2_fisher_bound(qs=(3, 4, 5, 6), ps=np.linspace(0.05, 0.95, 19), alpha_c: float = 0.05,
                     n_mc: int = 20000, seed: int = 0):
    """Monte-Carlo check of the false-confirmation bound (H0: same rate in both arms) and power
    (H1: unmasked rate beta, masked rate ~0)."""
    rng = np.random.default_rng(seed)
    rows = []
    cache: Dict[tuple, bool] = {}
    for q in qs:
        def rej(xu, xm):
            k = (q, xu, xm)
            if k not in cache:
                cache[k] = fisher_confirm(int(xu), int(xm), q, alpha_c)[0]
            return cache[k]
        for p in ps:
            xu = rng.binomial(q, p, n_mc)
            xm = rng.binomial(q, p, n_mc)
            h0 = np.mean([rej(a, b) for a, b in zip(xu, xm)])
            xu1 = rng.binomial(q, p, n_mc)
            xm1 = rng.binomial(q, 0.02, n_mc)
            pw = np.mean([rej(a, b) for a, b in zip(xu1, xm1)])
            rows.append({"q": q, "p": float(p), "false_confirm": float(h0), "power": float(pw),
                         "min_p": min_p_value(q)})
    return pd.DataFrame(rows)


def rq2_confirm_compare(cfg: Config, calib: Calibration, n_seeds: int = 40, attacks=("hijack", "selfrep")):
    items = {"LEDGER (exact pi)": ("ledger", {"confirm_compare": "exact"}),
             "LEDGER (cosine>theta)": ("ledger", {"confirm_compare": "cosine"}),
             "MELON (cosine)": ("melon", {}),
             "MELON (exact pi)": ("melon_exact", {})}
    df, _ = run_grid(cfg, [], [None] + list(attacks), range(n_seeds), calib, label="RQ2 compare",
                     defense_cfgs=items)
    return df, summarize(df)


# ===================================================================== RQ3
def rq3_spread(cfg: Config, n_seeds: int = 25, topologies=("pipeline", "cyclic", "full"),
               ttls=(1, 2, 3, 4, 6, None), betas=(0.4, 0.7, 0.9), n_rounds: int = 24):
    """Self-replicating payload, no blocking; transient seed (adversary removes it after 2 rounds)
    so persistence must come from copies. Compares outcome with the record-level R0 (Eq. 9)
    and with the agent-level epidemic index beta/delta * rho(A) (Eq. 5)."""
    rows = []
    total = len(topologies) * len(ttls) * len(betas)
    i = 0
    for topo in topologies:
        for ttl in ttls:
            for b in betas:
                c = cfg.with_(topology=topo, record_ttl=ttl, beta_r=b, n_rounds=n_rounds, seed_visible_rounds=2)
                # rho(RW) measured on benign runs of the same configuration
                rhos = []
                for s in range(6):
                    tb = Testbed(c, "ledger", None, 7000 + s, observe_only=True)
                    res = tb.run()
                    rhos.append(np.mean([x["rho_RW"] for x in res.series if x["round"] >= 2]))
                rho = float(np.mean(rhos))
                delta_a = 1.0 / c.memory_rounds
                delta_r = 1.0 / ttl if ttl else 1e-3
                R0 = b * c.beta_w / (delta_a * delta_r) * rho
                A = np.zeros((4, 4))
                for ri, a in enumerate(S.AGENTS):
                    for w in S.TOPOLOGIES[topo][a]:
                        A[ri, S.AGENTS.index(w)] = 1
                rhoA = float(np.max(np.abs(np.linalg.eigvals(A))))
                agent_index = b * c.beta_w / delta_a * rhoA
                for s in range(n_seeds):
                    res = Testbed(c, "none", "selfrep", 8000 + s).run()
                    late = res.rounds[-6:]
                    rows.append({"topology": topo, "ttl": "never" if ttl is None else ttl, "beta_r": b, "seed": s,
                                 "R0": R0, "rho_RW": rho, "agent_index": agent_index,
                                 "spread": float(np.mean([x["compromised"] for x in late]) / 4.0),
                                 "persist": res.rounds[-1]["active_payload"] > 0,
                                 "compromised_ever": res.gt["compromised_ever"]})
                _progress(i, total, "RQ3 spread", every=6)
                i += 1
    return pd.DataFrame(rows)


def rq3_containment(cfg: Config, calib: Calibration, n_seeds: int = 30, n_rounds: int = 16):
    """Cyclic topology, long-lived records, self-replicating attack: per-round compromise
    with record-level containment (LEDGER and its ablations) vs agent-level reset."""
    c = cfg.with_(n_rounds=n_rounds)
    items = {"No defense": ("none", {}), "Agent-level (reset agent)": ("agent_graph", {}),
             "LEDGER": ("ledger", {}), "LEDGER -Rollback": ("ledger", {"use_rollback": False}),
             "LEDGER -Quarantine": ("ledger", {"use_quarantine": False})}
    rows = []
    for disp, (d, over) in items.items():
        cc = c.with_(**over) if over else c
        for s in range(n_seeds):
            res = Testbed(cc, d, "selfrep", 9000 + s, calibration=calib).run()
            for rr in res.rounds:
                rows.append({"defense": disp, "seed": s, **rr, "success": res.attack_success})
    return pd.DataFrame(rows)


def rq3_flood(cfg: Config, calib: Calibration, n_seeds: int = 30, Ns=(10, 25, 50, 100, 200)):
    rows = []
    items = {"No defense": ("none", {}), "LEDGER -Grouping": ("ledger", {"use_grouping": False}),
             "LEDGER (grouping)": ("ledger", {})}
    for N in Ns:
        for disp, (d, over) in items.items():
            cc = cfg.with_(flood_n=N, **over)
            for s in range(n_seeds):
                res = Testbed(cc, d, "flood", 11000 + s, calibration=calib).run()
                flood_rounds = [r for r in res.rounds if r["round"] >= cfg.t_inject]
                lam = np.mean([r["cards_in"] for r in flood_rounds]) if flood_rounds else 0.0
                alarm_tasks = [t for t in res.tasks if t["kind"] == "alarm" and t["post_injection"]]
                rows.append({"N": N, "defense": disp, "seed": s, "attack_success": res.attack_success,
                             "harmful_approved": res.gt["harmful_approved"],
                             "max_backlog": max(r["backlog"] for r in res.rounds),
                             "rho_h": lam / cfg.reviewer_mu,
                             "alarm_task_success": np.mean([t["solved"] for t in alarm_tasks]) if alarm_tasks else np.nan,
                             "backlog_series": [r["backlog"] for r in res.rounds]})
    return pd.DataFrame(rows)


# ===================================================================== RQ4
def rq4_cost(rq1_runs: pd.DataFrame) -> pd.DataFrame:
    cols = ["calls_per_task", "extra_calls_per_task", "tokens_per_task", "latency_per_task_s",
            "energy_per_task_J", "defense_cpu_ms_per_step", "embed_calls_per_task"]
    g = rq1_runs.groupby(["defense", "benign"])[cols].mean().reset_index()
    return g


def rq4_scaling(rq1_runs: pd.DataFrame, cfg: Config, steps=range(2, 17)):
    """Extra LLM calls per task vs agent steps per task T: MELON re-executes every step (T extra);
    LEDGER re-executes 2q times only per confirmation, i.e. extra = 2q * E[#confirmations per task]."""
    led = rq1_runs[rq1_runs["defense"] == "ledger"]
    rate_b = led[led["benign"]]["extra_calls_per_task"].mean()
    rate_a = led[~led["benign"]]["extra_calls_per_task"].mean()
    steps_per_task = len(S.AGENTS)
    rows = []
    for T in steps:
        rows.append({"T": T, "MELON": float(T), "LEDGER benign": rate_b * T / steps_per_task,
                     "LEDGER under attack": rate_a * T / steps_per_task})
    return pd.DataFrame(rows)


DEVICE_PROFILES = {
    # name: (overhead_s, prefill_tps, decode_tps, power_W)  -- ASSUMED, replace with measurements
    "Laptop RTX GPU, 8B Q4": (0.20, 900.0, 30.0, 70.0),
    "Jetson Orin-class, 4B Q4": (0.30, 300.0, 12.0, 25.0),
    "CPU-only mini PC, 1.5B": (0.40, 120.0, 8.0, 18.0),
}


def rq4_device_profiles(rq1_runs: pd.DataFrame, cfg: Config) -> pd.DataFrame:
    from .config import EdgeProfile
    from .metrics import latency_energy
    rows = []
    g = rq1_runs.groupby(["defense", "benign"])[["calls_per_task", "tokens_per_task", "extra_calls_per_task"]].mean()
    for dev, (ov, pre, dec, pw) in DEVICE_PROFILES.items():
        for (d, ben), r in g.iterrows():
            # split tokens ~ 85% prompt / 15% completion as measured in the testbed
            calls = r["calls_per_task"]
            tok = r["tokens_per_task"]
            t = calls * ov + 0.85 * tok / pre + 0.15 * tok / dec
            rows.append({"device": dev, "defense": d, "benign": ben, "latency_s": t, "energy_J": t * pw})
    return pd.DataFrame(rows)


def measure_edge_profile(cfg: Config, n: int = 6, save_to: Optional[str] = None) -> Optional[Dict[str, float]]:
    """Measure the local Ollama model on this machine (RQ4): per-call overhead, prefill and decode
    speed (from Ollama's own timers) and mean GPU power during the calls (nvidia-smi).
    The result replaces the assumed EdgeProfile in ``cfg.edge`` and is optionally saved to JSON."""
    from .llm import OllamaChat, ollama_available
    from .energy import PowerMeter, save_profile
    if not ollama_available(cfg.ollama_url):
        print("Ollama is not reachable; keeping the assumed edge profile.")
        return None
    chat = OllamaChat(cfg.llm_model, cfg.ollama_url, 0.0, cfg.llm_timeout_s)
    chat.chat([{"role": "user", "content": "Reply with {\"ok\": true}"}], seed=0)      # load the model
    res = []
    with PowerMeter() as pm:
        for i in range(n):
            res.append(chat.chat([{"role": "user", "content": ("sensor zone temperature reading " * 120) +
                                   " Summarise in JSON {\"note\": ...} with 40 words."}], seed=i))
    pre = float(np.median([r.prompt_tokens / r.prefill_s for r in res if r.prefill_s > 0] or [cfg.edge.prefill_tps]))
    dec = float(np.median([r.completion_tokens / r.decode_s for r in res if r.decode_s > 0] or [cfg.edge.decode_tps]))
    ov = float(np.median([max(0.0, r.latency_s - r.prefill_s - r.decode_s) for r in res]))
    prof = {"overhead_s": ov, "prefill_tps": pre, "decode_tps": dec}
    if pm.mean_w is not None:
        prof["power_w"] = float(pm.mean_w)
    for k, v in prof.items():
        setattr(cfg.edge, k, v)
    cfg.edge.name = f"measured: {cfg.llm_model} on this machine"
    if save_to:
        save_profile(cfg.edge, save_to)
    print("measured edge profile:", {k: round(v, 3) for k, v in prof.items()},
          "" if pm.available else "(nvidia-smi not found: power stays assumed)")
    return prof


def rq2_sensitivity(cfg: Config, calib: Calibration, n_seeds: int = 25, ps=(0.0, 0.05, 0.10, 0.20, 0.35)):
    """Sensitivity of benign utility / alarm rate to the simulator assumption p_ctx_driven
    (how often a masked run reproduces a content-driven benign call)."""
    rows = []
    for p in ps:
        c = cfg.with_(p_ctx_driven=p)
        for d in ("melon", "melon_exact", "ledger"):
            for s in range(n_seeds):
                res = Testbed(c, d, None, 13000 + s, calibration=calib).run()
                rr = run_row(res, c)
                rows.append({"p_ctx_driven": p, "defense": d, "BU": rr["utility"], "alarm": rr["any_alarm"]})
    return pd.DataFrame(rows)


# ===================================================================== formal checks
def formal_checks(cfg: Config, calib: Calibration, n_runs: int = 20) -> pd.DataFrame:
    """Numerical checks of the statements the method relies on (supporting evidence)."""
    from .defense.layer_f import PlanDFA, mincut_bits
    from .defense.layer_t import trajectory_points, h0_diagram, max_consecutive_step
    from scipy.spatial.distance import pdist, squareform
    rows = []
    rng = __import__("random").Random(0)
    for kind in S.TASK_CYCLE:
        t = S.Task("t", kind, 0, "A", "D1", {"setpoint": 21, "vendor": "Acme HVAC"}, "u")
        p = S.compile_plan(t)
        rows.append({"check": f"Layer F plan '{kind}'", "value": f"|Q| = {PlanDFA(p).n_states()} states, "
                                                                 f"min-cut bound = {mincut_bits(p):.2f} bits",
                     "holds": True})
    hw_viol, n_hw, sp_viol, n_sp = 0, 0, 0, 0
    for s in range(n_runs):
        tb = Testbed(cfg, "ledger", "selfrep", 15000 + s, calibration=calib)
        res = tb.run()
        for x in res.series:
            n_hw += 1
            hw_viol += x["S1"] > x["HW_rhs"] + 1e-9
        for key, embs in tb.defense.traj.items():
            X = trajectory_points(embs[-cfg.traj_len:], cfg.traj_gamma)
            if len(X) >= 2:
                n_sp += 1
                t1 = max(d for _, d in h0_diagram(squareform(pdist(X))))
                sp_viol += t1 > max_consecutive_step(X) + 1e-9
    rows.append({"check": "Hoffman-Wielandt: S1 <= ||L_t - L_bar||_F", "value": f"{n_hw - hw_viol}/{n_hw} windows",
                 "holds": hw_viol == 0})
    rows.append({"check": "Spanning-path lemma: T1 <= max consecutive step", "value": f"{n_sp - sp_viol}/{n_sp} "
                 "trajectories", "holds": sp_viol == 0})
    for q in (3, 4, 5):
        rows.append({"check": f"Fisher test q={q}: minimum p-value 1/C(2q,q)", "value": f"{min_p_value(q):.4f}",
                     "holds": min_p_value(q) <= cfg.alpha_c})
    rows.append({"check": "Conformal calibration size", "value": f"N = {calib.n_runs} benign runs; "
                 f"min p = {1 / (calib.n_runs + 1):.4f} vs alpha/K = {cfg.alpha / 4:.4f}",
                 "holds": 1 / (calib.n_runs + 1) <= cfg.alpha / 4})
    return pd.DataFrame(rows)


# ===================================================================== LLM mode
def run_llm_experiment(cfg: Config, defenses=("none", "melon", "ledger"), attacks=("hijack", "inplan"),
                       n_seeds: int = 3, n_cal: int = 12, cache_dir: str = "results/cache") -> pd.DataFrame:
    """Same pipeline, real LLM agents (Ollama or OpenAI). Small by default: every agent step is an
    LLM call (~4 per round). Calibration is redone with the LLM (n_cal benign runs)."""
    from .agents import LLMPolicy
    from .llm import make_chat
    chat = make_chat(cfg)
    policy = LLMPolicy(cfg, chat)
    import pickle as _p
    os.makedirs(cache_dir, exist_ok=True)
    path = os.path.join(cache_dir, f"calib_llm_{cfg.llm_model.replace(':', '_')}_{cfg.topology}_{n_cal}.pkl")
    if os.path.exists(path):
        cal = _p.load(open(path, "rb"))
    else:
        cal = calibrate(cfg, n_runs=n_cal, n_attack=max(2, n_cal // 4), policy=policy)
        _p.dump(cal, open(path, "wb"))
    from .energy import PowerMeter
    rows = []
    for d in defenses:
        for a in [None] + list(attacks):
            for s in range(n_seeds):
                t0 = time.time()
                with PowerMeter() as pm:
                    res = Testbed(cfg, d, a, s, calibration=cal, policy=policy).run()
                row = run_row(res, cfg)
                row["wall_s"] = time.time() - t0
                if pm.mean_w is not None:       # measured energy for this run (Eq. 6)
                    row["measured_power_W"] = pm.mean_w
                    row["measured_energy_per_task_J"] = pm.mean_w * row["wall_s"] / max(1, len(res.tasks))
                rows.append(row)
                print(f"  LLM {d:12s} {str(a):8s} seed {s}: ASR={row['attack_success']} "
                      f"utility={row['utility']:.2f} calls/task={row['calls_per_task']:.1f} ({row['wall_s']:.0f}s)")
    return pd.DataFrame(rows)


def rq1_residual(cfg: Config, calib: Calibration, n_seeds: int = 30, defenses=DEFENSES) -> pd.DataFrame:
    """Residual threat: the adversary controls the plan-designated source itself (ticket feed).
    No defense can tell this value from a legitimate one; Layer F bounds its influence to the
    extractor codomain (min-cut bits). Reported separately from the five main attacks."""
    from .defense.layer_f import mincut_bits
    df, _ = run_grid(cfg, defenses, ["source"], range(n_seeds), calib, label="RQ1 residual")
    s = summarize(df)[["topology", "defense", "ASR", "ASR_lo", "ASR_hi", "UA", "calls_per_task"]]
    bits = {k: mincut_bits(S.compile_plan(S.Task("t", k, 0, "A", "D1", {"setpoint": 21, "vendor": "Acme HVAC"}, "u")))
            for k in ("hvac", "door")}
    s["bound_bits_hvac"], s["bound_bits_door"] = bits["hvac"], bits["door"]
    return s
