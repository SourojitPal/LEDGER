"""Measured power for Eq. (6), E ~= P_bar * t_total.

``PowerMeter`` samples the GPU board power with ``nvidia-smi`` in a background thread
(Windows and Linux, NVIDIA GPUs). If nvidia-smi is not available it reports None and the
assumed ``EdgeProfile.power_w`` is kept. ``save_profile`` / ``load_profile`` persist a measured
edge profile to ``results/edge_profile.json`` so every later run uses measured values.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import threading
import time
from dataclasses import asdict
from typing import List, Optional


def nvidia_smi_path() -> Optional[str]:
    p = shutil.which("nvidia-smi")
    if p:
        return p
    win = r"C:\Windows\System32\nvidia-smi.exe"
    return win if os.path.exists(win) else None


class PowerMeter:
    def __init__(self, interval_s: float = 0.25):
        self.interval = interval_s
        self.samples: List[float] = []
        self._stop = threading.Event()
        self._t: Optional[threading.Thread] = None
        self.exe = nvidia_smi_path()

    @property
    def available(self) -> bool:
        return self.exe is not None

    def _read(self) -> Optional[float]:
        try:
            out = subprocess.run([self.exe, "--query-gpu=power.draw", "--format=csv,noheader,nounits"],
                                 capture_output=True, text=True, timeout=5)
            vals = [float(x) for x in out.stdout.strip().splitlines() if x.strip()]
            return sum(vals) if vals else None
        except Exception:
            return None

    def _loop(self):
        while not self._stop.is_set():
            v = self._read()
            if v is not None:
                self.samples.append(v)
            time.sleep(self.interval)

    def __enter__(self):
        if self.available:
            self._t = threading.Thread(target=self._loop, daemon=True)
            self._t.start()
        return self

    def __exit__(self, *exc):
        self._stop.set()
        if self._t is not None:
            self._t.join(timeout=2)

    @property
    def mean_w(self) -> Optional[float]:
        return sum(self.samples) / len(self.samples) if self.samples else None


def save_profile(edge, path: str) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(asdict(edge), f, indent=2)


def load_profile(cfg, path: str) -> bool:
    """Overwrite cfg.edge with a measured profile if ``path`` exists. Returns True if loaded."""
    if not os.path.exists(path):
        return False
    with open(path, encoding="utf-8") as f:
        d = json.load(f)
    for k, v in d.items():
        if hasattr(cfg.edge, k):
            setattr(cfg.edge, k, v)
    return True
