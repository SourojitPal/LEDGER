"""Event schema and run log (Sec. III-A: "A run is a timestamped trace of messages,
record reads and writes, tool calls, and approval requests").

Labels live in the two-point lattice L = {T, U} with T <= U; ``join`` is the
least upper bound used for label propagation.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Iterable

T, U = "T", "U"


def join(labels: Iterable[str]) -> str:
    """Join in L={T,U}: U if any input is U (outputs inherit the join of consumed labels)."""
    return U if any(l == U for l in labels) else T


EVENT_TYPES = (
    "read", "write", "msg", "tool_call", "approval_request", "approval",
    "alarm", "confirm", "rollback", "quarantine", "block", "hold", "melon_abort",
    "agent_reset",
)


@dataclass
class Event:
    t: int                      # logical event time (global counter)
    round: int
    type: str
    agent: str = ""
    record: str = ""
    target: str = ""            # message receiver / tool name
    symbol: str = ""            # pi(action) in Sigma
    label: str = T
    context: List[str] = field(default_factory=list)
    verdict: str = ""           # V0..V3
    blocked: bool = False
    info: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class EventLog:
    def __init__(self, run_id: str = ""):
        self.run_id = run_id
        self.events: List[Event] = []
        self._t = 0

    def emit(self, round_: int, type_: str, **kw) -> Event:
        e = Event(t=self._t, round=round_, type=type_, **kw)
        self._t += 1
        self.events.append(e)
        return e

    @property
    def now(self) -> int:
        return self._t

    def of_type(self, *types: str) -> List[Event]:
        return [e for e in self.events if e.type in types]

    def since_round(self, r0: int) -> List[Event]:
        return [e for e in self.events if e.round >= r0]

    def to_jsonl(self, path: str) -> None:
        with open(path, "w", encoding="utf-8") as f:
            for e in self.events:
                d = e.to_dict()
                d["run"] = self.run_id
                f.write(json.dumps(d, default=str) + "\n")
