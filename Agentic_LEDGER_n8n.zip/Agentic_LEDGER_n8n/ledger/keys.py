"""Loads the OpenAI API key for AgentDojo/MELON (E1) and the OpenAI backend.

Order: environment variable OPENAI_API_KEY (if already set) -> OPENAI_API_KEY in api_keys.py at
the project root. The key is placed in os.environ so openai.OpenAI(), MELON's patched client and
AgentDojo all pick it up. The key itself is never printed.
"""
from __future__ import annotations

import importlib.util
import os
from pathlib import Path


def load_openai_key(root=None, required: bool = True) -> bool:
    if os.environ.get("OPENAI_API_KEY", "").strip():
        return True
    root = Path(root) if root else Path(__file__).resolve().parents[1]
    f = root / "api_keys.py"
    key = ""
    if f.is_file():
        spec = importlib.util.spec_from_file_location("api_keys", f)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        key = str(getattr(mod, "OPENAI_API_KEY", "") or "").strip()
    if key:
        os.environ["OPENAI_API_KEY"] = key
        return True
    if required:
        raise RuntimeError(f"No OpenAI key: put it in {f} (OPENAI_API_KEY = \"sk-...\") and re-run this cell.")
    return False


def key_status() -> str:
    k = os.environ.get("OPENAI_API_KEY", "")
    return "OPENAI_API_KEY is set (" + k[:3] + "..." + k[-4:] + ")" if len(k) > 8 else "OPENAI_API_KEY is NOT set"
