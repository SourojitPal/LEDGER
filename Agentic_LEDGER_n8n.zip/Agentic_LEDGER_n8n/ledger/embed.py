"""Text encoders.

* ``HashEmbedder``: deterministic, offline, dependency-free hashed bag of word
  and character-trigram features (unit norm). Used as e(.) in Eq. (3)/(4) and as
  the frozen encoder phi in Eq. (10) in ``sim`` mode.
* ``OllamaEmbedder`` / ``OpenAIEmbedder``: real encoders for LLM mode
  (nomic-embed-text, text-embedding-3-*). Results are cached.

Note: cosine similarity is used ONLY for retrieval (Eq. 4) and inside the MELON
baseline (Eq. 3). LEDGER's detection and confirmation never use it.
"""
from __future__ import annotations

import json
import re
import zlib
import urllib.request
from typing import Dict, List

import numpy as np

_TOKEN = re.compile(r"[a-z0-9]+")


_STOP = set("a an the of for to and or in on at by with is are be per then this that it its from as into any all".split())


class HashEmbedder:
    """Hashed bag of content words + word bigrams (digits mapped to '#', stop-words removed).

    It mimics two properties of a frozen sentence encoder that matter here: notes about the
    same task are close regardless of the exact numbers, and appended foreign instructions
    move the vector away. It is NOT a semantic model; use embed_backend='ollama' for that."""

    def __init__(self, dim: int = 1024):
        self.dim = dim
        self._cache: Dict[str, np.ndarray] = {}

    def _feats(self, text: str):
        words = ["#" if w.isdigit() else w for w in _TOKEN.findall(text.lower()) if w not in _STOP]
        feats = [("w:" + w, 1.0) for w in words]
        feats += [("b:" + a + "_" + b, 0.5) for a, b in zip(words, words[1:])]
        return feats

    def __call__(self, text: str) -> np.ndarray:
        v = self._cache.get(text)
        if v is not None:
            return v
        vec = np.zeros(self.dim)
        for f, w in self._feats(text):
            h = zlib.crc32(f.encode("utf-8"))
            sign = 1.0 if (h >> 31) & 1 else -1.0
            vec[h % self.dim] += sign * w
        n = np.linalg.norm(vec)
        if n > 0:
            vec = vec / n
        self._cache[text] = vec
        return vec


class _HTTPEmbedder:
    def __init__(self):
        self._cache: Dict[str, np.ndarray] = {}
        self.calls = 0

    def _post(self, url: str, payload: dict, headers: dict) -> dict:
        req = urllib.request.Request(url, data=json.dumps(payload).encode("utf-8"),
                                     headers={"Content-Type": "application/json", **headers})
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read().decode("utf-8"))

    def __call__(self, text: str) -> np.ndarray:
        v = self._cache.get(text)
        if v is None:
            v = np.asarray(self._embed(text), dtype=float)
            n = np.linalg.norm(v)
            v = v / n if n > 0 else v
            self._cache[text] = v
            self.calls += 1
        return v


class OllamaEmbedder(_HTTPEmbedder):
    def __init__(self, url: str = "http://localhost:11434", model: str = "nomic-embed-text"):
        super().__init__()
        self.url, self.model = url.rstrip("/"), model

    def _embed(self, text: str):
        out = self._post(self.url + "/api/embeddings", {"model": self.model, "prompt": text}, {})
        return out["embedding"]


class OpenAIEmbedder(_HTTPEmbedder):
    def __init__(self, base_url: str = "https://api.openai.com/v1", model: str = "text-embedding-3-small"):
        import os
        super().__init__()
        self.base_url, self.model = base_url.rstrip("/"), model
        self.key = os.environ.get("OPENAI_API_KEY", "")

    def _embed(self, text: str):
        out = self._post(self.base_url + "/embeddings", {"model": self.model, "input": text},
                         {"Authorization": "Bearer " + self.key})
        return out["data"][0]["embedding"]


def make_embedder(cfg) -> object:
    if cfg.embed_backend == "ollama":
        return OllamaEmbedder(cfg.ollama_url, cfg.embed_model)
    if cfg.embed_backend == "openai":
        return OpenAIEmbedder(cfg.openai_base_url, cfg.embed_model)
    return HashEmbedder()


def cosine(a: np.ndarray, b: np.ndarray) -> float:
    na, nb = np.linalg.norm(a), np.linalg.norm(b)
    if na == 0 or nb == 0:
        return 0.0
    return float(np.dot(a, b) / (na * nb))
