"""Figures for RQ1-RQ4 (matplotlib only). Every figure is saved as PNG (300 dpi) and PDF.

Colour follows the entity (defense), never its rank; categorical order is fixed.
Figures produced from the simulated backend carry "[SIM]" in their title.
"""
from __future__ import annotations

import os
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

from .metrics import wilson, mean_ci

# ------------------------------------------------------------------ style
COLORS = {
    "ledger": "#2a78d6", "melon": "#eb6834", "melon_exact": "#1baf7a", "agent_graph": "#eda100",
    "none": "#8a8985",
}
LABELS = {"ledger": "LEDGER", "melon": "MELON (cosine)", "melon_exact": "MELON (exact π)",
          "agent_graph": "Agent-level graph", "none": "No defense"}
MARKERS = {"ledger": "o", "melon": "s", "melon_exact": "D", "agent_graph": "^", "none": "x"}
ATTACK_LABELS = {"hijack": "One-shot hijack", "inplan": "In-alphabet hijack", "selfrep": "Self-replicating",
                 "flood": "Reviewer flood", "stealth": "Stealth (adaptive)", "benign": "Benign"}
SEQ = LinearSegmentedColormap.from_list("seq_blue", ["#f4f8fd", "#a9c8f0", "#2a78d6", "#0d3b75"])
INK, INK2, GRID = "#0b0b0b", "#52514e", "#e4e3df"


# ------------------------------------------------------------------ fonts (one place to change them)
# Times New Roman everywhere. Sizes (pt): figure title 14, axes (panel) title 12, axis labels 10, tick labels 10.
# Legends and in-plot annotations use the label size (10 pt).
FONT_FAMILY = ["Times New Roman", "Times", "Liberation Serif", "Nimbus Roman", "TeX Gyre Termes", "DejaVu Serif"]
FS_TITLE, FS_AXTITLE, FS_LABEL, FS_TICK = 14, 12, 10, 10
FS_TEXT = FS_LABEL          # legends, value labels, annotations


def set_style() -> None:
    import logging
    logging.getLogger("matplotlib.font_manager").setLevel(logging.ERROR)   # silent fallback if TNR is missing
    matplotlib.rcParams.update({
        "figure.dpi": 110, "savefig.dpi": 300,
        "font.family": "serif", "font.serif": FONT_FAMILY, "mathtext.fontset": "stix",
        "font.size": FS_LABEL, "figure.titlesize": FS_TITLE, "axes.titlesize": FS_AXTITLE,
        "axes.labelsize": FS_LABEL, "xtick.labelsize": FS_TICK, "ytick.labelsize": FS_TICK,
        "legend.fontsize": FS_TEXT, "legend.title_fontsize": FS_TEXT,
        "pdf.fonttype": 42, "ps.fonttype": 42,
        "axes.edgecolor": "#b5b4ae", "axes.linewidth": 0.8, "axes.grid": True, "grid.color": GRID,
        "grid.linewidth": 0.6, "axes.axisbelow": True, "axes.spines.top": False, "axes.spines.right": False,
        "legend.frameon": False, "xtick.color": INK2, "ytick.color": INK2,
        "axes.labelcolor": INK, "text.color": INK, "lines.linewidth": 2.0,
    })


def _fit_titles(fig) -> bool:
    """Wrap long figure/panel titles so the larger fonts never run past the figure edge."""
    import textwrap
    changed = False
    W = fig.get_figwidth()
    for ax in fig.axes:
        w_in = ax.get_position().width * W
        maxc = max(14, int(w_in * 72 / (FS_AXTITLE * 0.47)))
        for loc in ("left", "center", "right"):
            t = ax.get_title(loc)
            if t and "\n" not in t and len(t) > maxc:
                ax.set_title(textwrap.fill(t, maxc), loc=loc)
                changed = True
    st = getattr(fig, "_suptitle", None)
    if st is not None and st.get_text():
        maxc = max(20, int(W * 72 / (FS_TITLE * 0.47)))
        t = st.get_text()
        if "\n" not in t and len(t) > maxc:
            st.set_text(textwrap.fill(t, maxc))
            changed = True
    return changed


def _save(fig, out_dir: str, name: str) -> str:
    os.makedirs(out_dir, exist_ok=True)
    if _fit_titles(fig) and not fig.legends:      # re-layout only if a title was wrapped and no figure legend
        try:
            fig.tight_layout()
        except Exception:
            pass
    p = os.path.join(out_dir, name)
    fig.savefig(p + ".png", bbox_inches="tight")
    fig.savefig(p + ".pdf", bbox_inches="tight")
    return p + ".png"


def _tag(sim: bool) -> str:
    return " [SIM]" if sim else ""


# ===================================================================== RQ1
def fig_rq1_main(summary: pd.DataFrame, out_dir: str, sim: bool = True,
                 defenses=("none", "melon", "melon_exact", "agent_graph", "ledger")) -> str:
    att = summary[summary["attack"] != "benign"]
    topos = list(att["topology"].unique())
    attacks = list(att["attack"].unique())
    fig, axes = plt.subplots(2, len(topos), figsize=(5.2 * len(topos), 5.6), squeeze=False, sharey="row")
    w = 0.8 / len(defenses)
    x = np.arange(len(attacks))
    for j, topo in enumerate(topos):
        sub = att[att["topology"] == topo]
        for row, (metric, lo, hi, ylab) in enumerate([("ASR", "ASR_lo", "ASR_hi", "Attack success rate (ASR)"),
                                                      ("UA", "UA_lo", "UA_hi", "Utility under attack (UA)")]):
            ax = axes[row, j]
            for k, d in enumerate(defenses):
                s = sub[sub["defense"] == d].set_index("attack").reindex(attacks)
                v = s[metric].values
                err = np.clip(np.vstack([v - s[lo].values, s[hi].values - v]), 0, None)
                ax.bar(x + (k - (len(defenses) - 1) / 2) * w, v, w * 0.92, color=COLORS[d], label=LABELS[d],
                       yerr=np.nan_to_num(err), error_kw={"elinewidth": 0.8, "capsize": 1.5, "ecolor": INK2})
            ax.set_xticks(x)
            ax.set_xticklabels([ATTACK_LABELS.get(a, a) for a in attacks], rotation=18, ha="right")
            ax.set_ylim(0, 1.05)
            if j == 0:
                ax.set_ylabel(ylab)
            if row == 0:
                ax.set_title(f"{topo} topology")
    h, l = axes[0, 0].get_legend_handles_labels()
    fig.suptitle("RQ1: security and utility per attack (95% CI)" + _tag(sim))
    fig.tight_layout(rect=(0, 0, 1, 0.92))
    fig.legend(h, l, ncol=len(defenses), loc="upper center", bbox_to_anchor=(0.5, 0.96))
    return _save(fig, out_dir, "fig_rq1_asr_ua")


def _band(ax, df, xcol, ycol, color, label, ls="-"):
    g = df.groupby(xcol)[ycol]
    m = g.mean()
    n = g.count().clip(lower=1)
    se = g.std().fillna(0) / np.sqrt(n)
    ax.plot(m.index, m.values, color=color, label=label, ls=ls, marker="o", ms=3)
    ax.fill_between(m.index, (m - 1.96 * se).values, (m + 1.96 * se).values, color=color, alpha=0.15, lw=0)


def fig_rq1_timeline(traces: pd.DataFrame, t_inject: int, out_dir: str, sim: bool = True,
                     attack: str = "selfrep") -> str:
    """Event dynamics (cf. reference figure): persistence, exposure, spectral score, success."""
    tr = traces.copy()
    tr["rel"] = tr["round"] - t_inject
    tr["evidence"] = -np.log10(tr["p_min"].clip(lower=1e-6))
    fig, axes = plt.subplots(2, 2, figsize=(10, 6.2))
    panels = [("active_poisoned", "(a) Active poisoned records in D", "records"),
              ("exposed_cum", "(b) Agents exposed to untrusted payload (cumulative)", "agents"),
              ("evidence", "(c) Anomaly evidence -log10 min_k p_k (Eq. 11)", "-log10 p"),
              ("success_by_now", "(d) Attack executed by round (fraction of runs)", "P(success)")]
    for ax, (col, title, yl) in zip(axes.ravel(), panels):
        for d, ls in (("none", "--"), ("ledger", "-")):
            sub = tr[(tr["defense"] == d) & (tr["attack"] == attack)].copy()
            sub[col] = sub[col].astype(float)
            _band(ax, sub, "rel", col, COLORS[d], LABELS[d], ls)
        if col == "evidence":
            ben = tr[(tr["attack"] == "benign") & (tr["defense"] == "none")].copy()
            _band(ax, ben, "rel", "evidence", "#c3c2b7", "Benign baseline", ":")
            ax.axhline(-np.log10(0.05 / 4), color="#e34948", ls="--", lw=1)
            ax.text(ax.get_xlim()[0], -np.log10(0.05 / 4) * 1.03, " alarm level \u03b1/K", fontsize=FS_TEXT, color="#e34948")
        ax.axvline(0, color=INK2, lw=0.8)
        ax.set_title(title, loc="left")
        ax.set_xlabel("Rounds relative to injection (t = 0)")
        ax.set_ylabel(yl)
    axes[0, 0].legend()
    axes[1, 0].legend()
    fig.suptitle(f"RQ1: event dynamics, {ATTACK_LABELS.get(attack, attack)} attack (mean, 95% CI)" + _tag(sim))
    fig.tight_layout()
    return _save(fig, out_dir, "fig_rq1_timeline")


def fig_rq1_heatmap(counts: Dict[str, Dict[str, float]], out_dir: str, sim: bool = True) -> str:
    """Cross-channel activity per (agent . channel) x phase, no defense vs LEDGER."""
    phases = ["pre-injection", "injection", "propagation", "late"]
    keys = set()
    for d in counts.values():
        for k in d:
            a, ch, _ = k.split("|")
            keys.add((a, ch))
    order_a = ["system", "monitor", "maintenance", "planner", "actuator", "h"]
    order_c = ["read", "write", "msg", "tool_call", "approval_request", "approval", "replay reads", "block",
               "alarm", "hold", "confirm", "rollback", "quarantine"]
    rows = sorted(keys, key=lambda k: (order_a.index(k[0]) if k[0] in order_a else 9,
                                       order_c.index(k[1]) if k[1] in order_c else 99))
    rows = [r for r in rows if any(counts[d].get(f"{r[0]}|{r[1]}|{p}", 0) > 0 for d in counts for p in phases)]
    mats = {}
    for d in ("none", "ledger"):
        M = np.array([[counts[d].get(f"{a}|{c}|{p}", 0.0) for p in phases] for a, c in rows])
        mats[d] = M
    vmax = max(np.log1p(m).max() for m in mats.values())
    fig, axes = plt.subplots(1, 2, figsize=(10, 0.32 * len(rows) + 1.6), sharey=True)
    for ax, d in zip(axes, ("none", "ledger")):
        M = mats[d]
        im = ax.imshow(np.log1p(M), cmap=SEQ, vmin=0, vmax=vmax, aspect="auto")
        for i in range(M.shape[0]):
            for j in range(M.shape[1]):
                v = M[i, j]
                ax.text(j, i, f"{v:.1f}" if v < 10 else f"{v:.0f}", ha="center", va="center", fontsize=FS_TEXT,
                        color="white" if np.log1p(v) > 0.6 * vmax else INK)
        ax.set_xticks(range(len(phases)))
        ax.set_xticklabels(phases, rotation=15)
        ax.set_title(LABELS[d])
        ax.grid(False)
    axes[0].set_yticks(range(len(rows)))
    axes[0].set_yticklabels([f"{a} · {c}" for a, c in rows])
    cb = fig.colorbar(im, ax=axes, fraction=0.025, pad=0.02)
    cb.set_label("log(1 + mean events per run)")
    fig.suptitle("RQ1: cross-channel activity across workflow phases (self-replicating attack, mean over seeds)"
                 + _tag(sim))
    return _save(fig, out_dir, "fig_rq1_channel_heatmap")


def fig_rq1_spectral(traces_by_attack: Dict[str, pd.DataFrame], t_inject: int, out_dir: str,
                     sim: bool = True) -> str:
    """Spectral gap lambda_2 around injection (top) and structure-behaviour phase plot (bottom)."""
    attacks = list(traces_by_attack)
    fig, axes = plt.subplots(2, len(attacks), figsize=(4.0 * len(attacks), 6.4), squeeze=False)
    cmap = plt.get_cmap("YlOrRd")
    for j, a in enumerate(attacks):
        tr = traces_by_attack[a].copy()
        tr["rel"] = tr["round"] - t_inject
        ax = axes[0, j]
        ben = tr[(tr["attack"] == "benign") & (tr["defense"] == "none")]
        att = tr[(tr["attack"] == a) & (tr["defense"] == "none")]
        _band(ax, ben, "rel", "lam2", "#8a8985", "Benign baseline", "--")
        _band(ax, att, "rel", "lam2", COLORS["melon"], "Attack (no defense)", "-")
        pre = att[att["rel"] < 0]["lam2"].mean()
        post = att[att["rel"] >= 1]["lam2"].mean()
        bpost = ben[ben["rel"] >= 1]["lam2"].mean()
        ax.axvline(0, color=INK2, lw=0.8)
        ax.set_title(ATTACK_LABELS.get(a, a))
        ax.set_xlabel("Rounds relative to injection")
        if j == 0:
            ax.set_ylabel("Spectral gap λ2(L_t)")
        ax.text(0.02, 0.04, f"post-onset change {100 * (post - pre) / max(pre, 1e-9):+.1f}%\n"
                            f"benign drift {100 * (bpost - pre) / max(pre, 1e-9):+.1f}%",
                transform=ax.transAxes, fontsize=FS_TEXT, color=INK2)
        lo_, hi_ = ax.get_ylim()
        ax.set_ylim(lo_, hi_ + 0.35 * (hi_ - lo_))          # head-room for the legend
        if j == 0:
            ax.legend(loc="upper center", ncol=2)
        # phase plot: structural (lambda2) vs behavioural (max T1) state, mean trajectory
        ax2 = axes[1, j]
        bp = ben[ben["rel"] < 0][["T1", "lam2"]].dropna()
        ax2.scatter(bp["T1"], bp["lam2"], s=8, color="#a9c8f0", alpha=0.5, label="Benign states", lw=0)
        m = att.groupby("rel")[["T1", "lam2", "IPR"]].mean()
        m = m[m.index >= 0]
        if len(m):
            ax2.plot(m["T1"], m["lam2"], color="#8a8985", lw=1.0, zorder=1)
            sc = ax2.scatter(m["T1"], m["lam2"], c=m.index, cmap=cmap, s=30 + 220 * m["IPR"].fillna(0) /
                             max(1e-9, m["IPR"].max()), edgecolor="white", lw=0.8, zorder=2,
                             vmin=0, vmax=max(1, m.index.max()))
            ax2.annotate("t = 0", (m["T1"].iloc[0], m["lam2"].iloc[0]), fontsize=FS_TEXT, xytext=(4, 4),
                         textcoords="offset points")
        ax2.set_xlabel("Behavioural score max T1 (Layer T)")
        if j == 0:
            ax2.set_ylabel("λ2(L_t) (Layer S)")
            ax2.legend(loc="lower left")
    cb = fig.colorbar(plt.cm.ScalarMappable(cmap=cmap), ax=axes[1, :], fraction=0.02, pad=0.01)
    cb.set_label("round after injection\n(size $\\propto$ IPR)")
    fig.suptitle("RQ1: spectral signature of record-mediated attacks (mean, 95% CI)" + _tag(sim))
    return _save(fig, out_dir, "fig_rq1_spectral_signature")


def fig_rq1_localisation(theory: pd.DataFrame, summary: pd.DataFrame, out_dir: str, sim: bool = True) -> str:
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.6))
    ax = axes[0]
    pal = ["#a9c8f0", "#2a78d6", "#0d3b75"]
    for c, (pop, g) in zip(pal, theory.groupby("popular_benign_readers")):
        ax.plot(g["readers"], g["top1"], color=c, marker="o", ms=4, label=f"popular benign record: {pop} readers")
        ax.fill_between(g["readers"], g["lo"], g["hi"], color=c, alpha=0.2, lw=0)
    ax.set_xlabel("Agents reading the poisoned record")
    ax.set_ylabel("Top-1 localisation accuracy")
    ax.set_title("(a) SVD localisation on synthetic B (8 agents, 40 records)", loc="left")
    ax.set_ylim(0, 1.03)
    ax.legend(loc="lower right")
    ax = axes[1]
    s = summary[(summary["defense"] == "ledger") & (summary["attack"] != "benign")]
    topos = list(s["topology"].unique())
    attacks = list(s["attack"].unique())
    x = np.arange(len(attacks))
    w = 0.38
    for k, topo in enumerate(topos):
        g = s[s["topology"] == topo].set_index("attack").reindex(attacks)
        ax.bar(x + (k - 0.5) * w, g["loc_top1_family"].values, w * 0.9, color=["#2a78d6", "#0d3b75"][k % 2],
               label=f"{topo}: top-1 in poisoned family")
        ax.scatter(x + (k - 0.5) * w, g["loc_top1_seed"].values, color="white", edgecolor=INK, zorder=3, s=22,
                   label=f"{topo}: top-1 = injected record" if k == 0 else None)
    ax.set_xticks(x)
    ax.set_xticklabels([ATTACK_LABELS.get(a, a) for a in attacks], rotation=15)
    ax.set_ylim(0, 1.05)
    ax.set_title("(b) Testbed: record reported at first verdict", loc="left")
    ax.set_ylim(0, 1.5)
    ax.set_yticks([0, 0.25, 0.5, 0.75, 1.0])
    ax.legend(loc="upper center", fontsize=FS_TEXT)
    fig.suptitle("RQ1: record-level localisation" + _tag(sim))
    fig.tight_layout()
    return _save(fig, out_dir, "fig_rq1_localisation")


def fig_rq1_ablation(abl: pd.DataFrame, out_dir: str, sim: bool = True) -> str:
    att = abl[abl["attack"] != "benign"].groupby("defense")[["ASR", "UA", "calls_per_task"]].mean()
    ben = abl[abl["attack"] == "benign"].groupby("defense")[["BU", "FPR"]].mean()
    full = att.loc["ledger"]
    d = (att - full).drop(index="ledger")
    dbu = (ben - ben.loc["ledger"]).drop(index="ledger")
    names = list(d.index)
    fig, axes = plt.subplots(1, 4, figsize=(12, 0.36 * len(names) + 1.6), sharey=True)
    for ax, (col, title, src) in zip(axes, [("ASR", "Δ ASR", d), ("UA", "Δ UA", d),
                                            ("BU", "Δ BU (benign)", dbu),
                                            ("calls_per_task", "Δ LLM calls / task", d)]):
        v = src[col].reindex(names).values
        ax.barh(range(len(names)), v, color=["#e34948" if (x > 0) == (col in ("ASR", "calls_per_task")) and x != 0
                                             else "#2a78d6" for x in v], height=0.6)
        ax.axvline(0, color=INK2, lw=0.8)
        ax.set_title(title)
        for i, x in enumerate(v):
            ax.text(x, i, f" {x:+.2f}", va="center", ha="left" if x >= 0 else "right", fontsize=FS_TEXT)
    axes[0].set_yticks(range(len(names)))
    axes[0].set_yticklabels(names)
    axes[0].invert_yaxis()
    fig.suptitle("RQ1: ablations relative to full LEDGER (mean over attacks; red = worse)" + _tag(sim))
    fig.tight_layout()
    return _save(fig, out_dir, "fig_rq1_ablation")


# ===================================================================== RQ2
def fig_rq2_roc(action_df: pd.DataFrame, roc, out_dir: str, sim: bool = True) -> str:
    fpr, tpr, auc, exact_pt, cos_pt = roc
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.8))
    ax = axes[0]
    ax.plot(fpr, tpr, color=COLORS["melon"], label=f"MELON cosine, sweep θ (AUC {auc:.3f})")
    ax.scatter(*cos_pt, color=COLORS["melon"], s=50, zorder=3, label="cosine, θ = 0.8 (MELON default)")
    ax.scatter(*exact_pt, color=COLORS["ledger"], marker="D", s=50, zorder=3, label="exact π equality (no θ)")
    ax.plot([0, 1], [0, 1], color=GRID, lw=1, ls="--")
    ax.set_xlabel("False-positive rate (benign calls flagged)")
    ax.set_ylabel("True-positive rate (attack calls flagged)")
    ax.set_title("(a) Original vs masked-run tool calls", loc="left")
    ax.legend(loc="lower right")
    ax = axes[1]
    b = action_df[~action_df["attack_driven"]]
    a = action_df[action_df["attack_driven"]]
    bins = np.linspace(0, 1, 26)
    ax.hist(b["cosine"], bins=bins, color="#8a8985", alpha=0.7, label=f"benign calls (n={len(b)})", density=True)
    ax.hist(a["cosine"], bins=bins, color=COLORS["melon"], alpha=0.6, label=f"attack calls (n={len(a)})",
            density=True)
    ax.axvline(0.8, color=INK, lw=1, ls="--")
    ax.text(0.81, ax.get_ylim()[1] * 0.9, "θ = 0.8", fontsize=FS_TEXT)
    ax.set_xlabel("max cosine(e(a_t), e(ã_t))")
    ax.set_ylabel("density")
    ax.set_title("(b) Where the cosine threshold sits", loc="left")
    ax.legend()
    fig.suptitle("RQ2: cosine similarity vs exact action-alphabet comparison" + _tag(sim))
    fig.tight_layout()
    return _save(fig, out_dir, "fig_rq2_roc")


def fig_rq2_fisher(fb: pd.DataFrame, alpha_c: float, out_dir: str) -> str:
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.6))
    pal = {3: "#a9c8f0", 4: "#2a78d6", 5: "#1d5fae", 6: "#0d3b75"}
    for q, g in fb.groupby("q"):
        axes[0].plot(g["p"], g["false_confirm"], color=pal.get(q, INK), marker="o", ms=3,
                     label=f"q = {q} (min p = {g['min_p'].iloc[0]:.3f})")
        axes[1].plot(g["p"], g["power"], color=pal.get(q, INK), marker="o", ms=3, label=f"q = {q}")
    axes[0].axhline(alpha_c, color="#e34948", ls="--", lw=1, label=f"α_c = {alpha_c}")
    axes[0].set_xlabel("P(flagged symbol) in both arms (H0: no dependence)")
    axes[0].set_ylabel("False-confirmation rate")
    axes[0].set_title("(a) Bound: P(V3 | no dependence) ≤ α_c", loc="left")
    axes[0].legend()
    axes[1].set_xlabel("Compliance β in the unmasked arm (masked arm 0.02)")
    axes[1].set_ylabel("Confirmation power")
    axes[1].set_title("(b) Power of the one-sided Fisher test", loc="left")
    axes[1].legend()
    fig.suptitle("RQ2: statistical guarantees of the exact confirmation test (Monte Carlo, 20k draws)")
    fig.tight_layout()
    return _save(fig, out_dir, "fig_rq2_fisher")


def fig_rq2_compare(sm: pd.DataFrame, out_dir: str, sim: bool = True) -> str:
    att = sm[sm["attack"] != "benign"].groupby("defense")[["ASR", "UA", "extra_calls_per_task"]].mean()
    ben = sm[sm["attack"] == "benign"].groupby("defense")[["BU", "FPR", "extra_calls_per_task"]].mean()
    order = list(att.index)
    col = {n: (COLORS["ledger"] if "LEDGER" in n and "exact" in n else "#a9c8f0" if "LEDGER" in n
               else COLORS["melon"] if "cosine" in n else COLORS["melon_exact"]) for n in order}
    fig, axes = plt.subplots(1, 5, figsize=(13, 3.0), sharey=True)
    for ax, (m, src, t) in zip(axes, [("ASR", att, "ASR ↓"), ("UA", att, "UA ↑"), ("BU", ben, "BU ↑"),
                                      ("FPR", ben, "Benign runs with alarm ↓"),
                                      ("extra_calls_per_task", att, "Extra LLM calls/task ↓")]):
        v = src[m].reindex(order).values
        ax.barh(range(len(order)), v, color=[col[n] for n in order], height=0.6)
        for i, x in enumerate(v):
            ax.text(x, i, f" {x:.2f}", va="center", fontsize=FS_TEXT)
        ax.set_title(t)
    axes[0].set_yticks(range(len(order)))
    axes[0].set_yticklabels(order)
    axes[0].invert_yaxis()
    fig.suptitle("RQ2: exact π equality vs cosine > θ, inside MELON and inside LEDGER's confirmation"
                 + _tag(sim))
    fig.tight_layout()
    return _save(fig, out_dir, "fig_rq2_exact_vs_cosine")


# ===================================================================== RQ3
def fig_rq3_spread(sp: pd.DataFrame, out_dir: str, sim: bool = True) -> str:
    g = sp.groupby(["topology", "ttl", "beta_r"]).agg(R0=("R0", "first"), agent_index=("agent_index", "first"),
                                                     spread=("spread", "mean"), persist=("persist", "mean")
                                                     ).reset_index()
    topo_c = {"pipeline": "#2a78d6", "cyclic": "#eb6834", "full": "#1baf7a"}
    ttl_m = {1: "o", 2: "s", 3: "^", 4: "D", 6: "v", "never": "X"}
    fig, axes = plt.subplots(1, 3, figsize=(13, 3.9))
    for ax, xcol, title in ((axes[0], "R0", "(a) Record-level index R0 (Eq. 9)"),
                            (axes[1], "agent_index", "(b) Agent-level index βρ(A)/δ (Eq. 5)")):
        for _, r in g.iterrows():
            x = max(r[xcol], 1e-2)
            ax.scatter(x, r["persist"], color=topo_c[r["topology"]], marker=ttl_m.get(r["ttl"], "o"), s=34,
                       edgecolor="white", lw=0.6)
        ax.axvline(1.0, color="#e34948", ls="--", lw=1)
        ax.set_xscale("log")
        ax.set_xlabel(xcol.replace("agent_index", "agent-level index") + " (log; 0 plotted at 0.01)")
        ax.set_ylabel("P(payload still active at end)")
        ax.set_title(title, loc="left")
        ax.set_ylim(-0.03, 1.03)
    from matplotlib.lines import Line2D
    h = [Line2D([], [], color=c, marker="o", ls="", label=t) for t, c in topo_c.items()]
    h += [Line2D([], [], color=INK2, marker=m, ls="", label=f"TTL {t}") for t, m in ttl_m.items()]
    axes[1].legend(handles=h, fontsize=FS_TEXT, loc="center left", bbox_to_anchor=(1.0, 0.5))
    ax = axes[2]
    piv = g.groupby(["topology", "ttl"])["persist"].mean().unstack("ttl")
    cols = [c for c in [1, 2, 3, 4, 6, "never"] if c in piv.columns]
    piv = piv[cols].reindex([t for t in ["pipeline", "cyclic", "full"] if t in piv.index])
    im = ax.imshow(piv.values, cmap=SEQ, vmin=0, vmax=1, aspect="auto")
    for i in range(piv.shape[0]):
        for j in range(piv.shape[1]):
            v = piv.values[i, j]
            ax.text(j, i, f"{v:.2f}", ha="center", va="center", fontsize=FS_TEXT, color="white" if v > 0.6 else INK)
    ax.set_xticks(range(len(cols)))
    ax.set_xticklabels([str(c) for c in cols])
    ax.set_yticks(range(piv.shape[0]))
    ax.set_yticklabels(piv.index)
    ax.set_xlabel("Record lifetime (rounds) = 1/δ_r")
    ax.set_title("(c) Persistence by topology x lifetime", loc="left")
    ax.grid(False)
    fig.colorbar(im, ax=ax, fraction=0.04)
    fig.suptitle("RQ3: when do poisoned records persist? (self-replicating payload, transient seed, no blocking)"
                 + _tag(sim))
    fig.tight_layout()
    return _save(fig, out_dir, "fig_rq3_spread_vs_R0")


def fig_rq3_containment(ct: pd.DataFrame, out_dir: str, sim: bool = True) -> str:
    pal = {"No defense": "#8a8985", "Agent-level (reset agent)": COLORS["agent_graph"], "LEDGER": COLORS["ledger"],
           "LEDGER -Rollback": "#a9c8f0", "LEDGER -Quarantine": "#0d3b75"}
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.6))
    for d, g in ct.groupby("defense", sort=False):
        ls = "--" if d == "No defense" else "-"
        _band(axes[0], g.assign(c=g["compromised"].astype(float)), "round", "c", pal.get(d, INK), d, ls)
        _band(axes[1], g.assign(c=g["active_payload"].astype(float)), "round", "c", pal.get(d, INK), d, ls)
    axes[0].set_ylabel("Agents compromised in round")
    axes[1].set_ylabel("Payload-carrying records alive")
    for ax in axes:
        ax.set_xlabel("Round")
    axes[0].set_title("(a) Agent compromise", loc="left")
    axes[1].set_title("(b) Record reservoir", loc="left")
    axes[0].set_ylim(0, axes[0].get_ylim()[1] * 1.55)
    axes[0].legend(fontsize=FS_TEXT, ncol=2, loc="upper center")
    fig.suptitle("RQ3: record-level vs agent-level containment (cyclic topology, self-replicating)" + _tag(sim))
    fig.tight_layout()
    return _save(fig, out_dir, "fig_rq3_containment")


def fig_rq3_flood(fl: pd.DataFrame, mu: float, out_dir: str, sim: bool = True) -> str:
    pal = {"No defense": "#8a8985", "LEDGER -Grouping": "#a9c8f0", "LEDGER (grouping)": COLORS["ledger"]}
    has_q = "backlog_series" in fl.columns
    fig, axes = plt.subplots(1, 3 if has_q else 2, figsize=(13, 3.8) if has_q else (10, 3.8))
    for d, g in fl.groupby("defense", sort=False):
        a = g.groupby("N")
        k = a["attack_success"].sum()
        n = a["attack_success"].count()
        ci = np.array([wilson(int(kk), int(nn)) for kk, nn in zip(k, n)])
        axes[0].plot(k.index, k / n, color=pal[d], marker="o", label=d)
        axes[0].fill_between(k.index, ci[:, 0], ci[:, 1], color=pal[d], alpha=0.15, lw=0)
        axes[1].plot(a["rho_h"].mean().index, a["rho_h"].mean().values, color=pal[d], marker="o", label=d)
        sub = g[g["N"] == 50]
        if has_q and len(sub):
            S = np.array(sub["backlog_series"].tolist(), dtype=float)
            axes[2].plot(np.arange(S.shape[1]), S.mean(0), color=pal[d], label=d)
    axes[0].set_xscale("log")
    axes[1].set_xscale("log")
    axes[1].set_yscale("log")
    axes[1].axhline(1.0, color="#e34948", ls="--", lw=1)
    axes[1].text(axes[1].get_xlim()[0] * 1.1, 1.1, r"$\rho_h=1$ (stability boundary)", fontsize=FS_TEXT, color="#e34948")
    axes[0].set_xlabel("Flood size N")
    axes[0].set_ylabel("Harmful request executed (ASR)")
    axes[1].set_xlabel("Flood size N")
    axes[1].set_ylabel("Reviewer utilisation ρ_h = λ_h / μ")
    if has_q:
        axes[2].set_xlabel("Round")
        axes[2].set_ylabel("Reviewer backlog (cards)")
        axes[2].set_title("(c) Queue, N = 50", loc="left")
    axes[0].set_title("(a) Harmful approval", loc="left")
    axes[1].set_title("(b) Reviewer load", loc="left")
    axes[0].legend()
    fig.suptitle(f"RQ3: reviewer flooding through the shared database (μ = {mu:g} cards/round)" + _tag(sim))
    fig.tight_layout()
    return _save(fig, out_dir, "fig_rq3_reviewer_flood")


# ===================================================================== RQ4
def fig_rq4_pareto(runs: pd.DataFrame, out_dir: str, sim: bool = True) -> str:
    att = runs[~runs["benign"]].groupby("defense").agg(ASR=("attack_success", "mean"),
                                                         UA=("utility", "mean"),
                                                         extra=("extra_calls_per_task", "mean"))
    ben = runs[runs["benign"]].groupby("defense").agg(BU=("utility", "mean"), extra_b=("extra_calls_per_task", "mean"))
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.8))
    for d in att.index:
        r = att.loc[d]
        axes[0].scatter(r["extra"], r["ASR"], color=COLORS.get(d, INK), marker=MARKERS.get(d, "o"), s=70,
                        label=LABELS.get(d, d))
        axes[1].scatter(ben.loc[d, "extra_b"], ben.loc[d, "BU"], color=COLORS.get(d, INK), marker=MARKERS.get(d, "o"),
                        s=70)
    axes[0].set_xlabel("Extra LLM calls per task under attack")
    axes[0].set_ylabel("ASR (mean over attacks) ↓")
    axes[0].set_title("(a) Security vs cost", loc="left")
    axes[1].set_xlabel("Extra LLM calls per task, benign operation")
    axes[1].set_ylabel("Benign utility BU ↑")
    axes[1].set_title("(b) Utility vs cost (no attack)", loc="left")
    axes[0].legend(loc="center")
    fig.suptitle("RQ4: security-utility-cost trade-off" + _tag(sim))
    fig.tight_layout()
    return _save(fig, out_dir, "fig_rq4_pareto")


def fig_rq4_cost(cost: pd.DataFrame, out_dir: str, sim: bool = True,
                 defenses=("none", "melon", "melon_exact", "agent_graph", "ledger")) -> str:
    fig, axes = plt.subplots(1, 3, figsize=(13, 3.6))
    x = np.arange(len(defenses))
    for k, (ben, lab) in enumerate(((True, "benign"), (False, "under attack"))):
        sub = cost[cost["benign"] == ben].set_index("defense").reindex(defenses)
        w = 0.38
        off = (k - 0.5) * w
        style = dict(color=[COLORS[d] for d in defenses], alpha=1.0 if ben else 0.55, width=w * 0.92)
        axes[0].bar(x + off, sub["calls_per_task"], **style, label=lab)
        axes[1].bar(x + off, sub["latency_per_task_s"], **style, label=lab)
        axes[2].bar(x + off, sub["energy_per_task_J"], **style, label=lab)
    for ax, t in zip(axes, ("LLM calls per task", "Latency per task (s)", r"Energy per task (J), $E=\bar{P}\,t$")):
        ax.set_xticks(x)
        ax.set_xticklabels([LABELS[d] for d in defenses], rotation=20, ha="right")
        ax.set_title(t)
    from matplotlib.patches import Patch
    axes[0].legend(handles=[Patch(color=INK2, alpha=1.0, label="benign runs"),
                            Patch(color=INK2, alpha=0.55, label="attacked runs")], loc="upper center", ncol=2)
    for ax in axes:
        ax.set_ylim(0, ax.get_ylim()[1] * 1.22)
    fig.suptitle("RQ4: edge cost per task (laptop-GPU 8B profile)" + _tag(sim))
    fig.tight_layout()
    return _save(fig, out_dir, "fig_rq4_cost")


def fig_rq4_scaling(sc: pd.DataFrame, dev: pd.DataFrame, out_dir: str, sim: bool = True) -> str:
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.6))
    ax = axes[0]
    ax.plot(sc["T"], sc["MELON"], color=COLORS["melon"], label="MELON: one masked re-run per step")
    ax.plot(sc["T"], sc["LEDGER under attack"], color=COLORS["ledger"], label="LEDGER under attack")
    ax.plot(sc["T"], sc["LEDGER benign"], color=COLORS["ledger"], ls="--", label="LEDGER benign")
    ax.set_xlabel("Agent steps per task T")
    ax.set_ylabel("Extra LLM calls per task")
    ax.set_title("(a) Re-execution cost scales with steps (MELON) or alarms (LEDGER)", loc="left")
    ax.legend()
    ax = axes[1]
    devs = list(dev["device"].unique())
    ds = ["none", "melon", "ledger"]
    x = np.arange(len(devs))
    w = 0.27
    for k, d in enumerate(ds):
        v = [dev[(dev["device"] == dv) & (dev["defense"] == d) & (dev["benign"])]["energy_J"].mean() for dv in devs]
        ax.bar(x + (k - 1) * w, v, w * 0.92, color=COLORS[d], label=LABELS[d])
    ax.set_xticks(x)
    ax.set_xticklabels(devs, rotation=10)
    ax.set_ylabel("Energy per benign task (J)")
    ax.set_title("(b) Device profiles (assumed; replace with measurements)", loc="left")
    ax.set_ylim(0, ax.get_ylim()[1] * 1.3)
    ax.legend(ncol=3, loc="upper center")
    fig.suptitle("RQ4: scaling and device sensitivity" + _tag(sim))
    fig.tight_layout()
    return _save(fig, out_dir, "fig_rq4_scaling_devices")


# ===================================================================== paper figures (Fig. 2 and Fig. 3)
PAPER_ATTACKS = [("hijack", "One-shot\nhijack"), ("inplan", "In-alphabet\nhijack"), ("selfrep", "Self-\nreplicating"),
                 ("flood", "Reviewer\nflood"), ("stealth", "Stealth\n(adaptive)")]


def fig_paper_asr_ua(summary: pd.DataFrame, out_dir: str, topology: str = "pipeline",
                     defenses=("none", "melon", "ledger"), title: Optional[str] = None) -> str:
    """Paper Fig. 2: per-attack ASR (top) and utility under attack (bottom), one topology, three defenses,
    Wilson 95% CIs. Source: results/data/rq1_summary.csv."""
    s = summary[(summary["topology"] == topology) & (summary["attack"] != "benign")]
    atts = [(a, l) for a, l in PAPER_ATTACKS if a in set(s["attack"])]
    fig, axes = plt.subplots(2, 1, figsize=(7.0, 5.4), sharex=True)
    x = np.arange(len(atts))
    w = 0.8 / len(defenses)
    for k, d in enumerate(defenses):
        sub = s[s["defense"] == d].set_index("attack").reindex([a for a, _ in atts])
        for ax, m in zip(axes, ["ASR", "UA"]):
            v = sub[m].to_numpy(float)
            err = np.clip(np.vstack([v - sub[m + "_lo"].to_numpy(float), sub[m + "_hi"].to_numpy(float) - v]), 0, None)
            ax.bar(x + (k - (len(defenses) - 1) / 2) * w, v, w, color=COLORS[d], label=LABELS[d],
                   yerr=np.nan_to_num(err), error_kw={"elinewidth": 0.9, "capsize": 2.5, "ecolor": INK})
    for ax, lab in zip(axes, ["Attack success rate", "Utility under attack"]):
        ax.set_ylabel(lab)
        ax.set_ylim(0, 1.05)
        ax.grid(axis="x", visible=False)
    axes[1].set_xticks(x)
    axes[1].set_xticklabels([l for _, l in atts])
    axes[0].legend(ncol=len(defenses), loc="lower center", bbox_to_anchor=(0.5, 1.0))
    if title:
        fig.suptitle(title)
    fig.tight_layout(h_pad=0.6)
    return _save(fig, out_dir, "fig_paper_asr_ua")


def fig_paper_containment(persist: pd.DataFrame, flood: pd.DataFrame, out_dir: str,
                          title: Optional[str] = None) -> str:
    """Paper Fig. 3: (a) P(payload persists) by topology x record lifetime, (b) reviewer load rho_h vs flood size.
    Sources: results/tables/table_rq3_persistence.csv and results/data/rq3_flood.csv."""
    p = persist.copy()
    if "topology" in p.columns:
        p = p.set_index("topology")
    p.columns = [str(c) for c in p.columns]
    cols = [c for c in ["1", "2", "3", "4", "6", "never"] if c in p.columns]
    p = p.reindex([t for t in ["pipeline", "cyclic", "full"] if t in p.index])[cols]
    fig, (a, b) = plt.subplots(1, 2, figsize=(9.6, 3.9), gridspec_kw={"width_ratios": [1.25, 1]})
    a.imshow(p.values.astype(float), cmap="Blues", vmin=0, vmax=1, aspect="auto")
    for i in range(p.shape[0]):
        for j in range(p.shape[1]):
            v = float(p.values[i, j])
            a.text(j, i, f"{v:.2f}", ha="center", va="center", fontsize=FS_TEXT, color="white" if v > 0.55 else INK)
    a.set_xticks(range(len(cols)))
    a.set_xticklabels(cols)
    a.set_yticks(range(p.shape[0]))
    a.set_yticklabels(p.index)
    a.set_xlabel(r"Record lifetime $1/\delta_r$ (rounds)")
    a.set_title("(a) P(payload persists)")
    a.grid(False)
    for sp in a.spines.values():
        sp.set_visible(False)
    g = flood.groupby(["N", "defense"])["rho_h"].mean().unstack()
    style = {"No defense": ("#8a8985", "o", "No defense"), "LEDGER -Grouping": ("#9cc3f0", "s", "LEDGER w/o grouping"),
             "LEDGER (grouping)": (COLORS["ledger"], "^", "LEDGER")}
    for d, (c, mk, lab) in style.items():
        if d in g.columns:
            b.plot(g.index, g[d], color=c, marker=mk, ms=6, lw=2, label=lab)
    b.axhline(1, ls="--", lw=1.2, color="#d03b3b")
    b.set_xscale("log")
    b.set_yscale("log")
    b.set_ylim(0.03, 80)
    b.text(g.index.max(), 1.25, r"$\rho_h=1$ (stability)", color="#d03b3b", fontsize=FS_TEXT, ha="right", va="bottom")
    b.set_xlabel("Flood size $N$")
    b.set_ylabel(r"Reviewer load $\rho_h$")
    b.set_title("(b) Reviewer flooding")
    b.legend(loc="center right", bbox_to_anchor=(1.0, 0.33))
    if title:
        fig.suptitle(title)
    fig.tight_layout(w_pad=1.2)
    return _save(fig, out_dir, "fig_paper_containment")


def fig_rq2_sensitivity(sens: pd.DataFrame, out_dir: str, sim: bool = True) -> str:
    """RQ2 (d): sensitivity of benign utility / alarms to the masked-run assumption."""
    fig, ax = plt.subplots(1, 2, figsize=(10, 3.8))
    for d, g in sens.groupby("defense"):
        m = g.groupby("p_ctx_driven").mean(numeric_only=True)
        ax[0].plot(m.index, m.BU, marker="o", color=COLORS.get(d, INK), label=LABELS.get(d, d))
        ax[1].plot(m.index, m.alarm, marker="o", color=COLORS.get(d, INK), label=LABELS.get(d, d))
    ax[0].set_ylabel("Benign utility BU")
    ax[1].set_ylabel("Benign runs with alarm/stop")
    for a in ax:
        a.set_xlabel("P(masked run reproduces a content-driven benign call)")
    ax[0].legend()
    fig.suptitle("RQ2: sensitivity to the masked-run assumption" + _tag(sim))
    fig.tight_layout()
    return _save(fig, out_dir, "fig_rq2_sensitivity")
