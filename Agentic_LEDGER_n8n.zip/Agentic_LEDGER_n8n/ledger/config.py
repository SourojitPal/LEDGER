"""Experiment configuration.

Every default below is tied to a symbol in the paper
("Trust, but Roll Back: Record-Level Defense Against Indirect Prompt Injection
for Pervasive Agents", PerAgents 2027). The comment after each field names the
paper symbol / equation it instantiates.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict, replace
from typing import Optional, Dict


@dataclass
class EdgeProfile:
    """Edge-device cost model used for Eq. (6): E ~= P_bar * t_total.

    In ``sim`` mode latency per LLM call is modelled as
    overhead + prompt_tokens/prefill_tps + completion_tokens/decode_tps.
    In ``ollama``/``openai`` mode the wall-clock time is *measured* and only
    ``power_w`` is used (or replaced by nvidia-smi samples, see energy.py).
    Defaults approximate an 8B model (qwen3:8b, Q4) on a laptop RTX GPU; replace
    them with your own measurements on the MSI laptop before reporting.
    """
    name: str = "laptop-gpu-8B"
    overhead_s: float = 0.20      # per-call fixed latency (s)
    prefill_tps: float = 900.0    # prompt tokens / s
    decode_tps: float = 30.0      # completion tokens / s
    power_w: float = 70.0         # P_bar in Eq. (6), Watts
    embed_call_s: float = 0.03    # one embedding call (MELON uses embeddings, Eq. 3)


@dataclass
class Config:
    # ------------------------------------------------------------------ backend
    backend: str = "sim"                 # "sim" | "ollama" | "openai"
    llm_model: str = "qwen3:8b"          # Ollama model or OpenAI model name
    ollama_url: str = "http://localhost:11434"
    openai_base_url: str = "https://api.openai.com/v1"
    embed_backend: str = "hash"          # "hash" | "ollama" | "openai"  (encoder phi, Eq. 10; e(.) Eq. 3-4)
    embed_model: str = "nomic-embed-text"
    llm_temperature: float = 0.7         # >0 so masked/unmasked re-runs are stochastic (Sec. III-E)
    llm_timeout_s: float = 120.0

    # ----------------------------------------------------------------- testbed
    scenario: str = "smart_building"
    topology: str = "pipeline"           # "pipeline" (acyclic) | "cyclic" | "full"   (RQ3)
    n_rounds: int = 12                   # user tasks per run
    t_inject: int = 3                    # round at which the adversary writes the U record
    record_ttl: Optional[int] = 6        # record lifetime in rounds; 1/delta_r (Eq. 9). None = never expires
    memory_rounds: int = 2               # agent context memory; 1/delta_a (Eq. 9)
    rag_k: int = 3                       # k in R(q) = top-k cos(e(q), e(m))  (Eq. 4)
    seed_visible_rounds: Optional[int] = None  # None: seed stays until TTL; int: adversary deletes it (RQ3 transient seed)

    # ------------------------------------------- simulated agent (sim backend only)
    beta_r: float = 0.75                 # P(agent complies | reads payload)   beta_r in Eq. (9)
    beta_w: float = 0.8                  # P(compromised write carries payload) beta_w in Eq. (9)
    benign_error: float = 0.03           # legit agent mistakes (false violations of Layer F)
    p_ctx_driven: float = 0.10           # masked run (MELON) reproduces a content-driven benign call
    p_near_miss: float = 0.6             # ... with an argument that differs (e.g. set-point +/-1)
    memory_note_prob: float = 0.6        # agent also writes a retrievable memory note

    # ------------------------------------------------------------------ attacks
    flood_n: int = 50                    # N in the reviewer-flood attack (RQ3)

    # -------------------------------------------------------------------- LEDGER
    alpha: float = 0.05                  # anomaly level, Eq. (11)
    alpha_c: float = 0.05                # confirmation level (Fisher exact test)
    q: int = 4                           # re-runs per arm (masked / unmasked)
    window: int = 2                      # Delta (rounds) for W_t, B_t, R0-hat  (Eq. 8, 9)
    top_k_local: int = 3                 # top-k localised records intersected with provenance
    traj_len: int = 8                    # outputs per agent in X_i (Eq. 10)
    traj_gamma: float = 0.05             # gamma in x_k = (phi(o_k), gamma k)  (Eq. 10)
    cusum_k: float = 0.5                 # Page CUSUM reference value
    use_layer_f: bool = True
    bind_extractors: bool = True         # extractor slots carry chi(plan-designated source) (Layer F)
    use_layer_s: bool = True
    use_layer_t: bool = True
    use_confirm: bool = True
    use_rollback: bool = True
    use_quarantine: bool = True
    use_grouping: bool = True
    confirm_compare: str = "exact"       # "exact" (pi equality, LEDGER) | "cosine" (RQ2 ablation)
    always_confirm: bool = False         # ablation: confirm every U-provenance action (no evidence gating)

    # ------------------------------------------------------------------ MELON
    melon_theta: float = 0.8             # theta in Eq. (3); MELON's code uses 0.8

    # ---------------------------------------------------------- human reviewer h
    reviewer_mu: float = 3.0             # mu, cards served per round   (rho_h = lambda_h / mu)
    reviewer_p0: float = 0.9             # P(reviewer spots a harmful request | rested)
    reviewer_kappa: float = 8.0          # fatigue scale: p = p0 * exp(-backlog / kappa)
    approval_deadline: int = 2           # rounds a task waits for approval
    group_suspicious_size: int = 3       # a card with more requests than this from one U source is scrutinised

    edge: EdgeProfile = field(default_factory=EdgeProfile)

    def with_(self, **kw) -> "Config":
        return replace(self, **kw)

    def to_dict(self) -> Dict:
        d = asdict(self)
        return d


# Named defense configurations used throughout the experiments ----------------
DEFENSES = ["none", "melon", "melon_exact", "agent_graph", "ledger"]

ABLATIONS = {
    "ledger": {},
    "-F (no plan monitor)": {"use_layer_f": False},
    "-SourceBinding": {"bind_extractors": False},
    "-S (no spectral layer)": {"use_layer_s": False},
    "-T (no topology layer)": {"use_layer_t": False},
    "-Confirm": {"use_confirm": False},
    "-Rollback": {"use_rollback": False},
    "-Quarantine": {"use_quarantine": False},
    "-Grouping": {"use_grouping": False},
    "always-confirm": {"always_confirm": True},
    "cosine-confirm": {"confirm_compare": "cosine"},
}
