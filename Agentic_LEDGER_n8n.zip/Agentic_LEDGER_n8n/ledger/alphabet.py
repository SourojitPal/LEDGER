"""Finite action alphabet Sigma = F x Theta and the abstraction map pi (Sec. III-B).

pi(call) keeps the tool name, the *exact normalised value* of every
high-consequence argument (recipients, actuator targets/values, payment targets,
database-write targets ...) and only the *type class* of every other argument.
Two calls "match" iff their symbols are equal -- this exact comparison replaces
MELON's embedding cosine similarity + threshold (Eq. 3) in LEDGER's confirmation
test (Contribution 2).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Any, List, Tuple


@dataclass(frozen=True)
class ToolSpec:
    name: str
    args: Tuple[Tuple[str, str], ...]          # (arg name, type class)
    hc_args: Tuple[str, ...] = ()              # high-consequence arguments (sinks needing clearance T)
    actuating: bool = True                      # touches the physical world / external state


@dataclass
class ToolCall:
    tool: str
    args: Dict[str, Any] = field(default_factory=dict)
    agent: str = ""
    meta: Dict[str, Any] = field(default_factory=dict)   # ground-truth tags; never part of pi or text

    def text(self) -> str:
        """MELON's textual form of a tool call (``transform_tool_calls``)."""
        inner = ", ".join(f"{k} = {v}" for k, v in self.args.items() if not str(k).startswith("_"))
        return f"{self.tool}({inner})"


def norm_value(v: Any) -> str:
    if isinstance(v, bool):
        return str(v).lower()
    if isinstance(v, (int, float)):
        f = float(v)
        return str(int(f)) if f.is_integer() else f"{f:.3g}"
    s = str(v).strip().lower()
    try:
        f = float(s)
        return str(int(f)) if f.is_integer() else f"{f:.3g}"
    except ValueError:
        return " ".join(s.split())


class Alphabet:
    def __init__(self, specs: List[ToolSpec]):
        self.specs: Dict[str, ToolSpec] = {s.name: s for s in specs}

    def pi(self, call: ToolCall) -> str:
        spec = self.specs.get(call.tool)
        if spec is None:
            # unknown tool: the symbol is the name plus all argument values (still exact)
            parts = [call.tool] + [f"{k}={norm_value(v)}" for k, v in sorted(call.args.items())]
            return "|".join(parts)
        parts = [spec.name]
        for name, cls in spec.args:
            if name in spec.hc_args:
                parts.append(f"{name}={norm_value(call.args.get(name, ''))}")
            else:
                parts.append(f"{name}:{cls}")
        return "|".join(parts)

    def match(self, a: ToolCall, b: ToolCall) -> bool:
        """compare.match in the code plan: true iff pi(a) == pi(b)."""
        return self.pi(a) == self.pi(b)

    def is_hc(self, call: ToolCall) -> bool:
        spec = self.specs.get(call.tool)
        return bool(spec and spec.actuating)

    def __len__(self) -> int:
        return len(self.specs)
