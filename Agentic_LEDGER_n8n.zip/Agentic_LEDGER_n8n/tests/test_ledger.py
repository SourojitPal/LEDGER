"""Unit and integration tests (python -m unittest discover -s tests -v)."""
import os
import random
import sys
import unittest

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ledger.alphabet import ToolCall
from ledger import scenario as S
from ledger.config import Config
from ledger.events import join, T, U
from ledger.db import SharedDB
from ledger.embed import HashEmbedder
from ledger.defense.layer_f import PlanDFA, Monitor, mincut_bits, extract
from ledger.defense.layer_s import normalized_laplacian, lambda2, localize, r0_hat, quarantine_cut
from ledger.defense.layer_t import h0_diagram, h1_diagram, wasserstein, trajectory_points, max_consecutive_step
from ledger.defense.confirm import fisher_confirm, min_p_value
from ledger.defense.calibrate import conformal_p, PageCUSUM
from ledger.defense.contain import Reviewer, Request
from ledger.testbed import Testbed
from scipy.spatial.distance import pdist, squareform


class TestLayerF(unittest.TestCase):
    def setUp(self):
        self.task = S.Task("task0", "hvac", 0, "B", "D1", {"setpoint": 21, "vendor": "Acme HVAC"}, "u")
        self.plan = S.compile_plan(self.task)

    def test_pi_exact_hc_and_class_for_text(self):
        a = ToolCall("notify_occupants", {"zone": "B", "text": "hello"})
        b = ToolCall("notify_occupants", {"zone": "b", "text": "completely different words"})
        c = ToolCall("set_hvac", {"zone": "B", "setpoint": 21})
        d = ToolCall("set_hvac", {"zone": "B", "setpoint": 22})
        self.assertTrue(S.ALPHABET.match(a, b))        # free text -> class only
        self.assertFalse(S.ALPHABET.match(c, d))       # high-consequence value is exact

    def test_dfa_prefix_and_order(self):
        dfa = PlanDFA(self.plan)
        q = dfa.q0
        self.assertIsNone(dfa.delta(q, "actuator", ToolCall("notify_occupants", {"zone": "B", "text": "x"})))
        q = dfa.delta(q, "actuator", ToolCall("set_hvac", {"zone": "B", "setpoint": 22}))
        self.assertIsNotNone(q)
        q = dfa.delta(q, "actuator", ToolCall("notify_occupants", {"zone": "B", "text": "x"}))
        self.assertTrue(dfa.accepting(q))
        self.assertEqual(dfa.n_states(), 3)

    def test_monitor_blocks_unplanned_and_out_of_codomain(self):
        m = Monitor(S.ALPHABET)
        m.load(self.plan)
        self.assertFalse(m.check("task0", "actuator", ToolCall("unlock_door", {"door": "D3"}), U)[0])
        self.assertFalse(m.check("task0", "actuator", ToolCall("set_hvac", {"zone": "B", "setpoint": 35}), U)[0])
        self.assertTrue(m.check("task0", "actuator", ToolCall("set_hvac", {"zone": "B", "setpoint": 28}), U)[0])

    def test_source_binding_and_repair(self):
        m = Monitor(S.ALPHABET)
        m.load(self.plan)
        m.bind("task0", {"s1.setpoint": 21})
        bad = ToolCall("set_hvac", {"zone": "B", "setpoint": 28})        # in codomain, wrong source
        self.assertFalse(m.check("task0", "actuator", bad, U)[0])
        fixed = m.repair("task0", "actuator", bad)
        self.assertEqual(fixed.args["setpoint"], 21)
        self.assertTrue(m.check("task0", "actuator", fixed, U)[0])

    def test_system_extractor_reads_designated_ticket(self):
        db = SharedDB(HashEmbedder(), ttl=None)
        db.write("external", "ticket", "Maintenance ticket 0: zone B overheating; recommended set-point 22 C.", U, [], 0)
        db.write("external", "vendor_email", "recommended set-point 28 C", U, [], 0)
        vals = S.system_extract(self.task, self.plan, list(db.records.values()))
        self.assertEqual(vals["s1.setpoint"], 22)

    def test_extractor_finite_codomain(self):
        self.assertEqual(extract("22", S.SETPOINTS), 22)
        self.assertIsNone(extract("99", S.SETPOINTS))

    def test_mincut_bits(self):
        self.assertAlmostEqual(mincut_bits(self.plan), np.log2(len(S.SETPOINTS)), places=6)
        door = S.compile_plan(S.Task("t", "door", 0, "A", "D1", {"setpoint": 21, "vendor": "Acme HVAC"}, "u"))
        self.assertAlmostEqual(mincut_bits(door), np.log2(len(S.VENDORS)), places=6)
        status = S.compile_plan(S.Task("t", "status", 0, "A", "D1", {}, "u"))
        self.assertEqual(mincut_bits(status), 0.0)


class TestProvenance(unittest.TestCase):
    def test_label_join(self):
        self.assertEqual(join([T, T]), T)
        self.assertEqual(join([T, U]), U)

    def test_rollback_closure_and_expiry(self):
        db = SharedDB(HashEmbedder(), ttl=2)
        a = db.write("external", "vendor_email", "x", U, [], 0)
        b = db.write("maintenance", "workorder", "y", U, [a.rid], 0)
        c = db.write("planner", "plan", "z", U, [b.rid], 1)
        d = db.write("planner", "plan", "w", U, [], 1)
        self.assertEqual(db.rollback([a.rid]), {a.rid, b.rid, c.rid})
        self.assertFalse(db.records[d.rid].rolled_back)
        self.assertFalse(db.alive(db.records[d.rid], 3))


class TestLayerS(unittest.TestCase):
    def test_hoffman_wielandt(self):
        rng = np.random.default_rng(0)
        for _ in range(200):
            A = rng.random((5, 5)); A = A + A.T
            B = rng.random((5, 5)); B = B + B.T
            L1, L2 = normalized_laplacian(A), normalized_laplacian(B)
            self.assertLessEqual(abs(lambda2(L1) - lambda2(L2)), np.linalg.norm(L1 - L2, "fro") + 1e-9)

    def test_acyclic_r0_zero(self):
        RW = np.array([[0, 0, 0], [1, 0, 0], [0, 1, 0.]])   # strictly lower triangular = DAG
        rho = float(np.max(np.abs(np.linalg.eigvals(RW))))
        self.assertAlmostEqual(rho, 0.0)
        self.assertEqual(r0_hat(rho, 0.9, 0.9, 0.5, 0.1), 0.0)

    def test_quarantine_reaches_r0_below_one(self):
        pairs = {("a", "b"): 1.0, ("b", "a"): 1.0, ("c", "a"): 0.5, ("a", "c"): 0.5}
        cuts, r0 = quarantine_cut(pairs, ["a", "b", "c"], 0.9, 0.9, 0.5, 0.25)
        self.assertLess(r0, 1.0)
        self.assertTrue(cuts)

    def test_localisation_peaks_at_widely_read_record(self):
        B = np.zeros((4, 6)); B[0, 1] = B[1, 2] = B[2, 3] = 1; B[:, 0] = 1.5
        top, ipr, _ = localize(B, [f"r{i}" for i in range(6)], 1)
        self.assertEqual(top[0], "r0")


class TestLayerT(unittest.TestCase):
    def test_spanning_path_lemma(self):
        rng = np.random.default_rng(1)
        for _ in range(50):
            embs = [rng.normal(size=8) for _ in range(7)]
            X = trajectory_points(embs, 0.1)
            D = squareform(pdist(X))
            t1 = max(d for _, d in h0_diagram(D))
            self.assertLessEqual(t1, max_consecutive_step(X) + 1e-9)

    def test_h1_detects_a_loop(self):
        th = np.linspace(0, 2 * np.pi, 12, endpoint=False)
        X = np.c_[np.cos(th), np.sin(th)]
        dg = h1_diagram(squareform(pdist(X)))
        self.assertTrue(max(d - b for b, d in dg) > 0.5)

    def test_wasserstein_identity_and_symmetry(self):
        a, b = [(0, 1.0), (0, 0.5)], [(0, 0.8)]
        self.assertAlmostEqual(wasserstein(a, a), 0.0)
        self.assertAlmostEqual(wasserstein(a, b), wasserstein(b, a))


class TestConfirmation(unittest.TestCase):
    def test_min_p_values(self):
        self.assertAlmostEqual(min_p_value(3), 0.05)
        self.assertAlmostEqual(min_p_value(4), 1 / 70)
        ok, p = fisher_confirm(4, 0, 4, 0.05)
        self.assertTrue(ok)
        self.assertAlmostEqual(p, 1 / 70)
        self.assertFalse(fisher_confirm(2, 2, 4, 0.05)[0])

    def test_false_confirmation_bound(self):
        rng = np.random.default_rng(2)
        for p in (0.2, 0.5, 0.9):
            rej = np.mean([fisher_confirm(int(rng.binomial(4, p)), int(rng.binomial(4, p)), 4, 0.05)[0]
                           for _ in range(4000)])
            self.assertLessEqual(rej, 0.05)


class TestCalibrationAndHITL(unittest.TestCase):
    def test_conformal(self):
        self.assertAlmostEqual(conformal_p(10.0, [1, 2, 3]), 0.25)
        self.assertAlmostEqual(conformal_p(0.0, [1, 2, 3]), 1.0)

    def test_cusum(self):
        c = PageCUSUM(0.5, 3.0)
        self.assertFalse(any(c.update(0.0) for _ in range(20)))
        self.assertTrue(any(c.update(2.0) for _ in range(5)))

    def test_grouping_caps_cards(self):
        rv = Reviewer(3, 0.9, 8, random.Random(0))
        reqs = [Request(ToolCall("x"), "planner", "t", frozenset({"r9"}), i == 7, 0) for i in range(100)]
        self.assertEqual(rv.submit(reqs, 0, grouping=True), 1)
        rv2 = Reviewer(3, 0.9, 8, random.Random(0))
        self.assertEqual(rv2.submit(reqs, 0, grouping=False), 100)


class TestEndToEnd(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from ledger.experiments import calibrate
        cls.cfg = Config(n_rounds=10)
        cls.cal = calibrate(cls.cfg, n_runs=40, n_attack=10, verbose=False)

    def test_undefended_hijack_succeeds_and_ledger_blocks(self):
        succ_none = [Testbed(self.cfg, "none", "hijack", s).run().attack_success for s in range(8)]
        succ_led = [Testbed(self.cfg, "ledger", "hijack", s, calibration=self.cal).run().attack_success
                    for s in range(8)]
        self.assertGreaterEqual(sum(succ_none), 6)
        self.assertEqual(sum(succ_led), 0)

    def test_confirmation_and_rollback_happen(self):
        runs = [Testbed(self.cfg, "ledger", "selfrep", s, calibration=self.cal).run() for s in range(6)]
        conf = [r for r in runs if any(v["verdict"] == "V3" for v in r.verdicts)]
        self.assertGreaterEqual(len(conf), 3)
        self.assertTrue(all(r.gt["rolled_back"] for r in conf))

    def test_reproducible(self):
        a = Testbed(self.cfg, "ledger", "selfrep", 3, calibration=self.cal).run()
        b = Testbed(self.cfg, "ledger", "selfrep", 3, calibration=self.cal).run()
        self.assertEqual([v["verdict"] for v in a.verdicts], [v["verdict"] for v in b.verdicts])
        self.assertEqual(a.cost["agent_calls"], b.cost["agent_calls"])

    def test_stealth_in_alphabet_attack_blocked_by_source_binding(self):
        succ = [Testbed(self.cfg, "ledger", "stealth", s, calibration=self.cal).run().attack_success for s in range(8)]
        self.assertEqual(sum(succ), 0)

    def test_benign_runs_no_false_confirmation(self):
        v3 = sum(any(v["verdict"] == "V3" for v in Testbed(self.cfg, "ledger", None, 500 + s,
                                                             calibration=self.cal).run().verdicts)
                 for s in range(20))
        self.assertLessEqual(v3, 1)


if __name__ == "__main__":
    unittest.main()
