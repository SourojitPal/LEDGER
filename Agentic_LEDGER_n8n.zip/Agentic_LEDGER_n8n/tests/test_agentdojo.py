"""E1 plumbing test (skipped unless agentdojo is installed and MELON's pi_detector.py is found)."""
import importlib.util
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

HAVE = importlib.util.find_spec("agentdojo") is not None


@unittest.skipUnless(HAVE, "agentdojo not installed")
class TestE1Plumbing(unittest.TestCase):
    def test_alphabet(self):
        from integrations.agentdojo_melon.agentdojo_alphabet import exact_match
        self.assertTrue(exact_match("send_money(recipient = X, amount = 10, subject = a)",
                                    "send_money(recipient = X, amount = 10.0, subject = other words)"))
        self.assertFalse(exact_match("send_money(recipient = X, amount = 10)", "send_money(recipient = Y, amount = 10)"))

    def test_offline_selftest(self):
        from integrations.agentdojo_melon.melon_loader import default_melon_path
        try:
            path = default_melon_path()
        except FileNotFoundError:
            self.skipTest("MELON pi_detector.py not found")
        from integrations.agentdojo_melon.ledger_agentdojo import offline_selftest
        _, summ = offline_selftest("banking", user_tasks=("user_task_0",), injection_tasks=("injection_task_0",),
                                   melon_path=path, logdir=os.path.join("results", "agentdojo_selftest_test"))
        self.assertEqual(set(summ.defense), {"none", "melon", "melon_exact", "ledger"})


if __name__ == "__main__":
    unittest.main()
