# Agentic_LEDGER

Code for **"Trust, but Roll Back: Record-Level Defense Against Indirect Prompt Injection for
Pervasive Agents"** (PerAgents 2027 @ PerCom 2027).

## Run

```bat
cd C:\Users\souro\Documents\MyMLCodes1\Agentic_LEDGER
pip install -r requirements.txt        (Anaconda already has all of them)
jupyter notebook LEDGER_Experiments.ipynb
```

Then **Kernel → Restart & Run All**. `RUN_MODE = "quick"` in the first code cell gives a
3–4 minute smoke run; `"full"` (default) produces the paper numbers in roughly 25–35 minutes
(most of it is calibration, cached in `results/cache/` for later runs).

**OpenAI key:** open `api_keys.py` and paste it between the quotes (`OPENAI_API_KEY = "sk-..."`).
It is needed only for Section 9 with `backend="openai"` and Section 10 (AgentDojo).

**AgentDojo / MELON (Section 10):** `pip install -r requirements-e1.txt` (Python ≥ 3.10; installs
`agentdojo==0.1.29`). MELON's `pi_detector.py` is read from your `...\3. PERAGENT\Melon` folder
(path in the notebook cell `MELON_PATH`). Section 10a is an offline self-test (no key); set
`RUN_E1 = True` in 10b for the real run.
Outputs:

| Folder | Content |
|---|---|
| `results/tables/` | LaTeX (`.tex`, booktabs) and CSV tables for RQ1–RQ4, ablations, formal checks |
| `results/figures/` | every figure as PNG (300 dpi) and PDF |
| `results/data/` | per-run CSV data (re-plot without re-running) |
| `results/summary_of_findings.md` | numbers quoted in the notebook's summary |
| `results/cache/` | calibration (delete to recalibrate) |

## Layout

```
LEDGER_Experiments.ipynb     main notebook (calls the package below)
ledger/
  config.py                  every parameter, annotated with the paper symbol it sets
  events.py  db.py           event log; shared database with labels T/U and provenance DAG
  alphabet.py                Sigma = F x Theta and the abstraction map pi (exact symbols)
  scenario.py                smart-building team (monitor, maintenance, planner, actuator, reviewer h), tasks, attacks
  agents.py  llm.py          simulated agents / real LLM agents (Ollama, OpenAI) ; HTTP clients (stdlib only)
  embed.py                   hashed encoder (offline) or Ollama/OpenAI embeddings
  testbed.py                 orchestrator: reads, writes, messages, tool calls, approvals; chain-replay re-execution
  defense/layer_f.py         trusted planner, plan DAG, DFA monitor (Eq. 7), sinks/extractors, min-cut bits
  defense/layer_s.py         W_t, normalized Laplacian, S1, R0 (Eq. 8-9), SVD localisation, quarantine cut
  defense/layer_t.py         Vietoris-Rips H0/H1, T1-T3 (Eq. 10), Wasserstein, corroboration
  defense/calibrate.py       conformal p-values + Bonferroni (Eq. 11), Page CUSUM
  defense/confirm.py         one-sided Fisher exact test, minimum p-value
  defense/contain.py         reviewer model, grouping by source record
  defense/pipeline.py        No defense, MELON, MELON-exact, agent-level graph, LEDGER (+ probe for RQ2)
  metrics.py experiments.py plots.py
tests/                       28 unit/integration tests (python -m unittest discover -s tests)
integrations/agentdojo_melon E1 on AgentDojo: MELON loader (your pi_detector.py), MELON-exact, single-agent LEDGER, runner
api_keys.py                  the one place for your OpenAI key
ledger/energy.py             nvidia-smi power meter; measured edge profile (results/edge_profile.json)
PAPER_SYNC.md                what the code implements vs. what the PDF currently says (please read)
```

## Backends

* `Config(backend="sim")` – seeded stochastic agents; fast and exactly reproducible. Figures are tagged **[SIM]**.
* `Config(backend="ollama", llm_model="qwen3:8b", embed_backend="ollama")` – local edge models.
* `Config(backend="openai", llm_model="gpt-4o-mini")` – needs `OPENAI_API_KEY` in the environment.

The defense code is identical across backends; only the agents that read and write the shared database change.

## Live n8n evaluation

LEDGER copies of the two n8n Cloud workflows are in `integrations/n8n/` (see its README). After exporting the `ledger_runs` data table to `integrations/n8n/data/ledger_runs.csv`, analyse the runs with `LEDGER_n8n_Live.ipynb`.
