# Code ↔ paper synchronisation notes

The code follows Sections II–III of the current PDF. Where the PDF is silent or still a draft, the
code had to make a choice; each choice is listed here so the text can say the same thing.

## A. Places where the PDF should be updated

| # | PDF now | What the code does / suggested text |
|---|---|---|
| 1 | Sec. IV-A: "three central questions … from the TRIAD-UQ framework", then lists RQ1–RQ4 | Four RQs; delete the TRIAD-UQ phrase. |
| 2 | Sec. IV-C subsections "Coupling Detectability / Domain Shift Attribution / Attribution Dominance" (template text) | Replace with: RQ1 detection, localisation, prevention and recovery; RQ2 exact vs cosine confirmation; RQ3 persistence, spread and reviewer overload; RQ4 edge cost. The figures and tables are in `results/` (names in the notebook). |
| 3 | Abstract/Contribution 4: "N8N shared-database testbed", "pre-existing benchmarks" | The experiments use a Python multi-agent testbed with a shared database (smart-building team, Scenario B) plus AgentDojo (E1, notebook Section 10, MELON's official code). n8n is only a possible deployment front-end. Do not claim n8n results; claim AgentDojo numbers only after Section 10b has been run with the key. |
| 4 | "external content enters as U" | Device telemetry from the building's own attested sensors is labelled T by deployment policy. Tickets, vendor e-mails and manuals are U. Add one sentence. |
| 5 | Eq. (9) and Contribution 3: "acyclic flow and a sufficient record decay rate prevent it" | Confirmed with a qualification. With δ_r = 0 (records never expire), an acyclic pipeline still keeps the payload alive, because persistent infected records act as a reservoir while R0 = 0. State that R0 < 1 implies extinction only when δ_r > 0 (RQ3 figure, column "never"). |
| 6 | Layer S, Eq. (8) | L_t is computed on W_t + (τ/n)(11ᵀ − I) with τ = 0.1 (regularised Laplacian, Amini et al. 2013). Without it, an idle reviewer node forces λ2 = 0 in most windows. |
| 7 | Localisation "record with the largest right-singular-vector entry" | The SVD is taken of the deviation B_t − E[B_t \| benign], clipped at 0, where E is learned per record kind (and per static record) in calibration. Without this, manuals that every agent reads mask the poisoned record. |
| 8 | Layer T, Eq. (10), "calibrated on benign runs of the same task template" | Trajectories are kept per (agent, task template) and warm-started with benign history. Calibration is per (agent, template). |
| 9 | Eq. (11), conformal p-values, "min_k p_k ≤ α/K" | p-values use per-run maxima of each statistic (N = 1500 benign runs). Because many statistics are tested at every step, the per-step Bonferroni level α/K does not bound the *run-level* false-alarm rate. The code therefore replaces α/K by a run-level conformal threshold τ: the ⌊(α/2)(N+1)⌋-th smallest run-minimum of min_k p_k over a further 1500 benign runs, so P(V1 in a benign run) ≤ α/2. The CUSUM threshold uses the 1−α/2 quantile, so the two together are ≤ α. Suggested text: "min_k p_k ≤ τ, with τ calibrated on benign runs so that the run-level false-alarm rate is at most α". |
| 10 | Confirmation: "reruns only the affected step with R masked and unmasked" | R1 = untrusted ancestors ranked by how far their reads exceed the benign rate for their kind (plus window top-k and current suspects), then R2 = untrusted records in the step context, with Bonferroni α_c/2. If R is not in the step's own context, its descendants in the context are re-derived once by re-running their writers with R masked ("chain replay", bounded by the memory horizon). The test is **curtailed**: re-runs are drawn one at a time (unmasked arm first) and stop as soon as rejection is impossible, which gives the same decision as the full q-vs-q test with fewer calls. A violation already tested within the window is blocked without new re-runs. |
| 11 | Verdict V1 | V1 triggers (i) quarantine of the top-1 suspect and temporary cuts of read edges (only for records descending from the suspects) until R0 < 1, and (ii) a hold on high-consequence actions whose provenance meets the suspects. A held action is re-derived once with the suspects masked: the same symbol is released, the same tool with other arguments is *repaired*, and anything else stays held. |
| 12 | Execution after a violation | Blocking follows the prefix-closed monitor, so the rest of that agent step is halted after the first violating call. Only the first violation is confirmed. |
| 12b | Layer F extractors "plan-approved extractor χ : text → S" | The plan names the **source** of each extracted value (e.g. "set-point from the maintenance ticket of this task"). The system, not an agent, applies χ to that record only, and the slot must carry χ(source). A value in the codomain that came from another untrusted record (stealth / in-alphabet attack) is a violation (V2); the call is **repaired** by substituting χ(source), so the user task still completes. Add one sentence to III-B: "the plan binds each extractor to a designated source record". |
| 13 | Reviewer h | Escalations (approval requests) are always admissible. Actions approved by h are a local override and are not held. A grouped card with more than 3 requests from one untrusted source is scrutinised; if h rejects it, its source records are quarantined. While V1 is active, a burst of requests whose sources are suspects is withheld from h (V1 also pauses escalations). |
| 13b | E1 / AgentDojo | Single-agent LEDGER: trusted planner (1 LLM call on request + tool schema), Layer F over state-changing tools with exact values or source binding to a named read tool, curtailed Fisher confirmation (q = 4, most recent tool outputs first, then all), rollback = the responsible tool outputs are replaced in the history and the agent continues. MELON and MELON-exact run MELON's own `pi_detector.py`. |
| 14 | `[?]` citations | Schneider 2000 (enforceable security policies); Vovk et al. / Angelopoulos & Bates (conformal); van den Driessche & Watmough 2002 (next-generation matrix); Cohen-Steiner et al. 2007 and Chazal et al. 2009 (persistence stability); Page 1954 (CUSUM). |

## B. Algorithm 1 (drop-in for Sec. III-F)

```latex
\begin{algorithm}[t]\caption{LEDGER runtime loop}\label{alg:ledger}\small
\begin{algorithmic}[1]
\Require plan $P_u$, DFA $M_u$, extractor bindings $\chi(\text{source})$, calibration $(\bar L, \mathcal{C}, \tau, \hat\beta_r,\hat\beta_w)$
\For{each event $e$ in the run}
  \State append $e$ to the log; update labels (join) and provenance
  \If{$e$ is a tool call $\alpha$ of agent $a$}
     \If{$\pi(w_{1:k}\alpha)\notin \mathrm{Pref}(L_u)$ \textbf{or} a sink lacks clearance}
        \State verdict V2; if only extractor slots differ, repair $\alpha$ with $\chi(\text{designated source})$, else block and halt the step
        \State $R \gets \mathrm{prov}(\alpha)\cap \mathrm{top}\text{-}k$; re-run the step $q$ times with $R$ masked and unmasked
        \If{Fisher$(\pi(\alpha))\le\alpha_c$ \textbf{and} $\mathrm{prov}(\alpha)\cap U\neq\emptyset$}
           \State V3: roll back $\mathrm{desc}(R)$; cut read edges until $\hat R_0<1$
        \EndIf
     \ElsIf{V1 active \textbf{and} $\mathrm{prov}(\alpha)\cap$ suspects $\neq\emptyset$}
        \State re-derive the step with suspects masked: release, repair or hold $\alpha$
     \EndIf
  \EndIf
  \State compute $W_t, L_t, S_1$, $\hat R_0$, $B_t$ and $T_1..T_3$ of the acting agent
  \If{$\min_k p_k \le \tau$ \textbf{or} CUSUM alarm} \Comment{$\tau$: run-level conformal threshold}
     \State V1: suspects $\gets$ top-$k$ of $B_t-\mathbb{E}[B_t]$; quarantine; cut until $\hat R_0<1$
  \EndIf
  \State group approval requests by untrusted source record
\EndFor
\end{algorithmic}\end{algorithm}
```

## C. What the current numbers do and do not show

* All results in `results/` with **[SIM]** come from simulated agents whose behaviour parameters
  (β_r = 0.75, β_w = 0.8, 3 % benign mistakes, 10 % content-driven masked runs) are assumptions.
  Describe them as a controlled simulation of the mechanisms, not as LLM measurements. Section 9
  (Ollama/OpenAI agents) and Section 10 (AgentDojo) give real-model numbers once run.
* **Stealth / in-alphabet attacks** are now blocked by source-bound extractors (Layer F). The remaining
  **residual threat** is an adversary who controls the designated source itself; no defense detects it,
  and LEDGER bounds it to the extractor codomain (3.46 bits for set-points, 2.58 bits for vendors).
  It is reported in its own table (`table_rq1_residual.tex`), not averaged with the five attacks.
* **Cost under attack** dropped to below MELON thanks to curtailed tests and verdict reuse (see RQ4
  table); in benign operation LEDGER stays at ~5 calls/task vs MELON's 9.
* **Benign alarms**: statistical V1 alarms are now calibrated at the run level (≈ α/2); the remaining
  "FPR" in benign runs is Layer F correctly blocking wrong actions made by benign agents (3 % mistake
  rate), reported separately as `FalseViolation`.
* **Energy**: `measure_edge_profile` (Section 9) measures overhead, prefill/decode speed (Ollama timers)
  and GPU power (nvidia-smi) on the laptop and saves `results/edge_profile.json`; every later run of the
  notebook then uses the measured profile for RQ4. Until then the joules use the assumed profile.


## Addendum (11 Nov 2026): live n8n evaluation

**What was added.** I made LEDGER copies of two production-style n8n Cloud workflows (Moneycontrol news brief with Pinecone RAG memory; AI Recruiter with Brave Search). The details are in `integrations/n8n/README.md`, and the analysis is in `LEDGER_n8n_Live.ipynb`.

**Suggested paper text** (a short "Live deployment" paragraph or subsection, or the appendix if space is tight):

> We additionally deployed LEDGER inside two live n8n agent workflows: a news-brief agent (gpt-5-mini) with a Pinecone memory written by its own past runs, and a recruiting agent (Claude Sonnet 5) over web-search results. All reads go through a read hook that consults a quarantine registry. Layer F enforces source binding on the email sink: every link or profile URL must equal a value extracted by the workflow, not by the LLM. Violations are confirmed with the curtailed Fisher test (q = 4) using masked replays of the same LLM step, and are then repaired by re-derivation and quarantine. Over N runs per cell we report ASR, utility and LLM-call overhead with and without LEDGER for direct, stealth and memory-poisoning injections, plus two content-only attacks that are outside Layer F by construction.

**Claims this evidence supports:**
* Layer F, the replay/Fisher confirmation, rollback and quarantine with mediated reads work as specified in real agent stacks (LLM nodes, RSS, Brave, Pinecone, Gmail, data tables).
* The confirmation step prevents false quarantine. In smoke test exec 17, a case-only schema violation was flagged but not confirmed (p = 1).
* The cost is concentrated on flagged runs: 2q − 1 = 7 extra LLM calls at q = 4.

**Claims it does NOT support (state these explicitly):**
* Nothing here supports Layer S, Layer T, HITL triage or the conformal calibration. These are single-agent pipelines, and those layers are evaluated in simulation only.
* There is no MELON comparison on n8n. MELON is compared on AgentDojo (E1).
* The sample sizes are small (Wilson intervals are wide). Present the results as a feasibility study, not a benchmark.
* Content-only manipulation (`content`, `rank`) is the residual threat, consistent with the min-cut bound.

**Implementation notes to mention:**
* Suspect localisation in the live copies is content-match on the offending host/URL, with a fallback to the records the output cites. It is not the SVD localisation of Layer S.
* The workflow graph plays the role of the trusted planner: sinks and recipients are constants in the graph.
