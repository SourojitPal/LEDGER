"""Builds LEDGER_Experiments.ipynb (run once; the notebook is the deliverable)."""
import nbformat as nbf

nb = nbf.v4.new_notebook()
C = []


def md(s):
    C.append(nbf.v4.new_markdown_cell(s.strip()))


def code(s):
    C.append(nbf.v4.new_code_cell(s.strip()))


md(r"""
# LEDGER — experiments for *Trust, but Roll Back: Record-Level Defense Against Indirect Prompt Injection for Pervasive Agents* (PerAgents 2027)

Run top to bottom (**Kernel → Restart & Run All**). Everything below calls the `ledger/` package in this folder; all tables go to `results/tables/`, all figures (PNG + PDF) to `results/figures/`, raw per-run data to `results/data/`.

**How the code maps to the paper**

| Paper | Code |
|---|---|
| Eq. (1) agent policy $a_t=\pi(u,H_t)$ | `ledger/agents.py` (`SimPolicy`, `LLMPolicy`) |
| Eq. (2) ASR, UA; Eq. (6) FPR, $E\approx\bar P\,t_{total}$ | `ledger/metrics.py` |
| Eq. (3) MELON cosine test (baseline) | `ledger/defense/pipeline.py::Melon` |
| Eq. (4) top-$k$ retrieval from shared store | `ledger/db.py::SharedDB.retrieve` |
| Eq. (5) agent-level epidemic threshold (baseline / RQ3 comparison) | `AgentGraph`, `experiments.rq3_spread` |
| III-A records, labels $L=\{T,U\}$, join, adversary, IPI definition | `ledger/db.py`, `ledger/events.py`, `ledger/scenario.py` |
| III-B Layer F: $\Sigma=F\times\Theta$, plan DAG, DFA $M_u$, Eq. (7) prefix check, extractors $\chi$, min-cut bits | `ledger/alphabet.py`, `ledger/defense/layer_f.py` |
| III-C Layer S: Eq. (8) $W_t$, $L_t$, $S_1$, Hoffman–Wielandt; Eq. (9) $R_0$; SVD localisation + IPR | `ledger/defense/layer_s.py` |
| III-D Layer T: Eq. (10) $X_i$, Vietoris–Rips $H_0/H_1$, $T_1,T_2,T_3$, spanning-path lemma, corroboration | `ledger/defense/layer_t.py` |
| III-E Eq. (11) conformal p-values + Bonferroni, Page CUSUM | `ledger/defense/calibrate.py` |
| III-E confirmation: provenance ∩ top-$k$, exact symbols, masked/unmasked re-runs, one-sided Fisher | `ledger/defense/confirm.py`, `Ledger._confirm`, `Testbed._rerun` (chain replay) |
| III-E containment: cut read edges until $R_0<1$, rollback of provenance descendants, grouping by source | `layer_s.quarantine_cut`, `SharedDB.rollback`, `ledger/defense/contain.py` |
| RQ1–RQ4 | `ledger/experiments.py`, `ledger/plots.py` |

**Backends.** `BACKEND = "sim"` (default) uses a seeded stochastic stand-in for the LLM agents, so all experiments finish in minutes and are exactly reproducible; every figure from it is tagged **[SIM]** and must be described as a controlled simulation in the paper. Section 9 re-runs the same pipeline with real models through **Ollama** (e.g. `qwen3:8b`) or **OpenAI** (`gpt-4o-mini`). Section 10 points to the AgentDojo/MELON experiment (E1).
""")

code(r"""
import os, sys, json, time, platform, subprocess, warnings
from pathlib import Path
warnings.filterwarnings("ignore")

ROOT = Path.cwd()
if not (ROOT / "ledger").is_dir():                       # allow starting Jupyter one level up
    ROOT = next(p for p in [ROOT, *ROOT.parents] if (p / "ledger").is_dir())
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)

import numpy as np, pandas as pd, matplotlib, scipy, networkx
import matplotlib.pyplot as plt
from IPython.display import Image, display, Markdown

from ledger.config import Config, DEFENSES, ABLATIONS
from ledger import experiments as X
from ledger import plots as P
from ledger.metrics import summarize, to_latex, two_proportion_p, wilson

pd.set_option("display.width", 220); pd.set_option("display.max_columns", 40)
P.set_style()

# ------------------------------------------------------------------ run settings
RUN_MODE = "full"          # "quick" (~3-4 min, fewer seeds) or "full" (paper numbers, ~25-35 min)
BACKEND  = "sim"           # "sim" for all sections 1-8; LLM backends are used in Section 9
N = dict(quick=dict(seeds=12, cal=200, abl=10, rq2=15, rq3=8, flood=12, trace=12),
         full=dict(seeds=50, cal=1500, abl=30, rq2=40, rq3=25, flood=40, trace=40))[RUN_MODE]

cfg = Config(backend=BACKEND)
SIM = cfg.backend == "sim"
OUT = ROOT / "results"; FIG = OUT / "figures"; TAB = OUT / "tables"; DAT = OUT / "data"; CACHE = OUT / "cache"
for d in (FIG, TAB, DAT, CACHE): d.mkdir(parents=True, exist_ok=True)
from ledger.energy import load_profile
EDGE_PROFILE = OUT / "edge_profile.json"          # written by Section 9 (measure_edge_profile)
print("edge profile:", "MEASURED (" + str(EDGE_PROFILE) + ")" if load_profile(cfg, str(EDGE_PROFILE))
      else "assumed defaults; run Section 9 on this laptop to measure")

def show(path):
    plt.close("all")          # the saved PNG is shown once; avoid a second inline copy of the same figure
    display(Image(filename=str(path)))
def save_df(df, name): df.to_csv(DAT / f"{name}.csv", index=False); return DAT / f"{name}.csv"

print(f"Python {platform.python_version()} | numpy {np.__version__} | scipy {scipy.__version__} | pandas {pd.__version__} "
      f"| matplotlib {matplotlib.__version__} | networkx {networkx.__version__}")
print("Mode:", RUN_MODE, N, "| backend:", BACKEND)
print(json.dumps({k: v for k, v in cfg.to_dict().items() if k != 'edge'}, indent=None)[:900], "...")
""")

md(r"""
### OpenAI key (needed only for Section 9 with `backend="openai"` and for Section 10, AgentDojo)
Open **`api_keys.py`** in this folder and paste your key between the quotes: `OPENAI_API_KEY = "sk-..."`. Nothing else needs editing; the key is never printed or written to results.
""")
code(r"""
from ledger.keys import load_openai_key, key_status
load_openai_key(ROOT, required=False)
print(key_status())
""")

md(r"""
## 0. Unit and integration tests
Checks every building block against its stated property: exact symbols, DFA prefix closure and partial order, extractor codomain, min-cut bits, label join, rollback closure, Hoffman–Wielandt, $\rho(RW)=0$ for acyclic flow, quarantine reaching $R_0<1$, spanning-path lemma, $H_1$ of a loop, Wasserstein metric, Fisher minimum p-value and false-confirmation bound, conformal p-values, CUSUM, grouping, and end-to-end behaviour.
""")
code(r"""
r = subprocess.run([sys.executable, "-m", "unittest", "discover", "-s", "tests"], cwd=ROOT, capture_output=True, text=True, encoding="utf-8", errors="replace")
print(r.stderr[-1500:])
assert r.returncode == 0, "tests failed"
""")

md(r"""
## 1. Calibration (Sec. III-E)
Benign runs of the same task templates (seeds ≥ 100000, never reused for evaluation) give: the reference Laplacian $\bar L$, benign persistence diagrams per agent and task template, the benign read-rate baseline for localisation, conformal run-maxima for $S_1, T_1, T_2, T_3$, the CUSUM threshold, and $\hat\beta_r,\hat\beta_w$ from undefended attack runs.
""")
code(r"""
TOPOS = ["pipeline", "cyclic"]
calibs = {t: X.get_calibration(cfg.with_(topology=t), str(CACHE), n_runs=N["cal"]) for t in TOPOS}
pd.DataFrame([{"topology": t, "benign runs": c.n_runs, "lambda2(L_bar)": round(c.lam2_bar, 3),
               "beta_r_hat": round(c.beta_r_hat, 3), "beta_w_hat": round(c.beta_w_hat, 3),
               "CUSUM h": round(c.cusum_h, 2), "#T-statistics": len(c.calib.names) - 1} for t, c in calibs.items()])
""")

md(r"""
## 2. RQ1 — detect, localise, prevent and recover
*How effectively can LEDGER detect IPI in a multi-agent system with shared memory, localise the poisoned record, prevent the resulting unauthorised action, and recover through quarantine or rollback?*

Five attacks are written into one untrusted record at round 3: **one-shot hijack** (out-of-plan action), **in-alphabet hijack** (wrong value inside an extractor codomain, so Layer F cannot block it), **self-replicating** payload, **reviewer flood**, and an adaptive **stealth** variant (in-alphabet, no visible instruction, no copying). Defenses: no defense, MELON (cosine), MELON with exact π (same masking, exact comparison), an agent-level spectral monitor that resets agents (no records), and LEDGER.
""")
code(r"""
t0 = time.time()
rq1_runs, rq1_sum = X.rq1_main(cfg, calibs, n_seeds=N["seeds"], topologies=TOPOS)
save_df(rq1_runs, "rq1_runs"); save_df(rq1_sum, "rq1_summary")
print(f"{len(rq1_runs)} runs in {time.time()-t0:.0f}s")
cols = ["topology","attack","defense","n_runs","ASR","ASR_lo","ASR_hi","UA","BU","FPR","FPR_stat","false_violation_rate",
        "false_confirm_rate","detect_rate","delay_events","loc_top1_seed","loc_top1_family","rollback_precision",
        "rollback_recall","recovered","calls_per_task"]
rq1_sum[[c for c in cols if c in rq1_sum]].round(3)
""")
code(r"""
# Paper Table (RQ1): attacks averaged per topology, plus benign columns
att = rq1_runs[~rq1_runs.benign].groupby(["topology","defense"]).agg(ASR=("attack_success","mean"), UA=("utility","mean"),
        Detect=("detected","mean"), Loc_top1=("loc_top1_family","mean"), Recovered=("recovered","mean")).reset_index()
ben = rq1_runs[rq1_runs.benign].groupby(["topology","defense"]).agg(BU=("utility","mean"), FPR=("any_alarm","mean"),
        FPR_stat=("any_V1","mean"), FalseViolation=("any_V2","mean"), FalseConfirm=("any_V3","mean"),
        Calls=("calls_per_task","mean")).reset_index()
table_rq1 = att.merge(ben, on=["topology","defense"])
table_rq1["defense"] = table_rq1["defense"].map(P.LABELS)
to_latex(table_rq1, TAB / "table_rq1_main.tex", "RQ1: security, utility, detection and benign cost (mean over five attacks; "
         + ("simulated agents" if SIM else cfg.llm_model) + ").", "tab:rq1")
table_rq1.to_csv(TAB / "table_rq1_main.csv", index=False)
# per-attack table with CIs
per = rq1_sum[rq1_sum.attack != "benign"][["topology","attack","defense","ASR","ASR_lo","ASR_hi","UA","UA_lo","UA_hi",
                                            "delay_events","loc_top1_family"]].copy()
per["defense"] = per["defense"].map(P.LABELS)
to_latex(per, TAB / "table_rq1_per_attack.tex", "RQ1 per attack with 95% CIs.", "tab:rq1-attack")
# significance: LEDGER vs MELON ASR per attack (two-proportion z-test)
sig = []
for (topo, a), g in rq1_runs[~rq1_runs.benign].groupby(["topology","attack"]):
    l, m = g[g.defense=="ledger"].attack_success, g[g.defense=="melon"].attack_success
    sig.append({"topology": topo, "attack": a, "ASR LEDGER": l.mean(), "ASR MELON": m.mean(),
                "p (two-proportion)": two_proportion_p(int(l.sum()), len(l), int(m.sum()), len(m))})
sig = pd.DataFrame(sig); sig.to_csv(TAB / "rq1_significance.csv", index=False)
display(table_rq1.round(3)); display(sig.round(4))
""")
code(r"""
show(P.fig_rq1_main(rq1_sum, str(FIG), sim=SIM))
""")
md(r"""
### Paper Fig. 2: attack success and utility per attack (pipeline topology)
No defense vs MELON (cosine) vs LEDGER, Wilson 95% CIs. Saved as `results/figures/fig_paper_asr_ua.png/.pdf`.
""")
code(r"""
show(P.fig_paper_asr_ua(rq1_sum, str(FIG)))
""")
md(r"""
**Column meanings (benign runs).** `FPR` = any verdict; `FPR_stat` = statistical alarm (V1, Layers S/T), controlled at the run level by the conformal threshold τ; `FalseViolation` = Layer F blocked a *genuinely wrong* action made by a benign agent (3% mistake rate in the simulator) — a correct block, not a false alarm on a correct action; `FalseConfirm` = V3 on a benign run (bounded by α_c).

**Residual threat.** If the adversary controls the plan-designated source itself (here: the ticket feed), no defense can tell the value from a legitimate one. Layer F bounds what it can steer to the extractor codomain (min-cut bits). This is reported separately, not averaged with the five attacks.
""")
code(r"""
resid = pd.concat([X.rq1_residual(cfg.with_(topology=t), calibs[t], n_seeds=max(10, N["seeds"]//2)) for t in TOPOS])
resid["defense"] = resid["defense"].map(P.LABELS)
to_latex(resid, TAB / "table_rq1_residual.tex", "Residual threat: adversary controls the designated source; influence bounded by the extractor codomain.", "tab:residual")
resid.round(3)
""")
code(r"""
# Event dynamics (cf. reference figure 2) and cross-channel activity (cf. reference figure 1)
c_pipe = cfg.with_(topology="pipeline")
traces = {a: X.rq1_traces(c_pipe, calibs["pipeline"], attack=a, n_seeds=N["trace"]) for a in ["selfrep", "flood", "hijack"]}
pd.concat(traces.values()).to_csv(DAT / "rq1_traces.csv", index=False)
show(P.fig_rq1_timeline(traces["selfrep"], cfg.t_inject, str(FIG), sim=SIM, attack="selfrep"))
counts = X.rq1_heatmap_counts(c_pipe, calibs["pipeline"], attack="selfrep", n_seeds=N["trace"])
(DAT / "rq1_heatmap_counts.json").write_text(json.dumps(counts))      # lets replot_figures.py redraw it
show(P.fig_rq1_heatmap(counts, str(FIG), sim=SIM))
""")
code(r"""
# Spectral signature (cf. reference figure 3): lambda_2 around injection and structure-behaviour phase plot
show(P.fig_rq1_spectral(traces, cfg.t_inject, str(FIG), sim=SIM))
""")
code(r"""
# Localisation: synthetic SVD check + testbed
theory = X.rq1_localisation_theory(n_trials=300)
save_df(theory, "rq1_localisation_theory")
show(P.fig_rq1_localisation(theory, rq1_sum, str(FIG), sim=SIM))
""")
code(r"""
# Ablations: which layer does what
abl_runs, abl_sum = X.rq1_ablation(c_pipe, calibs["pipeline"], n_seeds=N["abl"])
save_df(abl_runs, "rq1_ablation_runs"); save_df(abl_sum, "rq1_ablation_summary")
abl_tab = abl_sum.groupby("defense", sort=False).agg(ASR=("ASR","mean"), UA=("UA","mean"), BU=("BU","mean"),
                                                     FPR=("FPR","mean"), calls=("calls_per_task","mean")).reset_index()
to_latex(abl_tab, TAB / "table_rq1_ablation.tex", "Ablations of LEDGER (pipeline; ASR/UA averaged over attacks).", "tab:ablation")
display(abl_tab.round(3))
show(P.fig_rq1_ablation(abl_sum, str(FIG), sim=SIM))
""")

md(r"""
## 3. RQ2 — exact finite-action confirmation instead of cosine similarity
*Can LEDGER's exact, finite-action confirmation replace cosine/embedding-similarity decisions while maintaining security and utility and reducing unnecessary re-execution?*

(a) For every agent step with tool calls we compare the original call with the masked-run call ($u\to\tilde u$) both by MELON's cosine and by exact π equality. (b) Monte-Carlo check of the false-confirmation bound and power of the one-sided Fisher test. (c) The comparison rule swapped inside MELON and inside LEDGER's confirmation. (d) Sensitivity to the simulator assumption that drives MELON's false positives.
""")
code(r"""
act = X.rq2_action_level(c_pipe, n_seeds=N["rq2"])
save_df(act, "rq2_action_level")
roc = X.roc_points(act)
print(f"calls: {len(act)} (attack-driven {int(act.attack_driven.sum())}) | cosine AUC {roc[2]:.3f} | "
      f"cosine@0.8 (FPR,TPR)={tuple(round(v,3) for v in roc[4])} | exact (FPR,TPR)={tuple(round(v,3) for v in roc[3])}")
show(P.fig_rq2_roc(act, roc, str(FIG), sim=SIM))
""")
code(r"""
fb = X.rq2_fisher_bound(qs=(3,4,5,6), alpha_c=cfg.alpha_c, n_mc=20000 if RUN_MODE=="full" else 4000)
save_df(fb, "rq2_fisher")
print("max false-confirmation rate over p, by q:", fb.groupby("q").false_confirm.max().round(4).to_dict())
show(P.fig_rq2_fisher(fb, cfg.alpha_c, str(FIG)))
""")
code(r"""
cmp_runs, cmp_sum = X.rq2_confirm_compare(c_pipe, calibs["pipeline"], n_seeds=N["rq2"])
save_df(cmp_runs, "rq2_compare_runs")
tab2 = pd.concat([cmp_sum[cmp_sum.attack!="benign"].groupby("defense")[["ASR","UA","extra_calls_per_task"]].mean(),
                  cmp_sum[cmp_sum.attack=="benign"].groupby("defense")[["BU","FPR","false_confirm_rate"]].mean()], axis=1).reset_index()
to_latex(tab2, TAB / "table_rq2_exact_vs_cosine.tex", "RQ2: exact $\\pi$ equality vs cosine $>\\theta$.", "tab:rq2")
display(tab2.round(3))
show(P.fig_rq2_compare(cmp_sum, str(FIG), sim=SIM))
""")
code(r"""
sens = X.rq2_sensitivity(c_pipe, calibs["pipeline"], n_seeds=max(10, N["rq2"]//2))
save_df(sens, "rq2_sensitivity")
show(P.fig_rq2_sensitivity(sens, str(FIG), sim=SIM))
""")

md(r"""
## 4. RQ3 — persistence, spread and reviewer overload
*Under what conditions do poisoned records persist and spread through shared memory, and can record-lifetime controls, topology constraints and source-based grouping limit both agent compromise and human-reviewer overload?*

(a) A self-replicating payload with a **transient** seed (the adversary deletes it after two rounds), no blocking, over topology × record lifetime × compliance; outcome against the record-level $R_0$ of Eq. (9) and the agent-level index of Eq. (5). (b) Record-level vs agent-level containment. (c) Reviewer flooding with and without grouping by source record.
""")
code(r"""
t0 = time.time()
spread = X.rq3_spread(cfg, n_seeds=N["rq3"])
save_df(spread, "rq3_spread")
g = spread.groupby(["topology","ttl","beta_r"]).agg(R0=("R0","first"), agent_index=("agent_index","first"),
                                                   persist=("persist","mean"), spread=("spread","mean")).reset_index()
below = g[g.R0 < 1]; above = g[g.R0 >= 1]
print(f"{time.time()-t0:.0f}s | persistence when R0<1: {below.persist.mean():.3f} (n={len(below)}) | when R0>=1: {above.persist.mean():.3f} (n={len(above)})")
fin = g[g.ttl != "never"]
print("finite lifetime only -> R0<1:", round(fin[fin.R0<1].persist.mean(),3), "| R0>=1:", round(fin[fin.R0>=1].persist.mean(),3))
tab3 = g.pivot_table(index="topology", columns="ttl", values="persist", aggfunc="mean")
tab3.to_csv(TAB / "table_rq3_persistence.csv"); display(tab3.round(2))
show(P.fig_rq3_spread(spread, str(FIG), sim=SIM))
""")
code(r"""
cyc = cfg.with_(topology="cyclic", record_ttl=None)
cal_cyc_persist = X.get_calibration(cyc, str(CACHE), n_runs=N["cal"])
ct = X.rq3_containment(cyc, cal_cyc_persist, n_seeds=N["rq3"])
save_df(ct, "rq3_containment")
display(ct[ct["round"] == ct["round"].max()].groupby("defense", sort=False)[["compromised","active_payload","success"]].mean().round(3))
show(P.fig_rq3_containment(ct, str(FIG), sim=SIM))
""")
code(r"""
fl = X.rq3_flood(c_pipe, calibs["pipeline"], n_seeds=N["flood"])
save_df(fl.drop(columns=["backlog_series"]), "rq3_flood")
(DAT / "rq3_flood_backlog.json").write_text(json.dumps([list(map(float, s)) for s in fl["backlog_series"]]))
tabf = fl.groupby(["N","defense"]).agg(ASR=("attack_success","mean"), rho_h=("rho_h","mean"),
                                       max_backlog=("max_backlog","mean"), alarm_task_ok=("alarm_task_success","mean")).reset_index()
to_latex(tabf, TAB / "table_rq3_flood.tex", "RQ3: reviewer flooding vs flood size $N$.", "tab:flood")
display(tabf.round(3))
show(P.fig_rq3_flood(fl, cfg.reviewer_mu, str(FIG), sim=SIM))
""")
md(r"""
### Paper Fig. 3: (a) P(payload persists), (b) reviewer flooding
(a) persistence of a self-replicating payload by topology and record lifetime $1/\delta_r$; (b) reviewer load $\rho_h$ vs flood size $N$ for no defense, LEDGER without grouping, and LEDGER. Saved as `results/figures/fig_paper_containment.png/.pdf`.
""")
code(r"""
show(P.fig_paper_containment(tab3, fl, str(FIG)))
""")

md(r"""
## 5. RQ4 — security–utility–cost trade-off at the edge
*Does LEDGER provide a favourable security–utility–cost trade-off for edge deployment, in LLM calls, tokens, latency and energy per task?*

Calls and tokens are counted in the testbed; latency and energy use the edge profile in `Config.edge` (Eq. 6, $E\approx\bar P\,t$). The defense's own computation (Layers F/S/T, statistics) is **measured** on this machine. Replace the edge profile with values measured on your laptop (Section 9 has `measure_edge_profile`).
""")
code(r"""
cost = X.rq4_cost(rq1_runs)
cost.to_csv(TAB / "table_rq4_cost.csv", index=False)
c4 = cost.copy(); c4["defense"] = c4["defense"].map(P.LABELS)
to_latex(c4, TAB / "table_rq4_cost.tex", f"RQ4: cost per task ({cfg.edge.name}, $\\bar P$ = {cfg.edge.power_w} W).", "tab:cost")
display(c4.round(3))
show(P.fig_rq4_pareto(rq1_runs, str(FIG), sim=SIM))
show(P.fig_rq4_cost(cost, str(FIG), sim=SIM))
""")
code(r"""
scal = X.rq4_scaling(rq1_runs, cfg); dev = X.rq4_device_profiles(rq1_runs, cfg)
save_df(scal, "rq4_scaling"); save_df(dev, "rq4_devices")
show(P.fig_rq4_scaling(scal, dev, str(FIG), sim=SIM))
led = rq1_runs[rq1_runs.defense=="ledger"]
print(f"Measured LEDGER defense computation on this machine: {led.defense_cpu_ms_per_step.mean():.2f} ms per agent step "
      f"(Layers F/S/T + statistics; excludes LLM re-runs)")
""")

md(r"""
## 6. Formal checks (supporting the method section)
Numerical checks of the statements LEDGER relies on: DFA size and min-cut influence bound per task template, Hoffman–Wielandt bound on every window, the spanning-path lemma on every trajectory, Fisher minimum p-values, and whether the calibration set is large enough for Bonferroni at $\alpha/K$.
""")
code(r"""
fc = X.formal_checks(c_pipe, calibs["pipeline"])
fc.to_csv(TAB / "table_formal_checks.csv", index=False); fc
""")

md(r"""
## 7. Summary of findings (auto-generated from the numbers above)
""")
code(r"""
def pct(x): return f"{100*x:.1f}%"
lines = []
for topo in TOPOS:
    a = rq1_runs[(rq1_runs.topology==topo) & ~rq1_runs.benign]; b = rq1_runs[(rq1_runs.topology==topo) & rq1_runs.benign]
    f = lambda d, col, src: src[src.defense==d][col].mean()
    lines.append(f"- **{topo}**: ASR none {pct(f('none','attack_success',a))}, MELON {pct(f('melon','attack_success',a))}, "
                 f"LEDGER {pct(f('ledger','attack_success',a))}; UA MELON {pct(f('melon','utility',a))} vs LEDGER {pct(f('ledger','utility',a))}; "
                 f"BU MELON {pct(f('melon','utility',b))} vs LEDGER {pct(f('ledger','utility',b))}; benign LLM calls/task "
                 f"MELON {f('melon','calls_per_task',b):.2f} vs LEDGER {f('ledger','calls_per_task',b):.2f}; "
                 f"false confirmations LEDGER {pct(f('ledger','any_V3',b))}.")
s = rq1_sum[(rq1_sum.defense=="ledger") & (rq1_sum.attack!="benign")]
lines.append(f"- Localisation (top-1 record in poisoned family at first verdict): {pct(s.loc_top1_family.mean())}; "
             f"exactly the injected record: {pct(s.loc_top1_seed.mean())}; median detection delay {s.delay_events.median():.0f} events.")
st = rq1_sum[(rq1_sum.defense=="ledger") & (rq1_sum.attack=="stealth")]
lines.append(f"- Stealth (in-alphabet value, no visible instruction): LEDGER ASR {pct(st.ASR.mean())} (source-bound extractors).")
rl = resid[resid.defense=="LEDGER"]
lines.append(f"- Residual threat (adversary controls the designated source): LEDGER ASR {pct(rl.ASR.mean())}, as for every defense; "
             f"influence bounded to {rl.bound_bits_hvac.iloc[0]:.2f} bits (set-point) / {rl.bound_bits_door.iloc[0]:.2f} bits (vendor).")
lines.append(f"- RQ2: cosine AUC {roc[2]:.3f}; exact pi (FPR, TPR) = ({roc[3][0]:.3f}, {roc[3][1]:.3f}); max empirical false-confirmation "
             f"rate {fb.false_confirm.max():.4f} <= alpha_c = {cfg.alpha_c}.")
lines.append(f"- RQ3: persistence with finite record lifetime, R0<1: {pct(fin[fin.R0<1].persist.mean())}, R0>=1: {pct(fin[fin.R0>=1].persist.mean())}; "
             f"never-expiring records persist in {pct(g[g.ttl=='never'].persist.mean())} of settings (reservoir effect, delta_r = 0).")
tf = tabf[tabf.N==tabf.N.max()]
lines.append(f"- RQ3 flood (N={tabf.N.max()}): ASR " + ", ".join(f"{r.defense} {pct(r.ASR)} (rho_h {r.rho_h:.1f})" for r in tf.itertuples()) + ".")
txt = "\n".join(lines)
(OUT / "summary_of_findings.md").write_text("# Summary of findings" + (" [SIM]" if SIM else "") + "\n\n" + txt, encoding="utf-8")
display(Markdown(txt))
print("\nTables:", sorted(p.name for p in TAB.iterdir())); print("Figures:", sorted(p.name for p in FIG.glob('*.png')))
""")

md(r"""
## 8. Reproducibility notes
* Seeds: evaluation 0…N−1 per cell, calibration ≥ 100000, RQ2 ≥ 3000, RQ3 ≥ 7000. Delete `results/cache/` to recalibrate.
* Every run can be re-scored from its event log: `Testbed(..., keep_log=True).run().log.to_jsonl(path)`.
* Simulator assumptions (only for `BACKEND="sim"`): compliance $\beta_r$=0.75, payload copying $\beta_w$=0.8, benign mistake rate 3%, masked-run content-driven reproduction 10% (sensitivity in Section 3). They are parameters of `Config`, not results.
""")

md(r"""
## 9. Optional — real LLM agents (Ollama / OpenAI)
Set `RUN_LLM = True`. For Ollama: install it, run `ollama pull qwen3:8b` and `ollama pull nomic-embed-text`, keep `ollama serve` running. For OpenAI: put the key in `api_keys.py` and use `Config(backend="openai", llm_model="gpt-4o-mini", embed_backend="openai", embed_model="text-embedding-3-small")`. Energy is measured with `nvidia-smi` when available. Every agent step is one LLM call, so start small (the defaults below take roughly 20–60 minutes on a laptop GPU).
""")
code(r"""
RUN_LLM = False
if RUN_LLM:
    from ledger.llm import ollama_available
    llm_cfg = Config(backend="ollama", llm_model="qwen3:8b", embed_backend="ollama", n_rounds=6, t_inject=2)
    assert ollama_available(llm_cfg.ollama_url), "start `ollama serve` first"
    # measured overhead / prefill / decode speed and GPU power (nvidia-smi) -> results/edge_profile.json;
    # re-run the notebook afterwards and Sections 5 (RQ4) use the MEASURED profile instead of the assumed one
    prof = X.measure_edge_profile(llm_cfg, save_to=str(EDGE_PROFILE))
    llm_runs = X.run_llm_experiment(llm_cfg, defenses=("none", "melon", "ledger"), attacks=("hijack", "inplan"),
                                    n_seeds=3, n_cal=12, cache_dir=str(CACHE))
    save_df(llm_runs, "llm_runs")
    display(summarize(llm_runs)[["attack","defense","ASR","UA","BU","FPR","calls_per_task","latency_per_task_s","energy_per_task_J"]].round(3))
    if "measured_energy_per_task_J" in llm_runs:
        display(llm_runs.groupby("defense")[["measured_power_W", "measured_energy_per_task_J"]].mean().round(2))
""")

md(r"""
## 10. E1 — AgentDojo with MELON's own code (needs the OpenAI key)
Compares **no defense**, **MELON** (its official `pi_detector.py`, loaded from your `Melon` folder), **MELON-exact** (only MELON's cosine line replaced by exact action-alphabet equality), and **LEDGER in single-agent mode** (trusted planner + exact Layer F gate with source binding, alarm-gated counterfactual confirmation, rollback of the responsible tool outputs and continuation) on AgentDojo with the `important_instructions` attack.

**One-time setup** (Anaconda Prompt, Python ≥ 3.10): `pip install "agentdojo==0.1.29"` (0.1.29 is the last AgentDojo release whose message format MELON's code expects). MELON's file is used as is; transformers/torch are **not** needed.

10a runs an **offline self-test** (no key, no cost: scripted agent, fake embeddings) that exercises the whole AgentDojo + MELON + LEDGER plumbing. 10b is the real experiment; start with a few task pairs to check cost (roughly 2–4 LLM calls per pair for no defense, about twice that for MELON).
""")
code(r"""
import importlib.util
MELON_PATH = r"C:\Users\souro\OneDrive\Documents\My Files\Further Studies\Post enrollment Works\Work 15 - Agentic AI\3. PERAGENT\Melon\pi_detector.py"
HAVE_AGENTDOJO = importlib.util.find_spec("agentdojo") is not None and sys.version_info >= (3, 10)
print("agentdojo installed:", HAVE_AGENTDOJO, "| Python", platform.python_version(), "| MELON file found:", Path(MELON_PATH).is_file())
if HAVE_AGENTDOJO:
    from importlib.metadata import version
    print("agentdojo version:", version("agentdojo"), "(0.1.29 recommended)")
    # 10a: offline self-test of the full E1 machinery (no API key needed)
    from integrations.agentdojo_melon.ledger_agentdojo import offline_selftest
    st_rows, st_sum = offline_selftest("banking", melon_path=MELON_PATH, logdir=str(OUT / "agentdojo_selftest"))
    display(st_sum[["defense","pairs","ASR","UA","BU"]])
    print("Self-test OK: AgentDojo, MELON's code and the LEDGER elements run end to end (scripted agent; numbers are not results).")
else:
    print('Install first:  pip install "agentdojo==0.1.29"   (then restart the kernel)')
""")
code(r"""
RUN_E1 = False                                   # set True after putting the key in api_keys.py
E1_SUITE   = "banking"                           # banking | slack | travel | workspace
E1_MODEL   = "gpt-4o-mini-2024-07-18"            # the name must be an AgentDojo model id
E1_USER    = [f"user_task_{i}" for i in range(4)]       # None = all user tasks of the suite
E1_INJ     = [f"injection_task_{i}" for i in range(3)]  # None = all injection tasks
if RUN_E1:
    from integrations.agentdojo_melon.ledger_agentdojo import run_e1
    load_openai_key(ROOT, required=True)
    e1_rows, e1_sum = run_e1(E1_SUITE, defenses=("none", "melon", "melon_exact", "ledger"), model=E1_MODEL,
                             user_tasks=E1_USER, injection_tasks=E1_INJ, melon_path=MELON_PATH,
                             logdir=str(OUT / "agentdojo_runs"))
    e1_rows.to_csv(DAT / f"e1_{E1_SUITE}_rows.csv", index=False); e1_sum.to_csv(TAB / f"table_e1_{E1_SUITE}.csv", index=False)
    to_latex(e1_sum[[c for c in ["defense","pairs","ASR","UA","BU","calls_per_pair","calls_per_task_benign",
                                 "embed_calls_per_pair","latency_per_pair_s"] if c in e1_sum]],
             TAB / f"table_e1_{E1_SUITE}.tex", f"E1: AgentDojo {E1_SUITE} ({E1_MODEL}, important\\_instructions).", "tab:e1")
    display(e1_sum.round(3))
    fig, ax = plt.subplots(1, 2, figsize=(9, 3.2))
    order = [d for d in ("none","melon","melon_exact","ledger") if d in set(e1_sum.defense)]
    e = e1_sum.set_index("defense").reindex(order)
    ax[0].bar([P.LABELS[d] for d in order], e.ASR, color=[P.COLORS[d] for d in order]); ax[0].set_title("ASR (AgentDojo)")
    ax[1].bar([P.LABELS[d] for d in order], e.calls_per_pair, color=[P.COLORS[d] for d in order]); ax[1].set_title("LLM calls per task pair")
    for a in ax: a.tick_params(axis="x", rotation=20)
    fig.tight_layout(); fig.savefig(FIG / f"fig_e1_{E1_SUITE}.png", dpi=300, bbox_inches="tight"); fig.savefig(FIG / f"fig_e1_{E1_SUITE}.pdf", bbox_inches="tight"); plt.show()
""")

nb["cells"] = C
nb["metadata"]["kernelspec"] = {"display_name": "Python 3", "language": "python", "name": "python3"}
nbf.write(nb, "LEDGER_Experiments.ipynb")
print("written LEDGER_Experiments.ipynb with", len(C), "cells")
