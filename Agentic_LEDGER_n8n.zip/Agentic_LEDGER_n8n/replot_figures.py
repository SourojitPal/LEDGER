"""Re-draw every figure from the saved results (no experiments are re-run).

    python replot_figures.py            # uses results/ ; takes ~1 minute

Use this after changing the plotting style (ledger/plots.py: FONT_FAMILY, FS_TITLE, FS_AXTITLE, FS_LABEL, FS_TICK).
Figures whose inputs are not stored in results/ are skipped with a note (the notebook stores them from now on).
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from ledger import plots as P                     # noqa: E402
from ledger import experiments as X               # noqa: E402
from ledger.config import Config                  # noqa: E402
from ledger.metrics import summarize              # noqa: E402

OUT = ROOT / "results"
FIG, TAB, DAT = OUT / "figures", OUT / "tables", OUT / "data"


def _csv(name, folder=DAT, **kw):
    p = folder / f"{name}.csv"
    return pd.read_csv(p, **kw) if p.exists() else None


def main() -> None:
    P.set_style()
    cfg = Config()
    done, skipped = [], []

    def run(label, fn):
        try:
            fn()
            done.append(label)
        except Exception as e:                    # keep going; report at the end
            skipped.append(f"{label}: {type(e).__name__}: {e}")
        plt.close("all")

    rq1_sum, rq1_runs = _csv("rq1_summary"), _csv("rq1_runs")
    if rq1_sum is not None:
        run("fig_rq1_asr_ua", lambda: P.fig_rq1_main(rq1_sum, str(FIG)))
        run("fig_paper_asr_ua", lambda: P.fig_paper_asr_ua(rq1_sum, str(FIG)))
    tr = _csv("rq1_traces")
    if tr is not None:
        ben = tr[tr["attack"] == "benign"].drop_duplicates()
        traces = {a: pd.concat([g, ben]) for a, g in tr.groupby("attack", sort=False) if a != "benign"}
        if "selfrep" in traces:
            run("fig_rq1_timeline", lambda: P.fig_rq1_timeline(traces["selfrep"], cfg.t_inject, str(FIG), attack="selfrep"))
        run("fig_rq1_spectral_signature", lambda: P.fig_rq1_spectral(traces, cfg.t_inject, str(FIG)))
    hc = DAT / "rq1_heatmap_counts.json"
    if hc.exists():
        run("fig_rq1_channel_heatmap", lambda: P.fig_rq1_heatmap(json.loads(hc.read_text()), str(FIG)))
    else:
        skipped.append("fig_rq1_channel_heatmap: counts not stored yet (re-run notebook Section 2 once)")
    th = _csv("rq1_localisation_theory")
    if th is not None and rq1_sum is not None:
        run("fig_rq1_localisation", lambda: P.fig_rq1_localisation(th, rq1_sum, str(FIG)))
    ab = _csv("rq1_ablation_summary")
    if ab is not None:
        run("fig_rq1_ablation", lambda: P.fig_rq1_ablation(ab, str(FIG)))
    act = _csv("rq2_action_level")
    if act is not None:
        run("fig_rq2_roc", lambda: P.fig_rq2_roc(act, X.roc_points(act), str(FIG)))
    fb = _csv("rq2_fisher")
    if fb is not None:
        run("fig_rq2_fisher", lambda: P.fig_rq2_fisher(fb, cfg.alpha_c, str(FIG)))
    cr = _csv("rq2_compare_runs")
    if cr is not None:
        run("fig_rq2_exact_vs_cosine", lambda: P.fig_rq2_compare(summarize(cr), str(FIG)))
    sens = _csv("rq2_sensitivity")
    if sens is not None:
        run("fig_rq2_sensitivity", lambda: P.fig_rq2_sensitivity(sens, str(FIG)))
    sp = _csv("rq3_spread")
    if sp is not None:
        sp["ttl"] = sp["ttl"].map(lambda v: int(v) if str(v).isdigit() else v)   # CSV turns 1,2,... into strings
        run("fig_rq3_spread_vs_R0", lambda: P.fig_rq3_spread(sp, str(FIG)))
    ct = _csv("rq3_containment")
    if ct is not None:
        run("fig_rq3_containment", lambda: P.fig_rq3_containment(ct, str(FIG)))
    fl = _csv("rq3_flood")
    bq = DAT / "rq3_flood_backlog.json"
    if fl is not None and bq.exists():
        fl["backlog_series"] = json.loads(bq.read_text())
    if fl is not None:
        run("fig_rq3_reviewer_flood", lambda: P.fig_rq3_flood(fl, cfg.reviewer_mu, str(FIG)))
        pers = _csv("table_rq3_persistence", TAB)
        if pers is not None:
            run("fig_paper_containment", lambda: P.fig_paper_containment(pers, fl, str(FIG)))
    if rq1_runs is not None:
        run("fig_rq4_pareto", lambda: P.fig_rq4_pareto(rq1_runs, str(FIG)))
    cost = _csv("table_rq4_cost", TAB)
    if cost is not None:
        run("fig_rq4_cost", lambda: P.fig_rq4_cost(cost, str(FIG)))
    sc, dev = _csv("rq4_scaling"), _csv("rq4_devices")
    if sc is not None and dev is not None:
        run("fig_rq4_scaling_devices", lambda: P.fig_rq4_scaling(sc, dev, str(FIG)))
    print(f"re-drawn {len(done)} figures in {FIG}:")
    for d in done:
        print("  ", d)
    if skipped:
        print("skipped:")
        for s in skipped:
            print("  ", s)


if __name__ == "__main__":
    main()
